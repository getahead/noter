"""Two-tier JIT-retrieval cascade: combine heading-nav and TF-IDF into a
routing decision (Tier 1), falling back to an OKF-vs-baseline choice (Tier
2) only when Tier 1 can't resolve confidently on its own.

Pure decision logic: never reads more of the document than heading-nav/
TF-IDF/OKF status already needed, and never calls an LLM -- the actual
answering step (reading the picked section(s), or the whole document) stays
an external caller's job, same as every other module in this package.

Tier 1 routing table (real evidence, see the design session's findings):

| # | Pattern                                                    | Resolution              |
|---|-------------------------------------------------------------|--------------------------|
| 1 | heading-nav: 0 hits, TF-IDF: no positive score anywhere      | escalate                |
| 2 | heading-nav: 0 hits, TF-IDF: unambiguous                     | resolved (Tier 1)       |
| 3 | heading-nav: 0 hits, TF-IDF: positive but not unambiguous    | escalate                |
| 4 | heading-nav>0, TF-IDF: no positive score anywhere            | escalate                |
| 5 | heading-nav>0, TF-IDF has signal, disagrees                  | resolved_multi (Tier 1) |
| 6 | heading-nav>0, TF-IDF has signal, agrees, unambiguous        | resolved (Tier 1)       |
| 7 | heading-nav>0, TF-IDF has signal, agrees, margin not unambiguous | escalate            |

Rows 1-4 (constructorfabric/studio#134, Oleg67's suggestion #4, plus a
review-caught correctness bug on row 4) fixed a real single-signal failure:
earlier, a zero-hit heading-nav result escalated immediately without ever
running TF-IDF at all, discarding a second, genuinely different signal --
heading-nav needs the query's exact literal substring to appear somewhere in
a section's raw text, while TF-IDF tokenizes on individual words, so a query
that differs from the source only in punctuation/spacing/hyphenation
(heading-nav: 0 hits) can still score unambiguously on TF-IDF's word-level
match. Every Tier 1 call now runs both methods unconditionally; only their
*outcome* determines whether the query needed one signal, two, or must
escalate. Row 4 exists because "TF-IDF found nothing" (every section scores
exactly 0) is a distinct outcome from "TF-IDF agrees" or "TF-IDF disagrees"
-- ``tfidf_ranked[0]`` is still a real dict entry in that case, just an
arbitrary document-order tie-break among all-zero scores, not a genuine
pick; comparing it against heading-nav's pick as if it were one previously
fabricated a "disagreement" (or, by coincidence, an "agreement") out of a
signal that was never actually there.

Row 6's "large margin" is deliberately restricted to ``unambiguous=True``
rather than a numeric margin cutoff: the only two real data points measured
for this design (an infinite margin on a correct pick, and 1.06x-1.58x
margins on two independently wrong picks) support "unambiguous is safe,
anything finite isn't yet proven safe" -- not a specific numeric threshold.
``margin_threshold`` exists so a numeric cutoff can be enabled later, once
there's real evidence for one, without an API change. Row 2 applies the same
"only trust an unambiguous signal" standard to TF-IDF running alone.

Deliberately out of scope here: folding OKF concept-file summaries into
Tier 1 as a fourth ranked signal. Tier 1's whole value is being free and
deterministic without ever touching the OKF bundle; querying OKF status
from inside Tier 1 would blur that guarantee for every query, not just the
ones that end up escalating anyway. Tier 2 already consults OKF -- see
:func:`route_tier2`.

Tier 2 never recommends an OKF concept file known to be stale/missing for
the candidate section Tier 1 identified (see :func:`route_tier2`) -- this is
this cascade's answer to the "does staleness block or serve-stale" design
question: since nothing in this codebase can perform a background rebuild
(there is no job runner, and by design no module here ever calls an LLM),
serving a known-stale OKF pointer would be a silent wrong answer with no
mechanism to ever correct itself. Falling back to baseline is the only
option that fits what this codebase can actually guarantee.

@cpt-algo:cpt-studio-algo-traceability-validation-cascade:p1
"""

from __future__ import annotations

import logging
import math
from pathlib import Path
from typing import Any, Dict, List, Optional, cast

from .doc_index import get_or_build_doc_index, record_tier2_escalation
from .heading_nav import find_sections
from .okf import get_okf_status
from .read_gate import check_gate
from .tfidf import score_sections

logger = logging.getLogger(__name__)

#: Real, measured per-query token rates (see the design session's findings).
_OKF_BUILD_COST_TOKENS = 301_187
_OKF_PER_QUERY_TOKENS = 45_735
_BASELINE_PER_QUERY_TOKENS = 333_573

#: The escalation count at which building an OKF bundle stops costing more
#: than continuing to fall back to baseline, derived from the three real
#: measured rates above rather than a second hardcoded guess: solves
#: ``_OKF_BUILD_COST_TOKENS + _OKF_PER_QUERY_TOKENS * n <=
#: _BASELINE_PER_QUERY_TOKENS * n`` for the smallest integer ``n``. This is
#: deliberately *not* the ~15-48 query figures discussed in
#: constructorfabric/studio#104's earlier comments -- those measured
#: break-even over a document's *total* query volume (most of which
#: resolve cheaply at Tier 1 and never reach this module at all); this
#: constant instead answers the narrower question route_tier2 actually
#: faces: for queries that *do* escalate to Tier 2, when does paying to
#: build OKF beat continuing to fall back to baseline for each one.
#:
#: The formula below divides by ``_BASELINE_PER_QUERY_TOKENS -
#: _OKF_PER_QUERY_TOKENS`` and only makes sense (a positive, finite
#: break-even point) while baseline costs strictly more per query than
#: OKF does -- true for the three measured rates above, but not something
#: Python enforces on three independent module-level integer literals. A
#: future edit to any of them (a rate remeasured, a typo) that silently
#: flipped or zeroed that sign would make this ``math.ceil(...)`` either
#: raise (division by zero) or -- worse -- silently produce a nonsensical
#: negative/zero break-even that made ``should_build_okf`` fire on the very
#: first escalation. Assert the invariant loudly at import time instead of
#: letting either of those happen quietly.
# @cpt-begin:cpt-studio-algo-traceability-validation-cascade:p1:inst-cascade-break-even-guard
assert _BASELINE_PER_QUERY_TOKENS > _OKF_PER_QUERY_TOKENS, (
    "_TIER2_BREAK_EVEN_ESCALATIONS's break-even math assumes baseline costs strictly more "
    "per query than OKF does (_BASELINE_PER_QUERY_TOKENS > _OKF_PER_QUERY_TOKENS); that no "
    "longer holds for the hardcoded rates above, so the break-even point below is undefined"
)
_TIER2_BREAK_EVEN_ESCALATIONS = math.ceil(
    _OKF_BUILD_COST_TOKENS / (_BASELINE_PER_QUERY_TOKENS - _OKF_PER_QUERY_TOKENS)
)
# @cpt-end:cpt-studio-algo-traceability-validation-cascade:p1:inst-cascade-break-even-guard


def _as_candidate(section: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "heading": section["heading"],
        "line_start": section["line_start"],
        "line_end": section["line_end"],
    }


def _check_margin_threshold_value(value: float) -> None:
    """Raise ``ValueError`` unless ``value`` is a finite number > 0.

    The single source of truth for the "finite and positive" rule, shared
    by :func:`_validate_margin_threshold` (the direct Python API, which
    requires ``value`` to already be numeric -- no string coercion) and
    ``commands/cascade.py``'s ``_margin_threshold_arg`` (the CLI, which
    parses the argparse string to ``float`` *first* and then delegates the
    finite/positive check here, translating a ``ValueError`` into
    ``argparse.ArgumentTypeError``). Before this was extracted, both call
    sites duplicated this exact check independently -- accepting different
    input domains (the CLI coerced ``"0.5"`` to ``0.5`` and accepted it,
    while this function rejects a bare string outright) was an accident of
    that duplication, not an intentional difference in policy, and the two
    copies could silently drift further apart on any future edit to just
    one of them.

    isinstance guards ``math.isfinite()`` itself: it raises ``TypeError``
    for any non-numeric argument, which would propagate out before the
    ``ValueError`` below ever runs. bool is deliberately excluded even
    though it subclasses int: True/False are not meaningful margin
    thresholds, and ``isfinite(True)`` would otherwise silently accept one.
    """
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not (math.isfinite(value) and value > 0)
    ):
        raise ValueError(f"margin_threshold must be a finite number > 0, got {value!r}")


def _validate_margin_threshold(margin_threshold: Optional[float]) -> None:
    """Reject a non-finite or non-positive ``margin_threshold`` before it can
    reach row 7's comparison.

    ``commands/cascade.py``'s ``_margin_threshold_arg`` enforces this same
    rule for the CLI (via the shared :func:`_check_margin_threshold_value`),
    but a direct Python caller of :func:`route_tier1`/:func:`route_query`
    bypasses argparse entirely -- without this check here too, a
    non-positive or non-finite threshold would make
    ``tfidf_result["margin"] >= margin_threshold`` fire on virtually any
    finite margin, silently defeating the "no finite value is yet proven
    safe" design basis this module's own docstring documents.

    A rejection is logged (not just raised) so a direct Python caller --
    which has no argparse error surface of its own to fall back on -- still
    leaves a structured trace of what was rejected and why.
    """
    if margin_threshold is None:
        return
    try:
        _check_margin_threshold_value(margin_threshold)
    except ValueError:
        logger.warning("rejected invalid margin_threshold: %r", margin_threshold)
        raise


# @cpt-begin:cpt-studio-algo-traceability-validation-cascade:p1:inst-cascade-tier1
def _route_tier1_heading_nav_miss(
    tfidf_ranked: List[Dict[str, Any]], has_tfidf_signal: bool, tfidf_result: Dict[str, Any],
) -> Dict[str, Any]:
    """Rows 1-3: heading-nav found nothing at all to anchor a guess to, so
    TF-IDF alone decides whether there's anything else to go on.

    Split out of :func:`route_tier1` (which was hitting pylint's
    too-many-return-statements past its own row-4 fix) rather than
    disabling the check: the docstring already treats "heading-nav found
    nothing" and "heading-nav found something" as two halves of one table,
    so giving each half its own function is a real decomposition, not a
    workaround.
    """
    if not has_tfidf_signal:
        return {"tier": "escalate", "reason": "no_signal_from_either_method", "candidates": []}
    tfidf_only_pick = tfidf_ranked[0]
    if tfidf_result["unambiguous"]:
        return {
            "tier": "resolved",
            "reason": "tfidf_only_unambiguous",
            "candidates": [_as_candidate(tfidf_only_pick)],
        }
    return {
        "tier": "escalate",
        "reason": "heading_nav_no_hits_diffuse_tfidf",
        "candidates": [_as_candidate(tfidf_only_pick)],
    }


def route_tier1(path: Path, query: str, *, margin_threshold: Optional[float] = None) -> Dict[str, Any]:
    """Apply the Tier 1 routing table to a query against ``path``.

    Returns ``{"tier": "resolved" | "resolved_multi" | "escalate", "reason":
    str, "candidates": [...]}``. ``candidates`` is the section(s) a caller
    should actually read: one for rows 2/3/4/6/7 (rows 3/4/7 despite
    escalating, since a signal's own top pick is still the best Tier-1 guess
    to hand Tier 2), two for row 5, none for row 1 (neither method found
    anything to anchor a guess to at all).

    Both heading-nav and TF-IDF always run, regardless of either one's
    outcome -- see this module's docstring for why a zero-hit heading-nav
    result used to skip TF-IDF entirely, discarding a genuinely different
    signal (word-level match vs. heading-nav's exact-phrase match). That
    means TF-IDF scoring (:func:`studio.utils.tfidf.score_sections`) always
    runs, even on a heading-nav hit that could otherwise have resolved
    without it: an accepted, explicit cost of fusing the two signals, not an
    oversight -- see ``tfidf.py``'s own module docstring for the scale
    assumption (validated against a single ~166-page, ~9-section document,
    deliberately no cap on section count or file size) this cost relies on.

    Raises ``ValueError`` if ``margin_threshold`` is not ``None`` and not a
    finite number > 0 (see :func:`_validate_margin_threshold`). This is
    checked unconditionally as the very first step, before ``nav_first_match``
    is even computed -- so it raises even for a query that would otherwise
    hit row 1 (``no_signal_from_either_method``), which never reads
    ``margin_threshold`` at all.
    """
    _validate_margin_threshold(margin_threshold)
    nav_first_match = find_sections(path, query)["first_match"]
    # Unconditional, even when heading-nav already found a hit: fusing the
    # two signals (this function's whole purpose, see the module docstring)
    # means TF-IDF's own outcome always matters, not just as a fallback for
    # a heading-nav miss. Accepted cost, not an oversight -- tfidf.py has no
    # cap on section count or file size and was only validated against a
    # single ~166-page/~9-section document; a caller feeding this an
    # adversarially large file pays that cost on every call, not just the
    # ones that end up escalating.
    tfidf_result = score_sections(path, query)
    tfidf_ranked = tfidf_result["ranked"]
    has_tfidf_signal = bool(tfidf_ranked) and tfidf_ranked[0]["score"] > 0

    if nav_first_match is None:
        return _route_tier1_heading_nav_miss(tfidf_ranked, has_tfidf_signal, tfidf_result)
    # pylint's astroid inference traces find_sections()'s "matches[0] if matches
    # else None" ternary and keeps treating this as Optional even after the
    # None-check above narrows it -- a known astroid limitation across module
    # boundaries (github.com/pylint-dev/pylint/issues/3162), not a real risk here.
    nav_pick = cast(Dict[str, Any], nav_first_match)

    # find_sections and score_sections both read retrieval_sections from the
    # same get_or_build_doc_index(path) call: a heading-nav match guarantees
    # at least one section exists, so TF-IDF always has one to rank too.
    tfidf_pick = tfidf_ranked[0]

    if not has_tfidf_signal:
        # tfidf_ranked[0] is a real dict entry, but with every section
        # scoring exactly 0 it's just document-order tie-breaking, not a
        # genuine top pick -- comparing it against nav_pick below would
        # report a fabricated "disagreement" (or, by coincidence of order,
        # a fabricated "agreement") whenever TF-IDF found nothing at all.
        # Symmetric to rows 2/3 (heading-nav's own no-signal case): the
        # single real signal here is heading-nav's, unconfirmed by a
        # second method, so it escalates rather than resolving alone.
        return {
            "tier": "escalate",
            "reason": "heading_nav_only_no_tfidf_signal",
            "candidates": [_as_candidate(nav_pick)],
        }

    if tfidf_pick["line_start"] != nav_pick["line_start"]:  # pylint: disable=unsubscriptable-object
        return {
            "tier": "resolved_multi",
            "reason": "heading_nav_tfidf_disagree",
            "candidates": [_as_candidate(nav_pick), _as_candidate(tfidf_pick)],
        }

    agree_large_margin = tfidf_result["unambiguous"] or (
        margin_threshold is not None
        and tfidf_result["margin"] is not None
        and tfidf_result["margin"] >= margin_threshold
    )
    if agree_large_margin:
        return {
            "tier": "resolved",
            "reason": "heading_nav_tfidf_agree_large_margin",
            "candidates": [_as_candidate(nav_pick)],
        }

    return {
        "tier": "escalate",
        "reason": "diffuse_margin",
        "candidates": [_as_candidate(nav_pick)],
    }
# @cpt-end:cpt-studio-algo-traceability-validation-cascade:p1:inst-cascade-tier1


# @cpt-begin:cpt-studio-algo-traceability-validation-cascade:p1:inst-cascade-tier2
def _baseline_recommendation(
    expected_future_queries: Optional[int], tier2_escalations: Optional[int],
) -> Dict[str, Any]:
    """``tier2_escalations`` is the real, persisted count of Tier 1
    escalations against this document (``None`` only outside a Studio
    project, where nothing can be persisted at all) -- this is what drives
    ``should_build_okf`` automatically, replacing the human-supplied
    ``expected_future_queries`` guess :func:`route_query` still accepts (and
    still reports ``build_okf_break_even`` for) for backward compatibility
    and for a caller that wants to reason about a *specific* future volume
    rather than the actually-observed-so-far count.

    Expected caller action on ``should_build_okf: True`` (this module never
    takes it itself -- by design, nothing here ever calls an LLM): read each
    of the document's ``retrieval_sections`` (:func:`studio.utils.doc_index.get_or_build_doc_index`),
    summarize each one, and call :func:`studio.utils.okf.write_concept_file`
    per section -- the same one-time enrichment pass OKF bundles are always
    built by, just triggered by this signal instead of a human's judgment
    call. Nothing in this codebase currently performs that pass
    automatically; a caller (a skill, an agent, a scheduled job) has to
    notice the flag and act on it.
    """
    rec: Dict[str, Any] = {"recommendation": "baseline", "reason": "no_current_okf_bundle"}
    if expected_future_queries is not None and expected_future_queries > 0:
        okf_total = _OKF_BUILD_COST_TOKENS + _OKF_PER_QUERY_TOKENS * expected_future_queries
        baseline_total = _BASELINE_PER_QUERY_TOKENS * expected_future_queries
        rec["build_okf_break_even"] = {
            "okf_total_tokens": okf_total,
            "baseline_total_tokens": baseline_total,
            "building_okf_would_pay_off": okf_total < baseline_total,
        }
    rec["tier2_escalations"] = tier2_escalations
    rec["should_build_okf"] = (
        tier2_escalations is not None and tier2_escalations >= _TIER2_BREAK_EVEN_ESCALATIONS
    )
    return rec


def route_tier2(
    path: Path,
    tier1_result: Dict[str, Any],
    *,
    expected_future_queries: Optional[int] = None,
    escalation_key: Optional[str] = None,
) -> Dict[str, Any]:
    """Choose OKF vs. baseline once Tier 1 has escalated.

    Only called for the escalating rows (see :func:`route_tier1`): row 1
    (neither method found anything), row 3 (heading-nav found nothing,
    TF-IDF diffuse), row 4 (heading-nav found a hit, TF-IDF found nothing),
    and row 7 (both have signal and agree, but not unambiguously). Rows
    3/4/7 name a candidate section, so only that section's concept file
    must be current. Row 1 has no candidate section to narrow to -- neither method found
    anything, so the query could need any section -- and OKF's own
    (external, LLM-driven) file-selection step picks among *whatever this
    function hands it*; recommending OKF there while some other section is
    stale or missing would let that external step land on exactly the
    untrustworthy one. Either way, a stale or missing concept file in the
    checked set downgrades the recommendation to baseline with
    ``okf_needs_rebuild: True`` rather than risking a known-wrong summary --
    see this module's docstring for why that's the only coherent choice
    here.

    Every call here is itself one Tier 1 escalation, so this is where that
    real usage gets recorded (:func:`studio.utils.doc_index.record_tier2_escalation`)
    -- regardless of which branch below the call ends up taking, since the
    escalation already happened by the time this function runs at all.

    ``escalation_key``, when given, is forwarded verbatim to
    :func:`studio.utils.doc_index.record_tier2_escalation` as its
    idempotency token: pass the same value on a retried call for the same
    logical query (e.g. a caller re-invoking this after a transient
    failure or timeout) so the retry doesn't inflate the persisted count a
    second time (constructorfabric/studio#136). Omitting it (the default)
    keeps the original always-increment behaviour, since there is nothing
    to deduplicate a bare retry against without one.
    """
    tier2_escalations = record_tier2_escalation(path, escalation_key=escalation_key)
    status = get_okf_status(path)
    # get_okf_status() returns one entry per retrieval section regardless of
    # whether anything was ever summarized -- an "available" bundle_dir with
    # every entry "missing" means no concept file has actually been written
    # yet, which is "no bundle" for this decision, not "bundle exists."
    bundle_exists = status["available"] and any(entry["status"] != "missing" for entry in status["entries"])
    if not bundle_exists:
        return _baseline_recommendation(expected_future_queries, tier2_escalations)

    candidates = tier1_result.get("candidates", [])
    if candidates:
        by_line_start = {entry["line_start"]: entry for entry in status["entries"]}
        relevant = [by_line_start.get(c["line_start"]) for c in candidates]
        # A candidate that no longer maps to a current section (the
        # document changed structurally between Tier 1 picking it and this
        # re-derived status) can't be verified at all -- silently dropping
        # it would let an all-unresolved candidate list pass the "any
        # stale/missing" check below vacuously (empty list, no False
        # values), recommending OKF on a candidate that was never actually
        # checked. Treat "can't verify" the same as "not current".
        if any(entry is None for entry in relevant):
            rec = _baseline_recommendation(expected_future_queries, tier2_escalations)
            rec["okf_needs_rebuild"] = True
            return rec
    else:
        # No named candidate (row 1): the external selector could land on
        # any section in the bundle, so every section must be trustworthy,
        # not just some of them.
        relevant = status["entries"]

    if any(entry["status"] != "current" for entry in relevant):
        rec = _baseline_recommendation(expected_future_queries, tier2_escalations)
        rec["okf_needs_rebuild"] = True
        return rec

    return {"recommendation": "okf", "reason": "okf_bundle_current", "bundle_dir": status["bundle_dir"]}
# @cpt-end:cpt-studio-algo-traceability-validation-cascade:p1:inst-cascade-tier2


# @cpt-begin:cpt-studio-algo-traceability-validation-cascade:p1:inst-cascade-route
def route_query(
    path: Path,
    query: str,
    *,
    margin_threshold: Optional[float] = None,
    expected_future_queries: Optional[int] = None,
    escalation_key: Optional[str] = None,
) -> Dict[str, Any]:
    """Route one query end to end: Tier 1, then Tier 2 only if it escalates.

    When Tier 2 recommends baseline (a full-document read), also runs the
    large-read confirmation gate against the document's real line count --
    the integration point this cascade exists to close, so a baseline
    fallback never happens without the caller seeing whether it crosses the
    confirmation threshold.

    Returned shape is a stable contract, not incidental: top-level ``query``,
    ``tier``, ``reason``, ``candidates`` (:func:`route_tier1`'s own return,
    merged in) are always present; ``tier2`` (:func:`route_tier2`'s return,
    with ``recommendation``/``reason``/optional ``okf_needs_rebuild``, plus
    -- whenever ``recommendation`` is ``"baseline"`` --
    ``tier2_escalations``/``should_build_okf``, see
    :func:`_baseline_recommendation`) is added only when Tier 1 escalated; ``read_gate``
    (:func:`studio.utils.read_gate.check_gate`'s return, with
    ``needs_confirmation``/``total_lines``/``threshold``) is added only when
    Tier 2 recommends ``"baseline"``. ``commands/cascade.py``'s
    ``_human_retrieve`` and ``tests/test_cascade.py`` both key into these
    fields by name -- changing a key here is a breaking change for both and
    should be treated as one (versioned or coordinated), not a routine edit.

    ``escalation_key`` is forwarded to :func:`route_tier2` unchanged (see
    its docstring): an optional idempotency token identifying one logical
    query attempt, so a caller retrying this same query after a transient
    failure or timeout can pass the same key again and not double-count
    the Tier-2 escalation (constructorfabric/studio#136).

    Raises ``ValueError`` for an invalid ``margin_threshold`` -- this calls
    :func:`route_tier1` first, which validates it unconditionally before
    doing anything else (see that function's own docstring).
    """
    tier1 = route_tier1(path, query, margin_threshold=margin_threshold)
    result: Dict[str, Any] = {"query": query, **tier1}
    if tier1["tier"] != "escalate":
        return result

    tier2 = route_tier2(
        path, tier1, expected_future_queries=expected_future_queries, escalation_key=escalation_key,
    )
    result["tier2"] = tier2

    if tier2["recommendation"] == "baseline":
        index = get_or_build_doc_index(path)
        result["read_gate"] = check_gate(index["total_lines"])

    return result
# @cpt-end:cpt-studio-algo-traceability-validation-cascade:p1:inst-cascade-route
