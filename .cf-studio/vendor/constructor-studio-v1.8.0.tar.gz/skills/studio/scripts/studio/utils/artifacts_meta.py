"""
Studio Validator - Artifacts Metadata Registry

Parses and provides access to artifacts.toml with the hierarchical system structure.

@cpt-flow:cpt-studio-flow-core-infra-cli-invocation:p1
"""

import fnmatch
import glob
import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, Iterator, List, Optional, Set, Tuple

from ._tomllib_compat import tomllib
from ..constants import ARTIFACTS_REGISTRY_FILENAME

logger = logging.getLogger(__name__)

# @cpt-begin:cpt-studio-algo-core-infra-registry-parsing:p1:inst-reg-dataclasses
# Slug validation pattern: lowercase letters, numbers, hyphens (no leading/trailing hyphens)
SLUG_PATTERN = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")

_TOKEN_PROJECT_ROOT = "{project_root}"
_TOKEN_SYSTEM = "$system"


def _merge_authoritative_core_kits(registry_kits: object, core_kits: object) -> object:
    merged = dict(registry_kits) if isinstance(registry_kits, dict) else {}
    if not isinstance(core_kits, dict):
        return merged
    for kit_id, core_kit in core_kits.items():
        if not isinstance(kit_id, str) or not isinstance(core_kit, dict):
            continue
        existing = merged.get(kit_id)
        if isinstance(existing, dict):
            merged_kit = dict(existing)
            merged_kit.update(core_kit)
            merged[kit_id] = merged_kit
            continue
        merged[kit_id] = dict(core_kit)
    return merged


def _parse_autodetect_artifacts(raw: object) -> "Dict[str, AutodetectArtifactPattern]":
    artifacts: Dict[str, "AutodetectArtifactPattern"] = {}
    if isinstance(raw, dict):
        for kind, v in raw.items():
            if isinstance(kind, str) and isinstance(v, dict):
                artifacts[kind] = AutodetectArtifactPattern.from_dict(v)
    return artifacts


def _parse_autodetect_codebase(raw: object) -> "List[CodebaseEntry]":
    codebase: List["CodebaseEntry"] = []
    if isinstance(raw, list):
        for c in raw:
            if isinstance(c, dict):
                codebase.append(CodebaseEntry.from_dict(c))
    return codebase


@dataclass
class Kit:
    """A kit package defining format and path to templates/rules."""

    kit_id: str
    format: str
    path: str  # Path to kit package (e.g., "kits/sdlc")
    artifacts: Dict[str, Dict[str, str]] = field(default_factory=dict)
    source: Optional[str] = None  # @cpt-algo:cpt-studio-feature-workspace:p1 — Workspace source name (v1.2+)

    @classmethod
    def from_dict(cls, kit_id: str, data: dict) -> "Kit":
        """Build an instance from a dictionary."""
        raw_format = (data or {}).get("format", "")
        fmt = str(raw_format).strip() if isinstance(raw_format, str) else ""

        raw_path = (data or {}).get("path", "")
        path = str(raw_path).strip() if isinstance(raw_path, str) else ""

        artifacts = _parse_kit_artifacts((data or {}).get("artifacts", {}))

        raw_source = (data or {}).get("source", None)
        source = str(raw_source).strip() if isinstance(raw_source, str) and str(raw_source).strip() else None
        return cls(
            kit_id=kit_id,
            format=fmt,
            path=path,
            artifacts=artifacts,
            source=source,
        )

    def is_cfs_format(self) -> bool:
        """Check if this kit uses the canonical CFS format (full tooling support)."""
        return self.format == "CFS"

    @staticmethod
    def _substitute_registry_tokens(path_template: str) -> str:
        """Expand registry tokens in a path template."""
        out = str(path_template or "")
        return out.replace(_TOKEN_PROJECT_ROOT, ".")

    def get_template_path(self, kind: str) -> Optional[str]:
        """Get the template file path for a given artifact kind."""
        k = str(kind or "").strip().upper()
        if self.artifacts and k in self.artifacts:
            tpl = (self.artifacts.get(k) or {}).get("template")
            if isinstance(tpl, str) and tpl.strip():
                return self._substitute_registry_tokens(tpl.strip())
            return None
        return f"{self.path.rstrip('/')}/artifacts/{kind}/template.md"

    def get_examples_path(self, kind: str) -> Optional[str]:
        """Get the examples directory path for a given artifact kind."""
        k = str(kind or "").strip().upper()
        if self.artifacts and k in self.artifacts:
            ex = (self.artifacts.get(k) or {}).get("examples")
            if isinstance(ex, str) and ex.strip():
                return self._substitute_registry_tokens(ex.strip())
            return None
        return f"{self.path.rstrip('/')}/artifacts/{kind}/examples"


def _parse_kit_artifacts(raw_artifacts: object) -> Dict[str, Dict[str, str]]:
    """Normalize a kit's artifact-path mapping from registry data."""
    artifacts: Dict[str, Dict[str, str]] = {}
    if not isinstance(raw_artifacts, dict):
        return artifacts
    for kind, spec in raw_artifacts.items():
        if not isinstance(kind, str) or not kind.strip() or not isinstance(spec, dict):
            continue
        item: Dict[str, str] = {}
        for key in ("template", "examples", "rules", "checklist"):
            value = spec.get(key)
            if isinstance(value, str) and value.strip():
                item[key] = value.strip()
        if item:
            artifacts[kind.strip().upper()] = item
    return artifacts

@dataclass
class Artifact:
    """A registered artifact (document)."""

    path: str
    kind: str  # Artifact kind (e.g., PRD, DESIGN, ADR)
    traceability: str  # "FULL" | "DOCS-ONLY"
    name: Optional[str] = None  # Human-readable name (optional)
    source: Optional[str] = None  # Workspace source name (v1.2+)

    # Backward compatibility property
    @property
    def type(self) -> str:
        """Return the legacy artifact type alias."""
        return self.kind

    @classmethod
    def from_dict(cls, data: dict) -> "Artifact":
        """Build an instance from a dictionary."""
        # Support both "kind" (new) and "type" (old) keys
        kind = str(data.get("kind", data.get("type", "")))
        name = data.get("name")
        raw_source = (data or {}).get("source", None)
        source = str(raw_source).strip() if isinstance(raw_source, str) and str(raw_source).strip() else None
        return cls(
            path=str(data.get("path", "")),
            kind=kind,
            traceability=str(data.get("traceability", "DOCS-ONLY")),
            name=str(name) if name else None,
            source=source,
        )


def _parse_single_line_comments(data: dict) -> Optional[List[str]]:
    slc = data.get("singleLineComments")
    if isinstance(slc, list):
        return [str(s).strip() for s in slc if isinstance(s, str) and str(s).strip()]
    return None


def _parse_multi_line_comments(data: dict) -> Optional[List[Dict[str, str]]]:
    mlc = data.get("multiLineComments")
    if not isinstance(mlc, list):
        return None
    parsed: List[Dict[str, str]] = []
    for item in mlc:
        if isinstance(item, dict) and "start" in item and "end" in item:
            parsed.append({"start": str(item["start"]), "end": str(item["end"])})
    return parsed if parsed else None


@dataclass
class CodebaseEntry:
    """A registered source code directory."""

    path: str
    extensions: List[str] = field(default_factory=list)
    name: Optional[str] = None  # Human-readable name (optional)
    single_line_comments: Optional[List[str]] = None
    multi_line_comments: Optional[List[Dict[str, str]]] = None
    source: Optional[str] = None  # Workspace source name (v1.2+)

    @classmethod
    def from_dict(cls, data: dict) -> "CodebaseEntry":
        """Build an instance from a dictionary."""
        exts = data.get("extensions", [])
        if not isinstance(exts, list):
            exts = []
        name = data.get("name")

        slc = _parse_single_line_comments(data)
        mlc = _parse_multi_line_comments(data)

        raw_source = (data or {}).get("source", None)
        source = str(raw_source).strip() if isinstance(raw_source, str) and str(raw_source).strip() else None
        return cls(
            path=str(data.get("path", "")),
            extensions=[str(e) for e in exts if isinstance(e, str)],
            name=str(name) if name else None,
            single_line_comments=slc,
            multi_line_comments=mlc,
            source=source,
        )

@dataclass
class IgnoreBlock:
    """Global ignore rule block."""

    reason: str
    patterns: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "IgnoreBlock":
        """Build an instance from a dictionary."""
        reason = str((data or {}).get("reason", "") or "").strip()
        raw_patterns = (data or {}).get("patterns", [])
        patterns: List[str] = []
        if isinstance(raw_patterns, list):
            patterns = [str(p).strip() for p in raw_patterns if isinstance(p, str) and str(p).strip()]
        return cls(reason=reason, patterns=patterns)

@dataclass
class AutodetectArtifactPattern:
    """Autodetection pattern declared by a kit manifest."""

    pattern: str
    traceability: str
    required: bool = True

    @classmethod
    def from_dict(cls, data: dict) -> "AutodetectArtifactPattern":
        """Build an instance from a dictionary."""
        return cls(
            pattern=str((data or {}).get("pattern", "") or "").strip(),
            traceability=str((data or {}).get("traceability", "FULL") or "FULL").strip(),
            required=bool((data or {}).get("required", True)),
        )

@dataclass
class AutodetectRule:
    """Autodetect rule (v1.1+)."""

    kit: Optional[str] = None
    system_root: Optional[str] = None
    artifacts_root: Optional[str] = None
    aliases: Dict[str, dict] = field(default_factory=dict)
    artifacts: Dict[str, AutodetectArtifactPattern] = field(default_factory=dict)
    codebase: List[CodebaseEntry] = field(default_factory=list)
    validation: Dict[str, object] = field(default_factory=dict)
    children: List["AutodetectRule"] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "AutodetectRule":
        """Build an instance from a dictionary."""
        artifacts = _parse_autodetect_artifacts((data or {}).get("artifacts", {}))
        codebase = _parse_autodetect_codebase((data or {}).get("codebase", []))

        raw_children = (data or {}).get("children", [])
        children: List[AutodetectRule] = []
        if isinstance(raw_children, list):
            for r in raw_children:
                if isinstance(r, dict):
                    children.append(cls.from_dict(r))

        aliases = (data or {}).get("aliases", {})
        if not isinstance(aliases, dict):
            aliases = {}

        validation = (data or {}).get("validation", {})
        if not isinstance(validation, dict):
            validation = {}

        kit = (data or {}).get("kit", None)
        return cls(
            kit=str(kit).strip() if isinstance(kit, str) and str(kit).strip() else None,
            system_root=str((data or {}).get("system_root", "") or "").strip() or None,
            artifacts_root=str((data or {}).get("artifacts_root", "") or "").strip() or None,
            aliases={str(k): v for k, v in aliases.items() if isinstance(k, str) and isinstance(v, dict)},
            artifacts=artifacts,
            codebase=codebase,
            validation=validation,
            children=children,
        )

@dataclass
class SystemNode:
    """A node in the system hierarchy (system, subsystem, component, module, etc.)."""

    name: str
    slug: str  # Machine-readable identifier (lowercase, no spaces)
    kit: str  # Reference to kit ID
    id_slug: Optional[str] = None
    artifacts: List[Artifact] = field(default_factory=list)
    codebase: List[CodebaseEntry] = field(default_factory=list)
    children: List["SystemNode"] = field(default_factory=list)
    autodetect: List[AutodetectRule] = field(default_factory=list)
    parent: Optional["SystemNode"] = field(default=None, repr=False)

    def get_hierarchy_prefix(self) -> str:
        """Get the hierarchical ID prefix by concatenating slugs from root to this node.

        Example: For a component 'auth' under subsystem 'core' under system 'saas-platform',
        returns 'saas-platform-core-auth'.
        """
        parts: List[str] = []
        node: Optional[SystemNode] = self
        while node is not None:
            current_slug = node.id_slug or node.slug
            if current_slug:
                parts.append(current_slug)
            node = node.parent
        return "-".join(reversed(parts))

    @classmethod
    def from_dict(cls, data: dict, parent: Optional["SystemNode"] = None) -> "SystemNode":
        """Build an instance from a dictionary."""
        kit = str(data.get("kit", data.get("kits", "")))
        # For backward compatibility, generate slug from name if not provided
        name = str(data.get("name", ""))
        raw_slug = (data or {}).get("slug", None)
        slug = str(raw_slug) if isinstance(raw_slug, str) else ""
        if not slug and ("slug" not in (data or {})) and name:
            # Auto-generate slug from name: lowercase, replace spaces with hyphens
            slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
        node = cls(
            name=name,
            slug=slug,
            id_slug=None,
            kit=kit,
            parent=parent,
        )

        raw_artifacts = data.get("artifacts", [])
        if isinstance(raw_artifacts, list):
            for a in raw_artifacts:
                if isinstance(a, dict):
                    node.artifacts.append(Artifact.from_dict(a))

        for c in _parse_autodetect_codebase(data.get("codebase", [])):
            node.codebase.append(c)

        raw_children = data.get("children", [])
        if isinstance(raw_children, list):
            for child_data in raw_children:
                if isinstance(child_data, dict):
                    node.children.append(cls.from_dict(child_data, parent=node))

        raw_autodetect = data.get("autodetect", [])
        if isinstance(raw_autodetect, list):
            for r in raw_autodetect:
                if isinstance(r, dict):
                    node.autodetect.append(AutodetectRule.from_dict(r))

        return node

def _collect_def_ids_from_artifacts(
    artifacts: List["Artifact"],
    resolve_path_fn: "Callable[[str], Path]",
    errors: Optional[List[str]] = None,
) -> Tuple[List[str], bool]:
    """Collect all definition CPT IDs from a list of artifacts.

    Returns (all_def_ids, has_ids) where has_ids is True if any artifact had IDs.
    When *errors* is provided, scan failures are appended instead of silently ignored.
    """
    all_def_ids: List[str] = []
    has_ids = False
    for art in artifacts:
        art_abs = resolve_path_fn(art.path)
        try:
            from .document import scan_cpt_ids
            for h in scan_cpt_ids(art_abs):
                if h.get("type") != "definition" or not h.get("id"):
                    continue
                has_ids = True
                all_def_ids.append(str(h["id"]))
        except (OSError, ValueError) as exc:
            if errors is not None:
                errors.append(f"Failed to scan IDs in {art_abs}: {exc}")
            continue
    return all_def_ids, has_ids


def _collect_unique_slugs(
    all_def_ids: List[str],
    prefix: str,
    kind_tokens: "Set[str]",
) -> Set[str]:
    """Extract unique system slug candidates from *all_def_ids* using *prefix*."""
    slugs: Set[str] = set()
    for cid in all_def_ids:
        candidates = extract_system_slug_candidates(cid, prefix, kind_tokens)
        if len(candidates) == 1:
            slugs.add(candidates[0])
    return slugs


def _check_with_child_slugs(
    child_node: "SystemNode",
    child_slugs: Set[str],
    full_systems: Set[str],
    prefix_info: str,
    errors: List[str],
) -> None:
    """Handle slug consistency when child_slugs were found."""
    if len(full_systems) > 1:
        errors.append(
            f"Inconsistent systems in IDs: system={child_node.name} "
            f"folder_slug={child_node.slug}{prefix_info} — "
            f"IDs use different system prefixes: {sorted(full_systems)}"
        )
    elif len(child_slugs) == 1:
        child_node.id_slug = next(iter(child_slugs))
    else:
        errors.append(
            f"Inconsistent systems in IDs: system={child_node.name} "
            f"folder_slug={child_node.slug}{prefix_info} — "
            f"IDs use different system slugs: {sorted(child_slugs)}"
        )


def _check_without_child_slugs(
    child_node: "SystemNode",
    full_systems: Set[str],
    parent_prefix: str,
    prefix_info: str,
    errors: List[str],
) -> None:
    """Handle slug consistency when no child_slugs matched but IDs exist."""
    if len(full_systems) > 1:
        errors.append(
            f"Inconsistent systems in IDs: system={child_node.name} "
            f"folder_slug={child_node.slug}{prefix_info} — "
            f"IDs use different system prefixes: {sorted(full_systems)}"
        )
    elif len(full_systems) == 1:
        full_sys = next(iter(full_systems))
        if parent_prefix:
            errors.append(
                f"IDs missing parent prefix: system={child_node.name} "
                f"folder_slug={child_node.slug}{prefix_info} — "
                f"all IDs use system `{full_sys}` which does not start with `{parent_prefix}-`"
            )
    else:
        errors.append(
            f"Cannot determine system from IDs: system={child_node.name} "
            f"folder_slug={child_node.slug}{prefix_info} — "
            f"no ID has an unambiguous kind-token marker"
        )


def _check_child_slug_consistency(
    child_node: "SystemNode",
    all_def_ids: List[str],
    has_ids: bool,
    kind_tokens: "Set[str]",
    parent_prefix: str,
    errors: List[str],
) -> None:
    """Check child system slug consistency based on IDs found in its artifacts.

    Appends error strings to errors when inconsistencies are detected.
    Does NOT mutate child_node.slug to preserve dedup key stability.
    """
    prefix_info = f" parent_prefix={parent_prefix}" if parent_prefix else ""

    child_slugs = _collect_unique_slugs(all_def_ids, parent_prefix, kind_tokens)
    full_systems = _collect_unique_slugs(all_def_ids, "", kind_tokens)

    if child_slugs:
        _check_with_child_slugs(child_node, child_slugs, full_systems, prefix_info, errors)
    elif has_ids:
        _check_without_child_slugs(child_node, full_systems, parent_prefix, prefix_info, errors)


class ArtifactsMeta:
    """
    Parses and provides access to artifacts.toml.

    Provides methods to find:
    - Artifacts by path or kind
    - Systems by name or level
    - Kits by ID
    - Codebase entries
    """

    def __init__(
        self,
        version: str,
        project_root: str,
        kits: Dict[str, Kit],
        systems: List[SystemNode],
        ignore: Optional[List[IgnoreBlock]] = None,
    ):
        self.version = version
        self.project_root = project_root
        self.kits = kits
        self.systems = systems

        self.ignore = ignore or []
        self._ignore_patterns: List[str] = []
        for blk in self.ignore:
            for p in (blk.patterns or []):
                sp = str(p).strip()
                if sp:
                    self._ignore_patterns.append(sp)

        # Build indices for fast lookups
        self._artifacts_by_path: Dict[str, Tuple[Artifact, SystemNode]] = {}
        self._build_indices()

    def is_ignored(self, rel_path: str) -> bool:
        """Return True if rel_path matches any registry root ignore pattern."""
        rp = self._normalize_path(rel_path)
        for pat in self._ignore_patterns:
            if fnmatch.fnmatch(rp, pat):
                return True
            # Treat "dir/*" as also ignoring "dir" itself (common expectation for directory ignores).
            if pat.endswith("/*"):
                base = pat[:-2]
                if rp == base:
                    return True
        return False

    def _build_indices(self) -> None:
        """Build lookup indices from the system tree."""
        for root_system in self.systems:
            self._index_system(root_system)

    def _index_system(self, node: SystemNode) -> None:
        """Index a system node and its descendants."""
        # Index artifacts
        for artifact in node.artifacts:
            if self.is_ignored(artifact.path):
                continue
            normalized_path = self._normalize_path(artifact.path)
            self._artifacts_by_path[normalized_path] = (artifact, node)

        # Recurse into children
        for child in node.children:
            self._index_system(child)

    @staticmethod
    def _normalize_path(path: str) -> str:
        """Normalize path for consistent lookups."""
        p = path.strip()
        if p.startswith("./"):
            p = p[2:]
        return p

    @classmethod
    def from_dict(cls, data: dict) -> "ArtifactsMeta":
        """Create ArtifactsMeta from parsed JSON dict."""
        version = str(data.get("version", "1.0"))
        project_root = str(data.get("project_root", ".."))

        ignore: List[IgnoreBlock] = []
        raw_ignore = data.get("ignore", [])
        if isinstance(raw_ignore, list):
            for blk in raw_ignore:
                if isinstance(blk, dict):
                    ignore.append(IgnoreBlock.from_dict(blk))

        kits: Dict[str, Kit] = {}
        raw_kits = data.get("kits", {})
        if isinstance(raw_kits, dict):
            for kit_id, kit_data in raw_kits.items():
                if isinstance(kit_data, dict):
                    kits[kit_id] = Kit.from_dict(kit_id, kit_data)

        systems: List[SystemNode] = []
        raw_systems = data.get("systems", [])
        if isinstance(raw_systems, list):
            for sys_data in raw_systems:
                if isinstance(sys_data, dict):
                    systems.append(SystemNode.from_dict(sys_data))

        return cls(
            version=version,
            project_root=project_root,
            kits=kits,
            systems=systems,
            ignore=ignore,
        )

    def rebuild_indices(self) -> None:
        """Rebuild lookup indices from the current artifacts."""
        self._artifacts_by_path = {}
        self._build_indices()

    def get_kit(self, kit_id: str) -> Optional[Kit]:
        """Get a kit definition by ID."""
        return (self.kits or {}).get(str(kit_id))
    # @cpt-end:cpt-studio-algo-core-infra-registry-parsing:p1:inst-reg-dataclasses

    # @cpt-begin:cpt-studio-algo-core-infra-registry-parsing:p1:inst-reg-expand-autodetect
    def expand_autodetect(  # pylint: disable=too-many-locals,too-many-statements
        self,
        *,
        adapter_dir: Path,
        project_root: Path,
        is_kind_registered: Optional[Callable[[str, str], bool]] = None,
        get_id_kind_tokens: Optional[Callable[[str], Set[str]]] = None,
    ) -> List[str]:
        """Expand autodetect rules into concrete artifact/codebase entries.

        Args:
            get_id_kind_tokens: Callback returning all ID kind tokens for a kit_id.
                Used to detect system slugs from artifact IDs during autodetect.

        Returns a list of validation error messages (best-effort).
        """

        errors: List[str] = []

        # Normalize roots to avoid path-prefix mismatches on macOS (e.g. /var vs /private/var)
        adapter_dir = adapter_dir.resolve()
        project_root = project_root.resolve()

        def _substitute(s: str, *, system: str, system_root: str, parent_root: str) -> str:
            out = str(s)
            out = out.replace("{system}", system)
            # {project_root} is the project root directory, not the registry's relative project_root string.
            # It intentionally expands to '.' so templates like '{project_root}/subsystems' resolve under
            # the provided `project_root` path.
            out = out.replace(_TOKEN_PROJECT_ROOT, ".")
            out = out.replace("{system_root}", system_root)
            out = out.replace("{parent_root}", parent_root)
            return out

        def _resolve_path(expanded: str) -> Path:
            e = str(expanded).strip()
            pr = str(self.project_root).strip()
            if pr and (e == pr or e.startswith(pr.rstrip("/") + "/")):
                return (adapter_dir / e).resolve()
            return (project_root / e).resolve()

        def _rel_to_project_root(p: Path) -> Optional[str]:
            if p.is_relative_to(project_root):
                return p.relative_to(project_root).as_posix()
            return None

        def _glob_files(root_abs: Path, pat: str) -> List[Path]:
            if not pat:
                return []
            g = str((root_abs / pat).as_posix())
            hits = [Path(x) for x in glob.glob(g, recursive=True)]
            out: List[Path] = []
            for h in hits:
                if not h.is_file():
                    continue
                rel = _rel_to_project_root(h.resolve())
                if not rel:
                    continue
                if self.is_ignored(rel):
                    continue
                out.append(h.resolve())
            return out

        def _iter_markdown_files(root_abs: Path) -> List[Path]:
            if not root_abs.is_dir():
                return []
            g = str((root_abs / "**" / "*.md").as_posix())
            hits = [Path(x) for x in glob.glob(g, recursive=True)]
            out: List[Path] = []
            for h in hits:
                if not h.is_file():
                    continue
                rel = _rel_to_project_root(h.resolve())
                if not rel:
                    continue
                if self.is_ignored(rel):
                    continue
                out.append(h.resolve())
            return out

        def _get_or_create_child_system(parent: SystemNode, *, slug: str, name: str, kit: str) -> SystemNode:
            for ch in parent.children:
                if str(ch.slug) == str(slug):
                    return ch
            child = SystemNode(
                name=str(name),
                slug=str(slug),
                kit=str(kit),
                artifacts=[],
                codebase=[],
                children=[],
                autodetect=[],
                parent=parent,
            )
            parent.children.append(child)
            return child

        def _discover_child_system_roots(
            parent: SystemNode,
            rule: AutodetectRule,
            *,
            parent_root_str: str,
        ) -> List[Tuple[SystemNode, str, Path]]:
            """Discover child systems for rules whose system_root contains $system.

            Returns list of (child_node, child_system_root_str, child_system_root_abs).
            """

            system_root_template = str(rule.system_root or _TOKEN_PROJECT_ROOT)
            if _TOKEN_SYSTEM not in system_root_template:
                return []

            # Expand other placeholders, keep $system for globbing.
            templ = _substitute(system_root_template, system=parent.slug, system_root="", parent_root=parent_root_str)
            # Build directory glob: replace $system with '*'
            g = templ.replace(_TOKEN_SYSTEM, "*")

            # Resolve as project-root relative (preferred). If it looks adapter-root relative, _resolve_path handles it.
            root_glob = str((_resolve_path(g)).as_posix())
            hits = [Path(x) for x in glob.glob(root_glob, recursive=False)]
            out: List[Tuple[SystemNode, str, Path]] = []
            for h in hits:
                try:
                    h = h.resolve()
                except OSError as exc:
                    logger.warning("Failed to resolve autodetect path %s: %s", h, exc)
                    continue
                if not h.exists() or not h.is_dir():
                    continue
                rel = _rel_to_project_root(h)
                if rel is None:
                    continue
                if self.is_ignored(rel):
                    continue
                raw_name = h.name
                slug = generate_slug(str(raw_name))
                if not slug:
                    continue
                kit_id = rule.kit or parent.kit
                child = _get_or_create_child_system(parent, slug=slug, name=str(raw_name), kit=str(kit_id))
                out.append((child, rel, h))

            return out

        def _apply_rule(  # pylint: disable=too-many-locals,too-many-branches,too-many-statements
            node: SystemNode,
            rule: AutodetectRule,
            *,
            parent_root_str: str,
            system_root_override: Optional[Tuple[str, Path]] = None,
        ) -> Tuple[List[Artifact], List[CodebaseEntry], str, List[AutodetectRule]]:
            kit_id = rule.kit or node.kit

            # Resolve system_root
            if system_root_override is not None:
                system_root_str, system_root_abs = system_root_override
            else:
                system_root_template = rule.system_root or _TOKEN_PROJECT_ROOT
                system_root_str = _substitute(
                    system_root_template,
                    system=node.slug,
                    system_root="",
                    parent_root=parent_root_str,
                )
                system_root_abs = _resolve_path(system_root_str)
                system_root_rel = _rel_to_project_root(system_root_abs)
                if system_root_rel is None:
                    # If outside project_root, treat as out-of-scope
                    system_root_rel = ""

            # Resolve artifacts_root
            artifacts_root_template = rule.artifacts_root or "{system_root}"
            artifacts_root_str = _substitute(
                artifacts_root_template,
                system=node.slug,
                system_root=system_root_str,
                parent_root=parent_root_str,
            )
            artifacts_root_abs = _resolve_path(artifacts_root_str)

            discovered_artifacts: List[Artifact] = []
            used_patterns: List[str] = []
            for kind, ap in (rule.artifacts or {}).items():
                kind_s = str(kind).strip()
                if not kind_s:
                    continue
                if ap.pattern:
                    used_patterns.append(str(ap.pattern))
                if is_kind_registered is not None and bool(
                    rule.validation.get("require_kind_registered_in_kit", False)
                ):
                    if not is_kind_registered(str(kit_id), kind_s):
                        errors.append(
                            "Autodetect kind not registered in kit: "
                            f"kit={kit_id} kind={kind_s} system={node.slug}"
                        )
                        continue

                hits = _glob_files(artifacts_root_abs, ap.pattern)
                if ap.required and not hits:
                    errors.append(
                        "Required autodetect artifact missing: "
                        f"system={node.slug} kind={kind_s} pattern={ap.pattern}"
                    )
                for h in hits:
                    rel = _rel_to_project_root(h)
                    if not rel:
                        continue
                    if bool(rule.validation.get("require_md_extension", False)) and not rel.lower().endswith(".md"):
                        errors.append(f"Autodetect artifact must be .md: {rel}")
                        continue
                    discovered_artifacts.append(
                        Artifact(
                            path=rel,
                            kind=kind_s,
                            traceability=str(ap.traceability or "FULL"),
                        )
                    )

            if bool(rule.validation.get("fail_on_unmatched_markdown", False)):
                md_files = _iter_markdown_files(artifacts_root_abs)
                for mf in md_files:
                    if not mf.is_relative_to(artifacts_root_abs):
                        logger.warning("Skipping markdown file outside artifacts root: %s", mf)
                        continue
                    rel_to_root = mf.relative_to(artifacts_root_abs).as_posix()
                    matched = False
                    for pat in used_patterns:
                        if pat and fnmatch.fnmatch(rel_to_root, pat):
                            matched = True
                            break
                    if not matched:
                        rel = _rel_to_project_root(mf)
                        if rel:
                            errors.append(f"Unmatched markdown under artifacts_root: system={node.slug} path={rel}")

            discovered_codebase: List[CodebaseEntry] = []
            for cb in (rule.codebase or []):
                cb_path_t = cb.path
                cb_path_expanded = _substitute(
                    cb_path_t,
                    system=node.slug,
                    system_root=system_root_str,
                    parent_root=parent_root_str,
                )
                cb_abs = _resolve_path(cb_path_expanded)
                cb_rel = _rel_to_project_root(cb_abs)
                if not cb_rel:
                    continue
                if self.is_ignored(cb_rel):
                    continue
                discovered_codebase.append(CodebaseEntry(
                    path=cb_rel,
                    extensions=list(cb.extensions or []),
                    name=cb.name,
                    single_line_comments=list(cb.single_line_comments) if cb.single_line_comments else None,
                    multi_line_comments=list(cb.multi_line_comments) if cb.multi_line_comments else None,
                ))

            return discovered_artifacts, discovered_codebase, system_root_str, list(rule.children or [])

        def _merge_discovered_child_entries(
            child_node: SystemNode,
            disc_artifacts: List[Artifact],
            disc_codebase: List[CodebaseEntry],
        ) -> None:
            """Merge autodetected entries into a child node."""
            existing_child_artifacts_by_path: Dict[str, Artifact] = {
                self._normalize_path(a.path): a for a in child_node.artifacts
            }
            existing_child_codebase_by_path: Dict[str, CodebaseEntry] = {
                self._normalize_path(c.path): c for c in child_node.codebase
            }
            for da in disc_artifacts:
                np = self._normalize_path(da.path)
                if np in existing_child_artifacts_by_path:
                    if str(existing_child_artifacts_by_path[np].kind) != str(da.kind):
                        errors.append(
                            "Autodetect conflict on path with different kind: "
                            f"path={da.path} explicit={existing_child_artifacts_by_path[np].kind} "
                            f"detected={da.kind}"
                        )
                    continue
                existing_child_artifacts_by_path[np] = da
                child_node.artifacts.append(da)

            for dc in disc_codebase:
                np = self._normalize_path(dc.path)
                if np in existing_child_codebase_by_path:
                    continue
                existing_child_codebase_by_path[np] = dc
                child_node.codebase.append(dc)

        def _expand_node(  # pylint: disable=too-many-locals,too-many-branches
            node: SystemNode,
            inherited_rules: List[Tuple[AutodetectRule, str]],
        ) -> List[Tuple[AutodetectRule, str]]:
            effective: List[Tuple[AutodetectRule, str]] = list(inherited_rules)
            default_parent_root = inherited_rules[0][1] if inherited_rules else str(self.project_root)
            for r in (node.autodetect or []):
                # Node-level rules use the current node's parent_root (derived from inheritance if any).
                effective.append((r, default_parent_root))

            # Apply rules in order
            existing_artifacts_by_path: Dict[str, Artifact] = {self._normalize_path(a.path): a for a in node.artifacts}
            existing_codebase_by_path: Dict[str, CodebaseEntry] = {
                self._normalize_path(c.path): c for c in node.codebase
            }

            next_inherited: List[Tuple[AutodetectRule, str]] = []

            processed_children: Set[str] = set()

            for rule, parent_root_str in effective:
                # Special: system_root containing $system means "discover child systems".
                if rule.system_root and _TOKEN_SYSTEM in str(rule.system_root):
                    discovered = _discover_child_system_roots(node, rule, parent_root_str=parent_root_str)
                    for child_node, child_root_str, child_root_abs in discovered:
                        disc_artifacts, disc_codebase, system_root_str, child_rules = _apply_rule(
                            child_node,
                            rule,
                            parent_root_str=parent_root_str,
                            system_root_override=(child_root_str, child_root_abs),
                        )

                        _merge_discovered_child_entries(child_node, disc_artifacts, disc_codebase)

                        # Detect system slug from artifact IDs (autodetect only).
                        # Strategy: extract the full system prefix from each ID
                        # (everything between `cpt-` and the first kind-token marker).
                        # All IDs must agree on the same system prefix — if they
                        # don't, report the distinct systems found.
                        if get_id_kind_tokens is not None:
                            _kit_id = rule.kit or node.kit
                            _kind_tokens = get_id_kind_tokens(str(_kit_id))
                            if _kind_tokens:
                                _parent_prefix = node.get_hierarchy_prefix()
                                _all_def_ids, _has_ids = _collect_def_ids_from_artifacts(
                                    child_node.artifacts, _resolve_path, errors,
                                )
                                _check_child_slug_consistency(
                                    child_node, _all_def_ids, _has_ids,
                                    _kind_tokens, _parent_prefix, errors,
                                )

                        # Expand grandchildren immediately with correct parent_root.
                        inherited_for_grandchildren = [(cr, system_root_str) for cr in (child_rules or [])]
                        _expand_node(child_node, inherited_for_grandchildren)
                        processed_children.add(self._normalize_path(child_node.slug))

                    continue

                disc_artifacts, disc_codebase, system_root_str, child_rules = _apply_rule(
                    node,
                    rule,
                    parent_root_str=parent_root_str,
                )
                for da in disc_artifacts:
                    np = self._normalize_path(da.path)
                    if np in existing_artifacts_by_path:
                        # explicit wins; if kind differs, keep explicit and record error
                        if str(existing_artifacts_by_path[np].kind) != str(da.kind):
                            errors.append(
                                "Autodetect conflict on path with different kind: "
                                f"path={da.path} explicit={existing_artifacts_by_path[np].kind} "
                                f"detected={da.kind}"
                            )
                        continue
                    existing_artifacts_by_path[np] = da
                    node.artifacts.append(da)

                for dc in disc_codebase:
                    np = self._normalize_path(dc.path)
                    if np in existing_codebase_by_path:
                        continue
                    existing_codebase_by_path[np] = dc
                    node.codebase.append(dc)

                # Inherit child rules for next nesting level
                for cr in child_rules:
                    next_inherited.append((cr, system_root_str))

            for child in node.children:
                if self._normalize_path(child.slug) in processed_children:
                    continue
                child_inherited = _expand_node(child, next_inherited)
                # Child's own next_inherited is not propagated to siblings
                _ = child_inherited

            return next_inherited

        for sys_node in self.systems:
            _expand_node(sys_node, [])

        self.rebuild_indices()
        return errors
    # @cpt-end:cpt-studio-algo-core-infra-registry-parsing:p1:inst-reg-expand-autodetect

    # === Pipeline Resolution ===
    PIPELINE_ORDER = ["PRD", "DESIGN", "ADR", "DECOMPOSITION", "FEATURE"]

    def resolve_pipeline(self, system_slug: str) -> dict:  # noqa: vulture
        """Resolve pipeline position for a system."""
        present_kinds: set = set()
        for art, node in self.iter_all_artifacts():
            if node.slug == system_slug or system_slug in node.get_hierarchy_prefix():
                present_kinds.add(str(art.kind).upper())

        missing_kinds = [k for k in self.PIPELINE_ORDER if k not in present_kinds]

        # (greenfield/brownfield detection deferred to agent workflow;
        #  resolve_pipeline returns missing kinds for agent to decide)

        recommendation = None
        for kind in missing_kinds:
            idx = self.PIPELINE_ORDER.index(kind)
            deps_satisfied = all(d in present_kinds for d in self.PIPELINE_ORDER[:idx])
            if deps_satisfied:
                recommendation = kind
                break

        if not missing_kinds:
            recommendation = "CODE"

        return {
            "present": sorted(present_kinds),
            "missing": missing_kinds,
            "recommendation": recommendation,
        }

    # @cpt-begin:cpt-studio-algo-core-infra-registry-parsing:p1:inst-reg-query-methods
    # === Kit Methods ===

    # === Artifact Methods ===

    def get_artifact_by_path(self, path: str) -> Optional[Tuple[Artifact, SystemNode]]:
        """Get artifact and its owning system by path."""
        normalized = self._normalize_path(path)
        return self._artifacts_by_path.get(normalized)

    def iter_all_artifacts(self) -> Iterator[Tuple[Artifact, SystemNode]]:
        """Iterate over all artifacts with their owning systems."""
        yield from self._artifacts_by_path.values()

    def iter_all_codebase(self) -> Iterator[Tuple["CodebaseEntry", SystemNode]]:
        """Iterate over all codebase entries with their owning systems."""
        def _iter_system(system: SystemNode) -> Iterator[Tuple["CodebaseEntry", SystemNode]]:
            for cb in system.codebase:
                if self.is_ignored(cb.path):
                    continue
                yield cb, system
            for child in system.children:
                yield from _iter_system(child)

        for system in self.systems:
            yield from _iter_system(system)

    def iter_all_system_prefixes(self) -> Iterator[str]:
        """Iterate over all system prefixes used in Studio IDs.

        Studio IDs are prefixed as: cpt-<system>-<kind>-<slug>

        Where <system> is the system node's slug hierarchy prefix (see
        SystemNode.get_hierarchy_prefix()). This differs from the human-facing
        system 'name'.
        """

        def _iter_system(node: SystemNode) -> Iterator[str]:
            try:
                prefix = node.get_hierarchy_prefix()
            except (ValueError, AttributeError) as exc:
                logger.warning("Failed to derive hierarchy prefix for system %s: %s", node.slug, exc)
                prefix = ""
            if prefix:
                yield prefix
            for child in node.children:
                yield from _iter_system(child)

        for system in self.systems:
            yield from _iter_system(system)

    def get_all_system_prefixes(self) -> set:
        """Get a set of all system prefixes (normalized to lowercase)."""
        return {p.lower() for p in self.iter_all_system_prefixes()}

    # @cpt-end:cpt-studio-algo-core-infra-registry-parsing:p1:inst-reg-query-methods

# @cpt-begin:cpt-studio-algo-core-infra-registry-parsing:p1:inst-reg-locate
# Pylint branch count is acceptable here because this loader intentionally
# centralizes the flat/legacy/config-path fallbacks and parse-time guards.
# pylint: disable=too-many-branches
def load_artifacts_meta(
    adapter_dir: Path,
) -> Tuple[Optional[ArtifactsMeta], Optional[str]]:
    """
    Load ArtifactsMeta from studio directory.

    Merges kits from core.toml into the registry before building ArtifactsMeta.

    Args:
        adapter_dir: Path to studio directory containing artifacts.toml and core.toml

    Returns:
        Tuple of (ArtifactsMeta or None, error message or None)
    """
    config_dir = adapter_dir / "config"
    # Try config/ subdir first, then legacy flat layout
    path = config_dir / ARTIFACTS_REGISTRY_FILENAME
    if not path.is_file():
        path = adapter_dir / ARTIFACTS_REGISTRY_FILENAME
    # Fallback: try legacy artifacts.json
    if not path.is_file():
        legacy = adapter_dir / "artifacts.json"
        if legacy.is_file():
            path = legacy
        else:
            return None, f"Missing artifacts registry: {config_dir / ARTIFACTS_REGISTRY_FILENAME}"
    # @cpt-end:cpt-studio-algo-core-infra-registry-parsing:p1:inst-reg-locate

    # @cpt-begin:cpt-studio-algo-core-infra-registry-parsing:p1:inst-reg-parse-merge
    try:
        if path.suffix == ".toml":
            with open(path, "rb") as f:
                data = tomllib.load(f)
        else:
            data = json.loads(path.read_text(encoding="utf-8"))

        if not isinstance(data, dict):
            return (
                None,
                (
                    f"Failed to load artifacts registry {path}: expected mapping "
                    f"at root, got {type(data).__name__}"
                ),
            )

        # Merge fields from core.toml into registry data (new layout)
        core_path = config_dir / "core.toml"
        if not core_path.is_file():
            core_path = adapter_dir / "core.toml"
        if core_path.is_file():
            with open(core_path, "rb") as f:
                core = tomllib.load(f)
            # version and project_root: core.toml is authoritative, artifacts.toml is fallback
            if isinstance(core.get("version"), str) and "version" not in data:
                data["version"] = core["version"]
            if isinstance(core.get("project_root"), str) and "project_root" not in data:
                data["project_root"] = core["project_root"]
            # kits: merge from core.toml, preserving registry-only fields while letting core override overlaps
            if isinstance(core.get("kits"), dict):
                data["kits"] = _merge_authoritative_core_kits(data.get("kits"), core["kits"])

        # @cpt-end:cpt-studio-algo-core-infra-registry-parsing:p1:inst-reg-parse-merge

        # @cpt-begin:cpt-studio-algo-core-infra-registry-parsing:p1:inst-reg-return
        # @cpt-begin:cpt-studio-algo-core-infra-registry-parsing:p1:inst-reg-build-meta
        meta = ArtifactsMeta.from_dict(data)
        return meta, None
        # @cpt-end:cpt-studio-algo-core-infra-registry-parsing:p1:inst-reg-build-meta
        # @cpt-end:cpt-studio-algo-core-infra-registry-parsing:p1:inst-reg-return
    except (OSError, ValueError, KeyError) as e:
        return None, f"Failed to load artifacts registry {path}: {e}"

# @cpt-begin:cpt-studio-algo-core-infra-registry-parsing:p1:inst-reg-utilities
def create_backup(path: Path) -> Optional[Path]:
    """Create a timestamped backup of a file or directory.

    Args:
        path: Path to file or directory to backup

    Returns:
        Path to backup if created, None otherwise
    """
    if not path.exists():
        return None

    from datetime import datetime
    import shutil

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup_name = f"{path.name}.{timestamp}.backup"
    backup_path = path.parent / backup_name

    try:
        if path.is_dir():
            shutil.copytree(path, backup_path)
        else:
            shutil.copy2(path, backup_path)
        return backup_path
    except OSError as exc:
        logger.warning("Failed to create backup for %s: %s", path, exc)
        return None

def extract_system_slug_candidates(cpt_id: str, parent_prefix: str, kind_tokens: Set[str]) -> List[str]:
    """Extract system slug candidates from a cpt ID.

    Scans left-to-right for the first ``-{kind}-`` marker among *kind_tokens*.
    IDs that contain more than one distinct kind token are considered ambiguous
    and discarded (returns ``[]``).

    ID format: cpt-{parent_prefix}-{system_slug}-{kind}-{rest}
    or if no parent prefix: cpt-{system_slug}-{kind}-{rest}

    Returns:
        A single-element list ``[slug]`` when exactly one kind token is found,
        or ``[]`` when the ID is ambiguous or contains no kind token.
    """
    if not cpt_id.startswith("cpt-"):
        return []
    remainder = cpt_id[4:]  # Remove "cpt-"
    if parent_prefix:
        expected = parent_prefix + "-"
        if not remainder.startswith(expected):
            return []
        remainder = remainder[len(expected):]
    # remainder: {system_slug}-{kind}-{rest}
    # 1. Find ALL kind tokens that appear as `-{kind}-` anywhere in remainder.
    matched_kinds: Set[str] = set()
    first_pos: Optional[int] = None
    for kind in kind_tokens:
        marker = f"-{kind}-"
        idx = remainder.find(marker)
        if idx < 0:
            continue
        matched_kinds.add(kind)
        if first_pos is None or idx < first_pos:
            first_pos = idx
    # 2. Discard if zero or more than one distinct kind token matched.
    if len(matched_kinds) != 1 or first_pos is None or not first_pos:
        return []
    slug = remainder[:first_pos]
    return [slug]

def generate_slug(name: str) -> str:
    """Generate a valid slug from a name.

    Converts to lowercase, replaces non-alphanumeric chars with hyphens,
    removes leading/trailing hyphens.

    Args:
        name: Human-readable name

    Returns:
        Valid slug string
    """
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    # Collapse multiple hyphens
    slug = re.sub(r"-+", "-", slug)
    return slug if slug else "unnamed"

def generate_default_registry(
    project_name: str,
    kit_slug: str = "sdlc",
    codebase: Optional[List[Dict[str, object]]] = None,
) -> dict:
    """Generate default artifacts.toml registry for a new project.

    Args:
        project_name: Name of the project (used as system name)
        kit_slug: Slug of the kit to assign to the root system
        codebase: Detected source roots to register. Omitted or empty leaves
            ``codebase = []``, which scans nothing -- callers that can detect
            roots should pass them, and say so when they find none.

    Returns:
        Dictionary with the default registry structure.
        Note: version, project_root, and kits are defined in core.toml, not here.
    """
    return {
        "systems": [
            {
                "name": project_name,
                "slug": generate_slug(project_name),
                "kit": kit_slug,
                "artifacts": [],
                "codebase": list(codebase or []),
                "children": [],
            },
        ],
    }
# @cpt-end:cpt-studio-algo-core-infra-registry-parsing:p1:inst-reg-utilities

__all__ = [
    "ArtifactsMeta",
    "SystemNode",
    "Artifact",
    "IgnoreBlock",
    "AutodetectRule",
    "AutodetectArtifactPattern",
    "CodebaseEntry",
    "Kit",
    "SLUG_PATTERN",
    "load_artifacts_meta",
    "create_backup",
    "generate_default_registry",
    "generate_slug",
]
