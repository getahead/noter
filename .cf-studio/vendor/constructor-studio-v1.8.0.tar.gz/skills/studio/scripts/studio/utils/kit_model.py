"""Normalized kit package model and canonical manifest conversion."""

from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Any, Dict, List, Optional

from . import toml_utils
from ._tomllib_compat import tomllib
from .manifest import AgentEntry, ComponentEntry, Manifest, ManifestResource, ManifestV2, load_manifest

logger = logging.getLogger(__name__)

_CANONICAL_MANIFEST = ".cf-studio-kit.toml"
_CANONICAL_MANIFEST_VERSION = "1.0"
_SUPPORTED_CANONICAL_MANIFEST_VERSIONS = {_CANONICAL_MANIFEST_VERSION}
_LEGACY_CONTENT_DIRS = ("artifacts", "codebase", "scripts", "workflows")
_LEGACY_CONTENT_FILES = ("constraints.toml", "SKILL.md", "AGENTS.md")
_PUBLIC_KINDS = {"skill", "agent", "rule"}
_SUPPORTING_KINDS = {
    "template",
    "checklist",
    "constraints",
    "script",
    "directory",
    "other",
}
_LEGACY_KIND_ALIASES = {"workflow": "skill"}
_LEGACY_MANIFEST_DEPRECATION_WARNING = (
    "legacy manifest.toml is supported for migration; publish "
    ".cf-studio-kit.toml for new kits"
)
_LEGACY_LAYOUT_DEPRECATION_WARNING = (
    "layout-only kit discovery is supported for migration; publish "
    ".cf-studio-kit.toml for new kits"
)
_LEGACY_WORKFLOW_DEPRECATION_WARNING = (
    "legacy workflow resources are normalized to public skill resources; "
    "use kind = \"skill\" in .cf-studio-kit.toml"
)
_UPDATE_CFS_HINT = "Update Constructor Studio with `pipx upgrade constructor-studio` and retry."
_EMPTY_TEXT = ""
_DEFAULT_ROLE = "any"
_DEFAULT_TARGET = "any"
_DEFAULT_PROVIDER = "anthropic"
_DEFAULT_MODE = "readwrite"
_NO_POLICY_OVERRIDE = None


# @cpt-begin:cpt-studio-algo-kit-manifest-install:p1:inst-manifest-datamodel
@dataclass(frozen=True)
class KitResource:
    """A normalized resource declared by a kit package."""

    id: str
    kind: str
    source: str
    install_path: str
    type: str
    public: bool = False
    description: str = ""
    user_modifiable: bool = True
    aliases: List[str] = field(default_factory=list)
    generated_targets: List[str] = field(default_factory=list)
    origin: str = ""
    generated_name: str = ""
    prefix_generated_name: bool = True
    content_hash: str = ""
    tools: List[str] = field(default_factory=list)
    disallowed_tools: List[str] = field(default_factory=list)
    mode: str = "readwrite"
    isolation: bool = False
    model: str = ""
    # Agent/runtime policy fields.
    skills: List[str] = field(default_factory=list)
    color: str = _EMPTY_TEXT
    memory_dir: str = _EMPTY_TEXT
    role: str = _DEFAULT_ROLE
    target: str = _DEFAULT_TARGET
    provider: str = _DEFAULT_PROVIDER
    reasoning_effort: Optional[str] = _NO_POLICY_OVERRIDE
    context_window: Optional[str] = _NO_POLICY_OVERRIDE
    subagents: List[Dict[str, Any]] = field(default_factory=list)
    target_configs: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    artifact_bindings: Dict[str, Dict[str, str]] = field(default_factory=dict)


@dataclass(frozen=True)
class PublicComponent:
    """A public skill, agent, or rule exposed by a normalized kit."""

    id: str
    kind: str
    source: str
    generated_name: str
    description: str = ""
    generated_targets: List[str] = field(default_factory=list)
    aliases: List[str] = field(default_factory=list)
    origin: str = ""
    tools: List[str] = field(default_factory=list)
    disallowed_tools: List[str] = field(default_factory=list)
    mode: str = "readwrite"
    isolation: bool = False
    model: str = ""
    # Agent/runtime policy fields.
    skills: List[str] = field(default_factory=list)
    color: str = _EMPTY_TEXT
    memory_dir: str = _EMPTY_TEXT
    role: str = _DEFAULT_ROLE
    target: str = _DEFAULT_TARGET
    provider: str = _DEFAULT_PROVIDER
    reasoning_effort: Optional[str] = _NO_POLICY_OVERRIDE
    context_window: Optional[str] = _NO_POLICY_OVERRIDE
    subagents: List[Dict[str, Any]] = field(default_factory=list)
    target_configs: Dict[str, Dict[str, Any]] = field(default_factory=dict)


@dataclass(frozen=True)
class KitModel:
    """Normalized kit metadata and resources."""

    slug: str
    name: str
    version: str
    manifest_source: str
    resources: List[KitResource] = field(default_factory=list)
    public_components: List[PublicComponent] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    manifest_bytes_hash: str = ""
    resource_hashes: Dict[str, str] = field(default_factory=dict)
    tool_risk_fingerprint: str = ""
    tool_risk_summary: Dict[str, Any] = field(default_factory=dict)
# @cpt-end:cpt-studio-algo-kit-manifest-install:p1:inst-manifest-datamodel


def _require_string(data: Dict[str, Any], key: str, context: str) -> str:
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-resource-shape
    value = data.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{context}: missing or invalid string field '{key}'")
    return value.strip()
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-resource-shape


def _optional_string(data: Dict[str, Any], key: str) -> str:
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-metadata
    value = data.get(key, "")
    if value is None:
        return ""
    if not isinstance(value, str):
        raise ValueError(f"Field '{key}' must be a string")
    return value.strip()
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-metadata


def _string_list(value: Any, field_name: str) -> List[str]:
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-resource-shape
    if value is None:
        return []
    if not isinstance(value, list):
        raise ValueError(f"Field '{field_name}' must be a list of strings")
    result: List[str] = []
    for item in value:
        if not isinstance(item, str):
            raise ValueError(f"Field '{field_name}' must be a list of strings")
        cleaned = item.strip()
        if cleaned:
            result.append(cleaned)
    return result
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-resource-shape


def _config_string(raw: Dict[str, Any], agent_config: Dict[str, Any], key: str, default: str = "") -> str:
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-agent-fields
    value = agent_config.get(key, raw.get(key, default))
    if value is None:
        return ""
    if not isinstance(value, str):
        raise ValueError(f"Field '{key}' must be a string")
    return value.strip()
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-agent-fields


def _config_optional_string(raw: Dict[str, Any], agent_config: Dict[str, Any], key: str) -> Optional[str]:
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-agent-fields
    value = agent_config.get(key, raw.get(key))
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(f"Field '{key}' must be a string")
    cleaned = value.strip()
    return cleaned or None
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-agent-fields


def _config_bool(raw: Dict[str, Any], agent_config: Dict[str, Any], key: str, default: bool = False) -> bool:
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-agent-fields
    value = agent_config.get(key, raw.get(key, default))
    if not isinstance(value, bool):
        raise ValueError(f"Field '{key}' must be a boolean")
    return value
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-agent-fields


def _optional_bool(data: Dict[str, Any], key: str, default: bool = True) -> bool:
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-resource-shape
    value = data.get(key, default)
    if not isinstance(value, bool):
        raise ValueError(f"Field '{key}' must be a boolean")
    return value
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-resource-shape


# @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-agent-fields
def _config_string_list(raw: Dict[str, Any], agent_config: Dict[str, Any], key: str, field_name: str) -> List[str]:
    return _string_list(agent_config.get(key, raw.get(key)), field_name)
# @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-agent-fields


def _config_subagents(raw: Dict[str, Any], agent_config: Dict[str, Any], field_name: str) -> List[Dict[str, Any]]:
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-subagent-config
    value = agent_config.get("subagents", raw.get("subagents"))
    if value is None:
        return []
    if not isinstance(value, list):
        raise ValueError(f"Field '{field_name}' must be a list of tables")
    result: List[Dict[str, Any]] = []
    for idx, item in enumerate(value):
        if not isinstance(item, dict):
            raise ValueError(f"Field '{field_name}[{idx}]' must be a table")
        result.append(dict(item))
    return result
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-subagent-config


def _config_table(raw: Dict[str, Any], key: str, field_name: str) -> Dict[str, Dict[str, Any]]:
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-agent-config
    value = raw.get(key)
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ValueError(f"Field '{field_name}' must be a table")
    result: Dict[str, Dict[str, Any]] = {}
    for name, item in value.items():
        if not isinstance(item, dict):
            raise ValueError(f"Field '{field_name}.{name}' must be a table")
        result[str(name)] = dict(item)
    return result
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-agent-config


def _artifact_bindings(value: Any, field_name: str) -> Dict[str, Dict[str, str]]:
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-artifact-bindings
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ValueError(f"Field '{field_name}' must be a table")
    result: Dict[str, Dict[str, str]] = {}
    allowed = {"template", "rules", "checklist", "example", "examples"}
    for kind, raw_binding in value.items():
        kind_s = str(kind).strip().upper()
        if not kind_s:
            raise ValueError(f"Field '{field_name}' contains an empty artifact kind")
        if not isinstance(raw_binding, dict):
            raise ValueError(f"Field '{field_name}.{kind_s}' must be a table")
        item: Dict[str, str] = {}
        for key, raw_value in raw_binding.items():
            key_s = str(key).strip()
            if key_s not in allowed:
                raise ValueError(
                    f"Field '{field_name}.{kind_s}.{key_s}' is unsupported; expected one of {sorted(allowed)}",
                )
            if not isinstance(raw_value, str) or not raw_value.strip():
                raise ValueError(f"Field '{field_name}.{kind_s}.{key_s}' must be a non-empty string")
            item["examples" if key_s == "example" else key_s] = raw_value.strip()
        if item:
            result[kind_s] = item
    return result
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-artifact-bindings


def _normalize_kind(kind: str, *, warnings: List[str], resource_id: str) -> str:
    cleaned = kind.strip().lower()
    # @cpt-begin:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-workflow-to-skill
    if cleaned in _LEGACY_KIND_ALIASES:
        warnings.append(
            f"Resource '{resource_id}' uses legacy kind '{cleaned}', normalized to 'skill'",
        )
        cleaned = _LEGACY_KIND_ALIASES[cleaned]
    # @cpt-end:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-workflow-to-skill
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-resource-kinds
    valid = _PUBLIC_KINDS | _SUPPORTING_KINDS
    if cleaned not in valid:
        raise ValueError(
            f"Resource '{resource_id}': invalid kind '{kind}', expected one of "
            f"{sorted(valid | set(_LEGACY_KIND_ALIASES))}",
        )
    normalized = cleaned
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-resource-kinds
    return normalized


def _normalize_public_name(slug: str, resource_id: str) -> str:
    # @cpt-begin:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-prefix-public-names
    prefix = f"cf-{slug}-"
    if resource_id == f"cf-{slug}" or resource_id.startswith(prefix):
        generated_name = resource_id
    else:
        generated_name = f"{prefix}{resource_id}"
    # @cpt-end:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-prefix-public-names
    return generated_name


def _frontmatter_name(path: Path) -> str:
    """Return YAML frontmatter ``name`` from a markdown file, if present."""
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-public-name-prefix
    try:
        content = path.read_text(encoding="utf-8").lstrip("\ufeff")
    except (OSError, UnicodeDecodeError) as exc:
        logger.warning("Failed to read frontmatter from %s: %s", path, exc)
        return ""
    if content.startswith("---\r\n"):
        start_len = 5
        end = content.find("\r\n---", start_len)
    elif content.startswith("---\n"):
        start_len = 4
        end = content.find("\n---", start_len)
    else:
        return ""
    if end == -1:
        return ""
    for line in content[start_len:end].splitlines():
        key, sep, value = line.partition(":")
        if sep and key.strip() == "name":
            return value.strip().strip("'\"")
    return ""
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-public-name-prefix


# @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-any-layout
def _resolved_source_path_within_kit(kit_source: Path, source: str) -> Optional[Path]:
    source_path = PurePosixPath(source)
    if source_path.is_absolute() or ".." in source_path.parts:
        return None
    resolved = (kit_source / source).resolve()
    resolved_root = kit_source.resolve()
    if not resolved.is_relative_to(resolved_root):
        logger.warning(
            "Resolved kit source path escapes kit root: %s not under %s",
            resolved,
            resolved_root,
        )
        return None
    return resolved
# @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-any-layout


# @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-public-name-prefix
def _public_name_from_source(
    kit_source: Path,
    source: str,
    kind: str,
    resource_id: str = "",
) -> str:
    """Return an implicit public component name derived from source content."""
    if kind not in _PUBLIC_KINDS:
        return ""
    source_path = _resolved_source_path_within_kit(kit_source, source)
    if source_path is None:
        return ""
    if not source_path.is_file():
        return ""
    frontmatter_name = _frontmatter_name(source_path)
    if frontmatter_name:
        return frontmatter_name
    if kind == "agent":
        return resource_id.strip()
    return ""
# @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-public-name-prefix


def _resource_generated_name(
    slug: str,
    public: bool,
    prefix_generated_name: bool,
    implicit_generated_name: str = "",
) -> str:
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-public-name-prefix
    generated_name = ""
    if public:
        base_name = implicit_generated_name.strip()
        if not base_name:
            return ""
        generated_name = base_name if not prefix_generated_name else _normalize_public_name(slug, base_name)
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-public-name-prefix
    return generated_name


def _warn_unknown_keys(
    data: Dict[str, Any],
    allowed: set[str],
    context: str,
    warnings: List[str],
) -> None:
    # @cpt-begin:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-warnings
    for key in sorted(set(data) - allowed):
        warnings.append(f"{context}: unknown optional field '{key}' ignored")
    # @cpt-end:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-warnings


def _validate_relative_source(kit_source: Path, resource: KitResource) -> None:
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-any-layout
    source_path = PurePosixPath(resource.source)
    if source_path.is_absolute() or ".." in source_path.parts:
        raise ValueError(
            f"Resource '{resource.id}': source '{resource.source}' must be a relative path inside the kit root",
        )
    actual = (kit_source / resource.source).resolve()
    try:
        actual.relative_to(kit_source.resolve())
    except ValueError as exc:
        raise ValueError(
            f"Resource '{resource.id}': source '{resource.source}' escapes the kit root",
        ) from exc
    if not actual.exists():
        raise ValueError(
            f"Resource '{resource.id}': source path '{resource.source}' does not exist",
        )
    if resource.type == "file" and not actual.is_file():
        raise ValueError(
            f"Resource '{resource.id}': type is 'file' but source is not a file",
        )
    if resource.type == "directory" and not actual.is_dir():
        raise ValueError(
            f"Resource '{resource.id}': type is 'directory' but source is not a directory",
        )
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-any-layout


def _validate_install_path(resource: KitResource) -> None:
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-resource-shape
    install_path = PurePosixPath(resource.install_path)
    if install_path.is_absolute() or ".." in install_path.parts:
        raise ValueError(
            f"Resource '{resource.id}': install_path '{resource.install_path}' "
            "must be relative and must not contain '..'",
        )
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-resource-shape


_HASH_EXCLUDED_DIRS = {
    ".git",
    ".hg",
    ".svn",
    "__pycache__",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
}


# @cpt-begin:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-hashes
def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()
# @cpt-end:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-hashes


def _resource_content_hash(kit_source: Path, resource: KitResource) -> str:
    # @cpt-begin:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-hashes
    source_path = kit_source / resource.source
    if resource.type == "file":
        return _sha256_bytes(source_path.read_bytes())
    # @cpt-end:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-hashes

    # @cpt-begin:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-directory-hash
    entries: List[Dict[str, str]] = []
    for fpath in sorted(source_path.rglob("*")):
        rel_parts = fpath.relative_to(source_path).parts
        if any(part in _HASH_EXCLUDED_DIRS for part in rel_parts):
            continue
        if fpath.is_file():
            entries.append({
                "path": PurePosixPath(*rel_parts).as_posix(),
                "sha256": _sha256_bytes(fpath.read_bytes()),
            })
    return _sha256_bytes(
        json.dumps(entries, sort_keys=True, separators=(",", ":")).encode("utf-8"),
    )
    # @cpt-end:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-directory-hash


def _semantic_resource_data(resource: KitResource) -> Dict[str, Any]:
    # @cpt-begin:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-resource-id-vs-generated-name
    data = {
        "id": resource.id,
        "kind": resource.kind,
        "source": resource.source,
        "install_path": resource.install_path,
        "type": resource.type,
        "public": resource.public,
        "description": resource.description,
        "user_modifiable": resource.user_modifiable,
        "aliases": resource.aliases,
        "generated_targets": resource.generated_targets,
        "origin": resource.origin,
        "generated_name": resource.generated_name,
        "prefix_generated_name": resource.prefix_generated_name,
        "tools": resource.tools,
        "disallowed_tools": resource.disallowed_tools,
        "mode": resource.mode,
        "isolation": resource.isolation,
        "model": resource.model,
        "skills": resource.skills,
        "color": resource.color,
        "memory_dir": resource.memory_dir,
        "role": resource.role,
        "target": resource.target,
        "provider": resource.provider,
        "reasoning_effort": resource.reasoning_effort,
        "context_window": resource.context_window,
        "subagents": resource.subagents,
        "target_configs": resource.target_configs,
        "artifact_bindings": resource.artifact_bindings,
    }
    # @cpt-end:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-resource-id-vs-generated-name
    return data


_KNOWN_TOOLS = {
    "*",
    "bash",
    "edit",
    "glob",
    "grep",
    "multiedit",
    "read",
    "search",
    "shell",
    "task",
    "view",
    "webfetch",
    "websearch",
    "write",
}
_DANGEROUS_TOOLS = {
    "*",
    "bash",
    "edit",
    "multiedit",
    "shell",
    "task",
    "webfetch",
    "websearch",
    "write",
}


# @cpt-begin:cpt-studio-algo-kit-tool-permission-risk:p1:inst-risk-dangerous-summary
def _tool_key(tool: str) -> str:
    return tool.strip().lower()
# @cpt-end:cpt-studio-algo-kit-tool-permission-risk:p1:inst-risk-dangerous-summary


# @cpt-begin:cpt-studio-algo-kit-tool-permission-risk:p1:inst-risk-unknown-tools-warn
# @cpt-begin:cpt-studio-algo-kit-tool-permission-risk:p1:inst-risk-dangerous-summary
def _tool_risk_summary(resources: List[KitResource], warnings: List[str]) -> Dict[str, Any]:
    unknown_tools: Dict[str, List[str]] = {}
    dangerous_tools: Dict[str, List[str]] = {}
    declared_tools: Dict[str, List[str]] = {}
    for resource in resources:
        tools = sorted({tool.strip() for tool in resource.tools if tool.strip()})
        if not tools:
            continue
        declared_tools[resource.id] = tools
        for tool in tools:
            key = _tool_key(tool)
            if key not in _KNOWN_TOOLS and not key.startswith("mcp__"):
                unknown_tools.setdefault(resource.id, []).append(tool)
                warnings.append(
                    f"Resource '{resource.id}' declares unknown tool '{tool}', accepted with warning",
                )
            if key in _DANGEROUS_TOOLS or key.startswith("mcp__"):
                dangerous_tools.setdefault(resource.id, []).append(tool)
    return {
        "declared_tools": declared_tools,
        "dangerous_tools": {key: sorted(value) for key, value in sorted(dangerous_tools.items())},
        "unknown_tools": {key: sorted(value) for key, value in sorted(unknown_tools.items())},
        "requires_confirmation": bool(dangerous_tools),
    }
# @cpt-end:cpt-studio-algo-kit-tool-permission-risk:p1:inst-risk-dangerous-summary
# @cpt-end:cpt-studio-algo-kit-tool-permission-risk:p1:inst-risk-unknown-tools-warn


def _public_components(resources: List[KitResource]) -> List[PublicComponent]:
    # @cpt-begin:cpt-studio-algo-kit-manifest-install:p1:inst-manifest-collect-meta
    # @cpt-begin:cpt-studio-algo-kit-manifest-install:p1:inst-manifest-public-rule-gen-boundary
    # @cpt-begin:cpt-studio-algo-kit-public-component-generation:p1:inst-public-generate-from-kitmodel
    return [
        PublicComponent(
            id=resource.id,
            kind=resource.kind,
            source=resource.source,
            generated_name=resource.generated_name,
            description=resource.description,
            generated_targets=resource.generated_targets or ["installed"],
            aliases=resource.aliases,
            origin=resource.origin,
            tools=resource.tools,
            disallowed_tools=resource.disallowed_tools,
            mode=resource.mode,
            isolation=resource.isolation,
            model=resource.model,
            skills=resource.skills,
            color=resource.color,
            memory_dir=resource.memory_dir,
            role=resource.role,
            target=resource.target,
            provider=resource.provider,
            reasoning_effort=resource.reasoning_effort,
            context_window=resource.context_window,
            subagents=resource.subagents,
            target_configs=resource.target_configs,
        )
        for resource in resources
        if resource.public and resource.kind in _PUBLIC_KINDS
    ]
    # @cpt-end:cpt-studio-algo-kit-public-component-generation:p1:inst-public-generate-from-kitmodel
    # @cpt-end:cpt-studio-algo-kit-manifest-install:p1:inst-manifest-public-rule-gen-boundary
    # @cpt-end:cpt-studio-algo-kit-manifest-install:p1:inst-manifest-collect-meta


def _with_hashes(kit_source: Path, model: KitModel) -> KitModel:
    # @cpt-begin:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-hashes
    resource_hashes = {
        resource.id: _resource_content_hash(kit_source, resource)
        for resource in model.resources
    }
    resources = [
        KitResource(
            id=resource.id,
            kind=resource.kind,
            source=resource.source,
            install_path=resource.install_path,
            type=resource.type,
            public=resource.public,
            description=resource.description,
            user_modifiable=resource.user_modifiable,
            aliases=resource.aliases,
            generated_targets=resource.generated_targets,
            origin=resource.origin,
            generated_name=resource.generated_name,
            prefix_generated_name=resource.prefix_generated_name,
            content_hash=resource_hashes[resource.id],
            tools=resource.tools,
            disallowed_tools=resource.disallowed_tools,
            mode=resource.mode,
            isolation=resource.isolation,
            model=resource.model,
            skills=resource.skills,
            color=resource.color,
            memory_dir=resource.memory_dir,
            role=resource.role,
            target=resource.target,
            provider=resource.provider,
            reasoning_effort=resource.reasoning_effort,
            context_window=resource.context_window,
            subagents=resource.subagents,
            target_configs=resource.target_configs,
            # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-artifact-bindings
            artifact_bindings=resource.artifact_bindings,
            # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-artifact-bindings
        )
        for resource in model.resources
    ]
    risk_summary = _tool_risk_summary(resources, model.warnings)
    semantic_data = {
        "slug": model.slug,
        "name": model.name,
        "version": model.version,
        "manifest_source": model.manifest_source,
        "resources": [_semantic_resource_data(resource) for resource in resources],
    }
    manifest_path = kit_source / _CANONICAL_MANIFEST
    manifest_bytes_hash = (
        _sha256_bytes(manifest_path.read_bytes())
        if manifest_path.is_file()
        else _sha256_bytes(json.dumps(semantic_data, sort_keys=True).encode("utf-8"))
    )
    return KitModel(
        slug=model.slug,
        name=model.name,
        version=model.version,
        manifest_source=model.manifest_source,
        resources=resources,
        public_components=_public_components(resources),
        warnings=model.warnings,
        manifest_bytes_hash=manifest_bytes_hash,
        resource_hashes=resource_hashes,
        tool_risk_fingerprint=_sha256_bytes(
            json.dumps(risk_summary, sort_keys=True, separators=(",", ":")).encode("utf-8"),
        ),
        tool_risk_summary=risk_summary,
    )
    # @cpt-end:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-hashes


def _canonical_model_from_entry(
    kit_source: Path,
    meta: Dict[str, Any],
    raw_resources: Any,
    *,
    kit_context: str,
    resources_context: str,
) -> KitModel:
    warnings: List[str] = []
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-metadata
    _warn_unknown_keys(
        meta,
        {
            "slug", "name", "version", "description", "source", "targets",
            "defaults", "compatibility", "resources",
        },
        kit_context,
        warnings,
    )
    slug = _require_string(meta, "slug", kit_context)
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-metadata

    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-resource-shape
    if not isinstance(raw_resources, list):
        raise ValueError(f"{_CANONICAL_MANIFEST}: {resources_context} must be an array of tables")
    resources: List[KitResource] = []
    seen_ids: set[str] = set()
    for idx, raw in enumerate(raw_resources):
        if not isinstance(raw, dict):
            raise ValueError(f"{_CANONICAL_MANIFEST}: {resources_context}[{idx}] must be a table")
        resource_context = f"{resources_context}[{idx}]"
        resource_id = _require_string(raw, "id", resource_context)
        if resource_id in seen_ids:
            raise ValueError(f"Duplicate resource id '{resource_id}' in kit '{slug}'")
        seen_ids.add(resource_id)
        # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-no-binding-path
        if "binding_path" in raw:
            raise ValueError(
                f"Resource '{resource_id}': binding_path is installed state and "
                f"is not allowed in {_CANONICAL_MANIFEST}",
            )
        # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-no-binding-path
        _warn_unknown_keys(
            raw,
            {
                "id", "kind", "source", "install_path", "type", "public",
                "description", "user_modifiable", "aliases", "generated_targets",
                "origin", "prefix_generated_name", "agent", "targets", "permissions",
                "tools", "disallowed_tools", "mode", "isolation", "model",
                "skills", "color", "memory_dir", "role", "target", "provider",
                "reasoning_effort", "context_window", "subagents", "artifacts",
            },
            resource_context,
            warnings,
        )
        resource = _canonical_resource_from_raw(
            kit_source=kit_source,
            slug=slug,
            raw=raw,
            resource_context=resource_context,
            resource_id=resource_id,
            warnings=warnings,
        )
        _validate_relative_source(kit_source, resource)
        _validate_install_path(resource)
        resources.append(resource)
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-resource-shape

    return _with_hashes(
        kit_source,
        KitModel(
            slug=slug,
            name=_optional_string(meta, "name") or slug,
            version=_optional_string(meta, "version"),
            manifest_source="canonical",
            resources=resources,
            warnings=warnings,
        ),
    )


def _validate_canonical_manifest_version(data: Dict[str, Any]) -> None:
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-version-gate
    raw_version = data.get("manifest_version")
    if not isinstance(raw_version, str) or not raw_version.strip():
        raise ValueError(
            f"{_CANONICAL_MANIFEST}: missing required manifest_version. {_UPDATE_CFS_HINT}",
        )
    version = raw_version.strip()
    if version not in _SUPPORTED_CANONICAL_MANIFEST_VERSIONS:
        supported = ", ".join(sorted(_SUPPORTED_CANONICAL_MANIFEST_VERSIONS))
        raise ValueError(
            f"{_CANONICAL_MANIFEST}: unsupported manifest_version '{version}' "
            f"(supported: {supported}). {_UPDATE_CFS_HINT}",
        )
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-version-gate


# @cpt-algo:cpt-studio-algo-kit-canonical-manifest:p1
def load_canonical_kit_models(kit_source: Path) -> List[KitModel]:
    """Load all kits from ``.cf-studio-kit.toml`` when present."""
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-any-layout
    manifest_path = kit_source / _CANONICAL_MANIFEST
    if not manifest_path.is_file():
        return []
    try:
        data = toml_utils.load(manifest_path)
    except tomllib.TOMLDecodeError as exc:
        raise ValueError(f"Invalid {_CANONICAL_MANIFEST}: {exc}") from exc
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-any-layout

    _validate_canonical_manifest_version(data)
    raw_kits = data.get("kits")
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-multi-kit
    if data.get("kit") is not None or data.get("resources") is not None:
        raise ValueError(
            f"{_CANONICAL_MANIFEST}: canonical manifests must use [[kits]] with nested [[kits.resources]]",
        )
    if not isinstance(raw_kits, list) or not raw_kits:
        raise ValueError(f"{_CANONICAL_MANIFEST}: [[kits]] must be a non-empty array of tables")
    models = [
        _canonical_model_from_entry(
            kit_source,
            raw_kit,
            raw_kit.get("resources", []) if isinstance(raw_kit, dict) else None,
            kit_context=f"[[kits]][{idx}]",
            resources_context=f"[[kits]][{idx}].resources",
        )
        for idx, raw_kit in enumerate(raw_kits)
        if isinstance(raw_kit, dict)
    ]
    if len(models) != len(raw_kits):
        raise ValueError(f"{_CANONICAL_MANIFEST}: every [[kits]] entry must be a table")
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-multi-kit

    seen_slugs: set[str] = set()
    for model in models:
        if model.slug in seen_slugs:
            raise ValueError(f"{_CANONICAL_MANIFEST}: duplicate kit slug '{model.slug}'")
        seen_slugs.add(model.slug)
    return models


def load_canonical_kit_model(kit_source: Path, kit_slug: str = "") -> Optional[KitModel]:
    """Load one kit from ``.cf-studio-kit.toml`` from *kit_source* when present."""
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-multi-kit
    # @cpt-begin:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-select-kit
    models = load_canonical_kit_models(kit_source)
    if not models:
        return None
    if kit_slug:
        for model in models:
            if model.slug == kit_slug:
                return model
        available = ", ".join(model.slug for model in models)
        raise ValueError(f"{_CANONICAL_MANIFEST}: kit '{kit_slug}' not found; available kits: {available}")
    if len(models) > 1:
        available = ", ".join(model.slug for model in models)
        raise ValueError(f"{_CANONICAL_MANIFEST}: contains multiple kits: {available}; choose one with --kit")
    return models[0]
    # @cpt-end:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-select-kit
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-multi-kit


def _read_conf_metadata(kit_source: Path) -> tuple[str, str]:
    # @cpt-begin:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-precedence
    conf_path = kit_source / "conf.toml"
    if not conf_path.is_file():
        return "", ""
    try:
        data = toml_utils.load(conf_path)
    except (OSError, tomllib.TOMLDecodeError) as exc:
        logger.warning("Failed to read kit metadata from %s: %s", conf_path, exc)
        return "", ""
    slug = data.get("slug", "")
    version = data.get("version", "")
    return (
        str(slug).strip() if slug else "",
        str(version).strip() if version else "",
    )
    # @cpt-end:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-precedence


def _resource_kind_from_path(source: str, resource_id: str) -> str:
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-resource-kinds
    source_name = Path(source).name
    normalized_id = resource_id.strip().lower()
    special_kinds = (
        ("constraints", normalized_id == "constraints" or source_name == "constraints.toml"),
        ("skill", source == "SKILL.md" or resource_id == "workflows" or source.startswith("workflows/")),
        ("rule", source == "AGENTS.md"),
        ("template", source.endswith("template.md")),
        ("checklist", source.endswith("checklist.md")),
        ("script", source.startswith("scripts/")),
    )
    for kind, matches in special_kinds:
        if matches:
            return kind
    return "directory" if "." not in Path(source).name else "other"
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-resource-kinds


def _canonical_resource_from_raw(
    *,
    kit_source: Path,
    slug: str,
    raw: Dict[str, Any],
    resource_context: str,
    resource_id: str,
    warnings: List[str],
) -> KitResource:
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-resource-shape
    agent_config = raw.get("agent") if isinstance(raw.get("agent"), dict) else {}
    if isinstance(agent_config, dict):
        _warn_unknown_keys(
            agent_config,
            {
                "mode", "isolation", "model", "tools", "disallowed_tools",
                "skills", "color", "memory_dir", "role", "target",
                "provider", "reasoning_effort", "context_window",
                "subagents",
            },
            f"{resource_context}.agent",
            warnings,
        )
    kind = _normalize_kind(
        _require_string(raw, "kind", resource_context),
        warnings=warnings,
        resource_id=resource_id,
    )
    source = _require_string(raw, "source", resource_context)
    resource_type = _optional_string(raw, "type") or "file"
    if resource_type not in {"file", "directory"}:
        raise ValueError(
            f"Resource '{resource_id}': type must be 'file' or 'directory'",
        )
    public = _optional_bool(raw, "public", kind in _PUBLIC_KINDS)
    prefix_generated_name = _optional_bool(raw, "prefix_generated_name", True)
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-generated-targets
    generated_targets = _string_list(raw.get("generated_targets"), "generated_targets")
    if public and kind not in _PUBLIC_KINDS:
        raise ValueError(
            f"Resource '{resource_id}': public=true is only allowed for skill, agent, and rule resources",
        )
    if not public and not prefix_generated_name:
        raise ValueError(
            f"Resource '{resource_id}': prefix_generated_name=false is only allowed for public resources",
        )
    if not public and generated_targets:
        raise ValueError(
            f"Resource '{resource_id}': generated_targets is only allowed for public resources",
        )
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-generated-targets
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-resource-shape
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-agent-config
    artifact_bindings = _artifact_bindings(raw.get("artifacts"), f"resources.{resource_id}.artifacts")
    if artifact_bindings and kind != "constraints":
        raise ValueError(
            f"Resource '{resource_id}': artifacts bindings are only allowed for constraints resources",
        )
    permissions_config = raw.get("permissions") if isinstance(raw.get("permissions"), dict) else {}
    return KitResource(
        id=resource_id,
        kind=kind,
        source=source,
        install_path=_optional_string(raw, "install_path") or source,
        type=resource_type,
        public=public,
        description=_optional_string(raw, "description"),
        user_modifiable=_optional_bool(raw, "user_modifiable", True),
        aliases=_string_list(raw.get("aliases"), "aliases"),
        # @cpt-begin:cpt-studio-algo-kit-manifest-install:p1:inst-manifest-default-path
        generated_targets=generated_targets or (["installed"] if public else []),
        # @cpt-end:cpt-studio-algo-kit-manifest-install:p1:inst-manifest-default-path
        origin=_optional_string(raw, "origin"),
        generated_name=_resource_generated_name(
            slug,
            public,
            prefix_generated_name,
            _public_name_from_source(kit_source, source, kind, resource_id),
        ),
        prefix_generated_name=prefix_generated_name,
        tools=_string_list(
            agent_config.get("tools", raw.get("tools", permissions_config.get("tools"))),
            f"resources.{resource_id}.tools",
        ),
        disallowed_tools=_string_list(
            agent_config.get(
                "disallowed_tools",
                raw.get("disallowed_tools", permissions_config.get("disallowed_tools")),
            ),
            f"resources.{resource_id}.disallowed_tools",
        ),
        mode=_config_string(raw, agent_config, "mode", _DEFAULT_MODE) or _DEFAULT_MODE,
        isolation=_config_bool(raw, agent_config, "isolation", False),
        model=_config_string(raw, agent_config, "model"),
        skills=_config_string_list(raw, agent_config, "skills", f"resources.{resource_id}.skills"),
        color=_config_string(raw, agent_config, "color"),
        memory_dir=_config_string(raw, agent_config, "memory_dir"),
        role=_config_string(raw, agent_config, "role", _DEFAULT_ROLE) or _DEFAULT_ROLE,
        target=_config_string(raw, agent_config, "target", _DEFAULT_TARGET) or _DEFAULT_TARGET,
        provider=_config_string(raw, agent_config, "provider", _DEFAULT_PROVIDER) or _DEFAULT_PROVIDER,
        reasoning_effort=_config_optional_string(raw, agent_config, "reasoning_effort"),
        context_window=_config_optional_string(raw, agent_config, "context_window"),
        subagents=_config_subagents(raw, agent_config, f"resources.{resource_id}.subagents"),
        target_configs=_config_table(raw, "targets", f"resources.{resource_id}.targets"),
        artifact_bindings=artifact_bindings,
    )
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-agent-config


def _from_manifest_resource(
    kit_source: Path,
    slug: str,
    res: ManifestResource,
    _warnings: List[str],
) -> KitResource:
    # @cpt-begin:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-resource-id-vs-generated-name
    kind = _resource_kind_from_path(res.source, res.id)
    origin = "legacy-workflow" if kind == "skill" and res.source.startswith("workflows/") else ""
    return KitResource(
        id=res.id,
        kind=kind,
        source=res.source,
        install_path=res.default_path,
        type=res.type,
        public=kind in _PUBLIC_KINDS,
        description=res.description,
        user_modifiable=res.user_modifiable,
        origin=origin,
        generated_name=_resource_generated_name(
            slug,
            kind in _PUBLIC_KINDS,
            True,
            implicit_generated_name=_public_name_from_source(kit_source, res.source, kind, res.id),
        ),
    )
    # @cpt-end:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-resource-id-vs-generated-name


def _source_from_component(component: ComponentEntry) -> str:
    return component.source or component.prompt_file


# @cpt-begin:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-resource-id-vs-generated-name
def _from_manifest_component(
    kit_source: Path,
    slug: str,
    component: ComponentEntry,
    kind: str,
    *,
    origin: str = "",
) -> Optional[KitResource]:
    source = _source_from_component(component)
    if not source:
        return None
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-generated-targets
    generated_targets = component.agents or ["installed"]
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-generated-targets
    kwargs: Dict[str, Any] = {}
    if isinstance(component, AgentEntry):
        kwargs = {
            "tools": component.tools,
            "disallowed_tools": component.disallowed_tools,
            "mode": component.mode,
            "isolation": component.isolation,
            "model": component.model,
            "skills": component.skills,
            "color": component.color,
            "memory_dir": component.memory_dir,
            "role": component.role,
            "target": component.target,
            "provider": component.provider,
            "reasoning_effort": component.reasoning_effort,
            "context_window": component.context_window,
        }
    return KitResource(
        id=component.id,
        kind=kind,
        source=source,
        install_path=source,
        type="file",
        public=True,
        description=component.description,
        user_modifiable=True,
        generated_targets=generated_targets,
        origin=origin,
        generated_name=_resource_generated_name(
            slug,
            True,
            True,
            implicit_generated_name=_public_name_from_source(kit_source, source, kind, component.id),
        ),
        **kwargs,
    )
# @cpt-end:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-resource-id-vs-generated-name


# @cpt-begin:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-unique-resource-ids
def _append_unique_legacy_resource(
    resources: List[KitResource],
    seen_ids: set[str],
    resource: KitResource,
) -> None:
    if resource.id in seen_ids:
        raise ValueError(f"Duplicate resource id '{resource.id}' in legacy manifest")
    seen_ids.add(resource.id)
    resources.append(resource)
# @cpt-end:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-unique-resource-ids


# @cpt-begin:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-append-components
def _append_manifest_resources(
    resources: List[KitResource],
    seen_ids: set[str],
    manifest_resources: List[ManifestResource],
    kit_source: Path,
    slug: str,
    warnings: List[str],
) -> None:
    """Normalize legacy manifest resources into KitResource entries."""
    for res in manifest_resources:
        _append_unique_legacy_resource(
            resources,
            seen_ids,
            _from_manifest_resource(kit_source, slug, res, warnings),
        )


def _append_legacy_component_resource(
    resources: List[KitResource],
    seen_ids: set[str],
    warnings: List[str],
    resource: Optional[KitResource],
    *,
    warning_message: str = "",
    deprecation_warning: str = "",
) -> None:
    """Append an optional normalized component resource and related warnings."""
    if resource is None:
        return
    _append_unique_legacy_resource(resources, seen_ids, resource)
    if warning_message:
        warnings.append(warning_message)
    if deprecation_warning and deprecation_warning not in warnings:
        warnings.append(deprecation_warning)
# @cpt-end:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-append-components


# @cpt-begin:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-precedence
def _load_legacy_manifest_model(kit_source: Path) -> Optional[KitModel]:
    manifest = load_manifest(kit_source)
    if manifest is None:
        return None
    conf_slug, conf_version = _read_conf_metadata(kit_source)
    slug = conf_slug or kit_source.name
    # @cpt-begin:cpt-studio-algo-kit-manifest-normalize:p1:inst-rollout-docs-deprecation
    warnings = [
        "legacy manifest.toml normalized to canonical KitModel",
        _LEGACY_MANIFEST_DEPRECATION_WARNING,
    ]
    # @cpt-end:cpt-studio-algo-kit-manifest-normalize:p1:inst-rollout-docs-deprecation
    resources: List[KitResource] = []
    seen_ids: set[str] = set()
    if isinstance(manifest, Manifest):
        _append_manifest_resources(
            resources,
            seen_ids,
            manifest.resources,
            kit_source,
            slug,
            warnings,
        )
        version = manifest.version or conf_version
    elif isinstance(manifest, ManifestV2):
        version = manifest.version or conf_version
        _append_manifest_resources(
            resources,
            seen_ids,
            manifest.resources,
            kit_source,
            slug,
            warnings,
        )
        # @cpt-begin:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-workflows-to-skills
        for workflow in manifest.workflows:
            _append_legacy_component_resource(
                resources,
                seen_ids,
                warnings,
                _from_manifest_component(
                    kit_source,
                    slug,
                    workflow,
                    "skill",
                    origin="legacy-workflow",
                ),
                warning_message=f"Legacy workflow '{workflow.id}' normalized to public skill resource",
                deprecation_warning=_LEGACY_WORKFLOW_DEPRECATION_WARNING,
            )
        # @cpt-end:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-workflows-to-skills
        for skill in manifest.skills:
            _append_legacy_component_resource(
                resources,
                seen_ids,
                warnings,
                _from_manifest_component(kit_source, slug, skill, "skill"),
            )
        for agent in manifest.agents:
            resource = _from_manifest_component(kit_source, slug, agent, "agent")
            if resource is not None:
                _append_unique_legacy_resource(resources, seen_ids, resource)
        for rule in manifest.rules:
            resource = _from_manifest_component(kit_source, slug, rule, "rule")
            if resource is not None:
                _append_unique_legacy_resource(resources, seen_ids, resource)
    else:
        return None
    for resource in resources:
        _validate_relative_source(kit_source, resource)
        _validate_install_path(resource)
    return _with_hashes(
        kit_source,
        KitModel(
            slug=slug,
            name=slug,
            version=version,
            manifest_source="legacy_manifest",
            resources=resources,
            warnings=warnings,
        ),
    )
# @cpt-end:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-precedence


# @cpt-begin:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-precedence
def _load_layout_model(kit_source: Path) -> KitModel:
    conf_slug, conf_version = _read_conf_metadata(kit_source)
    slug = conf_slug or kit_source.name
    resources: List[KitResource] = []
    warnings = [
        "legacy layout normalized to canonical KitModel",
        _LEGACY_LAYOUT_DEPRECATION_WARNING,
    ]
    for dirname in _LEGACY_CONTENT_DIRS:
        path = kit_source / dirname
        if path.is_dir():
            if dirname == "workflows" and _LEGACY_WORKFLOW_DEPRECATION_WARNING not in warnings:
                warnings.append(_LEGACY_WORKFLOW_DEPRECATION_WARNING)
            resources.append(KitResource(
                id=dirname,
                kind="skill" if dirname == "workflows" else "directory",
                source=dirname,
                install_path=dirname,
                type="directory",
                public=dirname == "workflows",
                user_modifiable=True,
                origin="legacy-workflow" if dirname == "workflows" else "",
                generated_name=_resource_generated_name(
                    slug,
                    dirname == "workflows",
                    True,
                    implicit_generated_name=_public_name_from_source(kit_source, dirname, "skill"),
                ),
            ))
    for filename in _LEGACY_CONTENT_FILES:
        path = kit_source / filename
        if path.is_file():
            resource_id = Path(filename).stem.lower()
            kind = _resource_kind_from_path(filename, resource_id)
            resources.append(KitResource(
                id=resource_id,
                kind=kind,
                source=filename,
                install_path=filename,
                type="file",
                public=kind in _PUBLIC_KINDS,
                user_modifiable=True,
                generated_name=_resource_generated_name(
                    slug,
                    kind in _PUBLIC_KINDS,
                    True,
                    implicit_generated_name=_public_name_from_source(
                        kit_source,
                        filename,
                        kind,
                        resource_id,
                    ),
                ),
            ))
    if not resources:
        raise ValueError(f"No kit resources found under {kit_source}")
    return _with_hashes(
        kit_source,
        KitModel(
            slug=slug,
            name=slug,
            version=conf_version,
            manifest_source="legacy_layout",
            resources=resources,
            warnings=warnings,
        ),
    )
# @cpt-end:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-precedence


def _resolve_core_path(studio_root: Path, raw_path: str) -> Path:
    # @cpt-begin:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-core-bindings
    path = Path(raw_path)
    if path.is_absolute():
        raise ValueError(
            f"Invalid persisted core.toml path '{raw_path}': only project-relative paths are supported",
        )
    return (studio_root / path).resolve()
    # @cpt-end:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-core-bindings


# @cpt-begin:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-core-bindings
def _find_core_kit_entry(kit_source: Path) -> tuple[Path, str, Dict[str, Any]]:
    for candidate in [kit_source, *kit_source.parents]:
        core_path = candidate / "core.toml"
        if not core_path.is_file():
            continue
        try:
            data = toml_utils.load(core_path)
        except (OSError, tomllib.TOMLDecodeError) as exc:
            raise ValueError(f"Invalid core.toml at {core_path}: {exc}") from exc
        kits = data.get("kits")
        if not isinstance(kits, dict):
            continue
        studio_root = candidate.parent.resolve()
        for slug, entry in sorted(kits.items()):
            if not isinstance(entry, dict):
                continue
            raw_path = entry.get("path", f"config/kits/{slug}")
            if not isinstance(raw_path, str):
                continue
            if _resolve_core_path(studio_root, raw_path) == kit_source.resolve():
                return studio_root, str(slug), entry
        fallback = kits.get(kit_source.name)
        if isinstance(fallback, dict):
            return studio_root, kit_source.name, fallback
    raise ValueError(f"No core.toml registration found for installed kit root: {kit_source}")
# @cpt-end:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-core-bindings


# @cpt-begin:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-core-bindings
def _core_binding_resource(
    *,
    kit_source: Path,
    studio_root: Path,
    slug: str,
    resource_id: Any,
    binding: Any,
    warnings: List[str],
) -> Optional[KitResource]:
    raw_binding = binding.get("path") if isinstance(binding, dict) else binding
    # @cpt-begin:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-report-ambiguity
    if not isinstance(raw_binding, str) or not raw_binding.strip():
        warnings.append(f"Resource '{resource_id}' has no usable binding path; skipped")
        return None
    # @cpt-end:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-report-ambiguity
    # @cpt-begin:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-containment
    bound_path = _resolve_core_path(studio_root, raw_binding)
    try:
        source = bound_path.relative_to(kit_source.resolve()).as_posix()
    except ValueError as exc:
        raise ValueError(
            f"Resource '{resource_id}' binding '{raw_binding}' is outside selected kit root '{kit_source}'",
        ) from exc
    if not bound_path.exists():
        raise ValueError(f"Resource '{resource_id}' binding path does not exist: {bound_path}")
    # @cpt-end:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-containment
    binding_dict = binding if isinstance(binding, dict) else {}
    kind = (
        _normalize_kind(str(binding_dict.get("kind", "")).strip(), warnings=warnings, resource_id=str(resource_id))
        if str(binding_dict.get("kind", "")).strip()
        else _resource_kind_from_path(source, str(resource_id))
    )
    # @cpt-begin:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-artifact-bindings
    artifact_bindings = _artifact_bindings(binding_dict.get("artifacts"), f"resources.{resource_id}.artifacts")
    if artifact_bindings and kind != "constraints":
        raise ValueError(
            f"Resource '{resource_id}': artifacts bindings are only allowed for constraints resources",
        )
    # @cpt-end:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-artifact-bindings
    origin = str(binding_dict.get("origin", "")).strip()
    if not origin and kind == "skill" and source.startswith("workflows/"):
        origin = "legacy-workflow"
    return KitResource(
        id=str(resource_id),
        kind=kind,
        source=source,
        # @cpt-begin:cpt-studio-algo-kit-manifest-install:p1:inst-manifest-default-path
        install_path=source,
        # @cpt-end:cpt-studio-algo-kit-manifest-install:p1:inst-manifest-default-path
        type="directory" if bound_path.is_dir() else "file",
        public=kind in _PUBLIC_KINDS,
        description=str(binding_dict.get("description", "")).strip(),
        user_modifiable=bool(binding_dict.get("user_modifiable", True)),
        aliases=_string_list(binding_dict.get("aliases"), f"resources.{resource_id}.aliases"),
        # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-generated-targets
        generated_targets=(
            _string_list(
                binding_dict.get("generated_targets"),
                f"resources.{resource_id}.generated_targets",
            )
            or ["installed"]
        ),
        # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-generated-targets
        origin=origin,
        generated_name=_resource_generated_name(
            slug,
            kind in _PUBLIC_KINDS,
            bool(binding_dict.get("prefix_generated_name", True)),
            _public_name_from_source(kit_source, source, kind, resource_id),
        ),
        prefix_generated_name=bool(binding_dict.get("prefix_generated_name", True)),
        tools=_string_list(binding_dict.get("tools"), f"resources.{resource_id}.tools"),
        disallowed_tools=_string_list(
            binding_dict.get("disallowed_tools"),
            f"resources.{resource_id}.disallowed_tools",
        ),
        mode=str(binding_dict.get("mode", _DEFAULT_MODE) or _DEFAULT_MODE),
        isolation=bool(binding_dict.get("isolation", False)),
        model=str(binding_dict.get("model", _EMPTY_TEXT) or _EMPTY_TEXT),
        skills=_string_list(binding_dict.get("skills"), f"resources.{resource_id}.skills"),
        color=str(binding_dict.get("color", _EMPTY_TEXT) or _EMPTY_TEXT),
        memory_dir=str(binding_dict.get("memory_dir", _EMPTY_TEXT) or _EMPTY_TEXT),
        role=str(binding_dict.get("role", _DEFAULT_ROLE) or _DEFAULT_ROLE),
        target=str(binding_dict.get("target", _DEFAULT_TARGET) or _DEFAULT_TARGET),
        provider=str(binding_dict.get("provider", _DEFAULT_PROVIDER) or _DEFAULT_PROVIDER),
        reasoning_effort=(
            str(binding_dict.get("reasoning_effort", _EMPTY_TEXT) or _EMPTY_TEXT)
            if binding_dict.get("reasoning_effort")
            else None
        ),
        context_window=(
            str(binding_dict.get("context_window", _EMPTY_TEXT) or _EMPTY_TEXT)
            if binding_dict.get("context_window")
            else None
        ),
        subagents=_config_subagents(binding_dict, {}, f"resources.{resource_id}.subagents"),
        target_configs=_config_table(binding_dict, "targets", f"resources.{resource_id}.targets"),
        artifact_bindings=artifact_bindings,
    )
# @cpt-end:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-core-bindings


# @cpt-begin:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-core-bindings
def _load_core_model(kit_source: Path) -> KitModel:
    studio_root, slug, entry = _find_core_kit_entry(kit_source)
    bindings = entry.get("resources")
    if not isinstance(bindings, dict) or not bindings:
        raise ValueError(f"Kit '{slug}' has no resource bindings in core.toml")

    warnings = ["installed core.toml resource bindings normalized to canonical KitModel"]
    resources: List[KitResource] = []
    # @cpt-begin:cpt-studio-algo-kit-manifest-install:p1:inst-manifest-foreach-resource
    for resource_id, binding in sorted(bindings.items()):
        resource = _core_binding_resource(
            kit_source=kit_source,
            studio_root=studio_root,
            slug=slug,
            resource_id=resource_id,
            binding=binding,
            warnings=warnings,
        )
        if resource is not None:
            resources.append(resource)
    # @cpt-end:cpt-studio-algo-kit-manifest-install:p1:inst-manifest-foreach-resource
    if not resources:
        raise ValueError(f"No usable resource bindings found for kit '{slug}'")

    return _with_hashes(
        kit_source,
        KitModel(
            slug=slug,
            name=str(entry.get("name") or slug),
            version=str(entry.get("version") or ""),
            manifest_source="core",
            resources=resources,
            warnings=warnings,
        ),
    )
# @cpt-end:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-core-bindings


# @cpt-algo:cpt-studio-algo-kit-model-normalize:p1
def load_kit_model(kit_source: Path, source_hint: str = "", kit_slug: str = "") -> KitModel:
    """Load a kit source through canonical, legacy manifest, or layout adapters."""
    # @cpt-begin:cpt-studio-state-kit-manifest:p1:inst-manifest-source-state
    # @cpt-begin:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-single-boundary
    # @cpt-begin:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-canonical-manifest
    if source_hint in ("", "manifest"):
        model = load_canonical_kit_model(kit_source, kit_slug=kit_slug)
        if model is not None:
            return model
    # @cpt-end:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-canonical-manifest

    # @cpt-begin:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-precedence
    if source_hint in ("", "manifest"):
        legacy_model = _load_legacy_manifest_model(kit_source)
        if legacy_model is not None:
            return legacy_model
    if source_hint == "core":
        return _load_core_model(kit_source)
    if source_hint in ("", "layout"):
        return _load_layout_model(kit_source)
    raise ValueError(f"Unsupported normalization source: {source_hint}")
    # @cpt-end:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-precedence
    # @cpt-end:cpt-studio-algo-kit-model-normalize:p1:inst-kitmodel-single-boundary
    # @cpt-end:cpt-studio-state-kit-manifest:p1:inst-manifest-source-state


# @cpt-begin:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-convert
def _merge_core_authoritative_model(core_model: KitModel, source_model: KitModel) -> KitModel:
    # @cpt-begin:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-merge-core-authority
    source_by_id = {resource.id: resource for resource in source_model.resources}
    merged_resources: List[KitResource] = []
    for core_resource in core_model.resources:
        source_resource = source_by_id.get(core_resource.id)
        if source_resource is None:
            merged_resources.append(core_resource)
            continue
        inferred_core_kind = _resource_kind_from_path(core_resource.source, core_resource.id)
        merged_kind = core_resource.kind
        if core_resource.kind == inferred_core_kind and source_resource.kind != core_resource.kind:
            merged_kind = source_resource.kind
        merged_public = core_resource.public
        if not merged_public and merged_kind == source_resource.kind and source_resource.public:
            merged_public = True
        merged_resources.append(KitResource(
            id=core_resource.id,
            kind=merged_kind,
            source=core_resource.source,
            install_path=core_resource.install_path,
            type=core_resource.type,
            public=merged_public,
            description=source_resource.description or core_resource.description,
            user_modifiable=source_resource.user_modifiable,
            aliases=list(source_resource.aliases or core_resource.aliases),
            generated_targets=list(source_resource.generated_targets or core_resource.generated_targets),
            origin=core_resource.origin or source_resource.origin,
            generated_name=source_resource.generated_name or core_resource.generated_name,
            prefix_generated_name=source_resource.prefix_generated_name,
            content_hash=core_resource.content_hash,
            tools=list(source_resource.tools),
            disallowed_tools=list(source_resource.disallowed_tools),
            mode=source_resource.mode,
            isolation=source_resource.isolation,
            model=source_resource.model or core_resource.model,
            skills=list(source_resource.skills),
            color=source_resource.color or core_resource.color,
            memory_dir=source_resource.memory_dir or core_resource.memory_dir,
            role=source_resource.role,
            target=source_resource.target,
            provider=source_resource.provider,
            reasoning_effort=source_resource.reasoning_effort or core_resource.reasoning_effort,
            context_window=source_resource.context_window or core_resource.context_window,
            subagents=list(source_resource.subagents),
            target_configs=dict(source_resource.target_configs),
            artifact_bindings=core_resource.artifact_bindings or source_resource.artifact_bindings,
        ))
    return KitModel(
        slug=core_model.slug,
        name=source_model.name or core_model.name,
        version=core_model.version or source_model.version,
        manifest_source="core",
        resources=merged_resources,
        warnings=list(dict.fromkeys(list(core_model.warnings) + list(source_model.warnings))),
    )
    # @cpt-end:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-merge-core-authority
# @cpt-end:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-convert


# @cpt-begin:cpt-studio-algo-kit-manifest-normalize:p1:inst-rollout-path-install
def load_installed_kit_model(
    kit_source: Path,
    core_kit: Dict[str, Any],
    kit_slug: str = "",
) -> KitModel:
    """Load a registered installed kit using install-mode-aware source precedence."""
    install_mode = str(core_kit.get("install_mode", "") or "").strip().lower()
    if install_mode != "register":
        try:
            core_model = load_kit_model(kit_source, source_hint="core", kit_slug=kit_slug)
        except ValueError as exc:
            logger.warning("Failed to load core-preferred kit model from %s: %s", kit_source, exc)
            core_model = None
        if core_model is not None:
            try:
                source_model = load_kit_model(kit_source, kit_slug=kit_slug)
            except ValueError:
                return core_model
            return _with_hashes(kit_source, _merge_core_authoritative_model(core_model, source_model))
    return load_kit_model(kit_source, kit_slug=kit_slug)
# @cpt-end:cpt-studio-algo-kit-manifest-normalize:p1:inst-rollout-path-install


# @cpt-begin:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-preserve-fields
def _resource_to_toml_item(resource: KitResource) -> Dict[str, Any]:
    item: Dict[str, Any] = {
        "id": resource.id,
        "kind": resource.kind,
        "source": resource.source,
        "install_path": resource.install_path,
        "type": resource.type,
        "user_modifiable": resource.user_modifiable,
    }
    optional_values = {
        "description": resource.description,
        "aliases": resource.aliases,
        "generated_targets": resource.generated_targets,
        "origin": resource.origin,
        "tools": resource.tools,
        "disallowed_tools": resource.disallowed_tools,
        "model": resource.model,
        "skills": resource.skills,
        "color": resource.color,
        "memory_dir": resource.memory_dir,
        "reasoning_effort": resource.reasoning_effort,
        "context_window": resource.context_window,
        "subagents": resource.subagents,
        "targets": resource.target_configs,
        "artifacts": resource.artifact_bindings,
    }
    if resource.public:
        item["public"] = True
    if not resource.prefix_generated_name:
        item["prefix_generated_name"] = False
    if resource.mode != _DEFAULT_MODE:
        item["mode"] = resource.mode
    if resource.isolation:
        item["isolation"] = resource.isolation
    if resource.role != _DEFAULT_ROLE:
        item["role"] = resource.role
    if resource.target != _DEFAULT_TARGET:
        item["target"] = resource.target
    if resource.provider != _DEFAULT_PROVIDER:
        item["provider"] = resource.provider
    for key, value in optional_values.items():
        if value:
            item[key] = value
    return item
# @cpt-end:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-preserve-fields


# @cpt-begin:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-convert
def kit_models_to_toml_data(models: List[KitModel]) -> Dict[str, Any]:
    """Convert one or more KitModels to canonical manifest TOML data."""
    if not models:
        raise ValueError("At least one kit model is required")
    kits: List[Dict[str, Any]] = []
    for model in models:
        kits.append({
            "slug": model.slug,
            "name": model.name,
            "version": model.version,
            "resources": [_resource_to_toml_item(resource) for resource in model.resources],
        })

    return {
        "manifest_version": _CANONICAL_MANIFEST_VERSION,
        "kits": kits,
    }
# @cpt-end:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-convert


def render_canonical_manifest(model: KitModel) -> str:
    """Render a normalized model as canonical ``.cf-studio-kit.toml``."""
    return render_canonical_manifest_models([model])


def render_canonical_manifest_models(models: List[KitModel]) -> str:
    """Render one or more normalized models as canonical ``.cf-studio-kit.toml``."""
    return toml_utils.dumps(
        kit_models_to_toml_data(models),
        header_comment="Generated by cfs kit normalize. Review before publishing.",
    )


def normalize_kit_source(kit_source: Path, source_hint: str = "") -> tuple[KitModel, str]:
    """Normalize *kit_source* and return the model plus canonical TOML text."""
    # @cpt-begin:cpt-studio-algo-kit-manifest-normalize:p1:inst-rollout-kitmodel-tests
    # @cpt-begin:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-load-kitmodel
    if not kit_source.is_dir():
        raise ValueError(f"Kit source directory not found: {kit_source}")
    model = load_kit_model(kit_source, source_hint)
    # @cpt-end:cpt-studio-algo-kit-manifest-normalize:p1:inst-normalize-load-kitmodel
    # @cpt-end:cpt-studio-algo-kit-manifest-normalize:p1:inst-rollout-kitmodel-tests
    manifest_text = render_canonical_manifest(model)
    # @cpt-begin:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-version-gate
    try:
        rendered_data = toml_utils.loads(manifest_text)
    except tomllib.TOMLDecodeError as exc:
        raise ValueError(f"Generated canonical manifest is invalid TOML: {exc}") from exc
    _validate_canonical_manifest_version(rendered_data)
    # @cpt-end:cpt-studio-algo-kit-canonical-manifest:p1:inst-canonical-version-gate
    return model, manifest_text
