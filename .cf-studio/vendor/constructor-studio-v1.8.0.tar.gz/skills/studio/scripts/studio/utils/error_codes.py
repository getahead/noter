"""Stable error codes for Studio validation.

Every validation error/warning carries a ``code`` field from this module.
Fixing prompts and downstream consumers match on codes, not messages.

Invariant — every uppercase string constant in this module is a rule code, and
only rule codes live here. ``utils/severity.py`` checks at import that each one
has a declared default severity and refuses to load otherwise. That is a
deliberate tripwire, not a heuristic to be worked around: a constant that is
not a rule code (a schema version, a format tag) belongs in the module that
uses it, and adding it here will name itself in the import error. Scoping the
check to a curated list instead would let a new code slip past the guard when
someone forgot to add it to the list — the exact silence the guard exists to
prevent.

@cpt-algo:cpt-studio-algo-traceability-validation-validate-structure:p1
@cpt-dod:cpt-studio-dod-traceability-validation-structure:p1
"""

# @cpt-begin:cpt-studio-algo-traceability-validation-validate-structure:p1:inst-codes-structure
# ---------------------------------------------------------------------------
# Structure — task / checkbox consistency
# ---------------------------------------------------------------------------
CDSL_STEP_UNCHECKED = "cdsl-step-unchecked"
PARENT_UNCHECKED_ALL_DONE = "parent-unchecked-all-done"
PARENT_CHECKED_NESTED_UNCHECKED = "parent-checked-nested-unchecked"

# ---------------------------------------------------------------------------
# Structure — references
# ---------------------------------------------------------------------------
REF_NO_DEFINITION = "ref-no-definition"
REF_DONE_DEF_NOT_DONE = "ref-done-def-not-done"
DEF_DONE_REF_NOT_DONE = "def-done-ref-not-done"
REF_TASK_DEF_NO_TASK = "ref-task-def-no-task"
DUPLICATE_DEFINITION = "duplicate-definition"

# ---------------------------------------------------------------------------
# Structure — heading numbering
# ---------------------------------------------------------------------------
HEADING_NUMBER_NOT_CONSECUTIVE = "heading-number-not-consecutive"

# ---------------------------------------------------------------------------
# Structure — cross-artifact ID coverage (validate.py)
# ---------------------------------------------------------------------------
ID_NOT_REFERENCED = "id-not-referenced"
ID_NOT_REFERENCED_NO_SCOPE = "id-not-referenced-no-scope"

# @cpt-end:cpt-studio-algo-traceability-validation-validate-structure:p1:inst-codes-structure

# @cpt-begin:cpt-studio-algo-traceability-validation-validate-structure:p1:inst-codes-constraints
# ---------------------------------------------------------------------------
# Constraints — ID kind presence
# ---------------------------------------------------------------------------
MISSING_CONSTRAINTS = "missing-constraints"
ID_SYSTEM_UNRECOGNIZED = "id-system-unrecognized"
ID_KIND_NOT_ALLOWED = "id-kind-not-allowed"
REQUIRED_ID_KIND_MISSING = "required-id-kind-missing"
TEMPLATE_DEF_KIND_NOT_IN_CONSTRAINTS = "template-def-kind-not-in-constraints"
TEMPLATE_REF_KIND_NOT_IN_CONSTRAINTS = "template-ref-kind-not-in-constraints"
# A required and an optional placeholder are two rules, not one rule at two
# severities: they carry different messages and different defaults. Splitting
# them keeps "one code, one default severity" true, which is what lets the
# stamped severity be derived from the code alone.
TEMPLATE_DEF_PLACEHOLDER_MISSING = "template-def-placeholder-missing"
TEMPLATE_DEF_PLACEHOLDER_MISSING_OPTIONAL = "template-def-placeholder-missing-optional"
TEMPLATE_REF_PLACEHOLDER_MISSING = "template-ref-placeholder-missing"
TEMPLATE_REF_PLACEHOLDER_MISSING_OPTIONAL = "template-ref-placeholder-missing-optional"

# ---------------------------------------------------------------------------
# Constraints — task / priority on definitions
# ---------------------------------------------------------------------------
DEF_MISSING_TASK = "def-missing-task"
DEF_PROHIBITED_TASK = "def-prohibited-task"
DEF_MISSING_PRIORITY = "def-missing-priority"
DEF_PROHIBITED_PRIORITY = "def-prohibited-priority"

# ---------------------------------------------------------------------------
# Constraints — how a definition is spelled
# ---------------------------------------------------------------------------
# A reference may be written as a markdown link; a definition may not. Without
# this code the link-form definition was filed as a reference to itself, so the
# id had no definition and the only finding, if any, blamed a dangling reference.
DEF_LINK_FORM_NOT_ALLOWED = "def-link-form-not-allowed"

# ---------------------------------------------------------------------------
# Constraints — heading placement for definitions
# ---------------------------------------------------------------------------
DEF_WRONG_HEADINGS = "def-wrong-headings"

# ---------------------------------------------------------------------------
# Constraints — heading contract
# ---------------------------------------------------------------------------
HEADING_MISSING = "heading-missing"
HEADING_PROHIBITS_MULTIPLE = "heading-prohibits-multiple"
HEADING_REQUIRES_MULTIPLE = "heading-requires-multiple"
HEADING_NUMBERING_MISMATCH = "heading-numbering-mismatch"
HEADING_ORDER_VIOLATION = "heading-order-violation"

# ---------------------------------------------------------------------------
# Constraints — cross-reference coverage
# ---------------------------------------------------------------------------
REF_TARGET_NOT_IN_SCOPE = "ref-target-not-in-scope"
REF_MISSING_FROM_KIND = "ref-missing-from-kind"
REF_WRONG_HEADINGS = "ref-wrong-headings"
REF_MISSING_TASK_FOR_TRACKED = "ref-missing-task-for-tracked"
REF_FROM_PROHIBITED_KIND = "ref-from-prohibited-kind"
REF_MISSING_TASK = "ref-missing-task"
REF_PROHIBITED_TASK = "ref-prohibited-task"
REF_MISSING_PRIORITY = "ref-missing-priority"
REF_PROHIBITED_PRIORITY = "ref-prohibited-priority"

# @cpt-end:cpt-studio-algo-traceability-validation-validate-structure:p1:inst-codes-constraints

# @cpt-begin:cpt-studio-algo-traceability-validation-validate-structure:p1:inst-codes-code-traceability
# ---------------------------------------------------------------------------
# Code traceability — marker errors
# ---------------------------------------------------------------------------
MARKER_DUP_BEGIN = "marker-dup-begin"
MARKER_END_NO_BEGIN = "marker-end-no-begin"
MARKER_EMPTY_BLOCK = "marker-empty-block"
MARKER_BEGIN_NO_END = "marker-begin-no-end"
MARKER_DUP_SCOPE = "marker-dup-scope"

# ---------------------------------------------------------------------------
# Code traceability — cross-validation
# ---------------------------------------------------------------------------
CODE_DOCS_ONLY = "code-docs-only"
CODE_ORPHAN_REF = "code-orphan-ref"
CODE_TASK_UNCHECKED = "code-task-unchecked"
CODE_NO_MARKER = "code-no-marker"
CODE_INST_MISSING = "code-inst-missing"
CODE_INST_ORPHAN = "code-inst-orphan"

# @cpt-end:cpt-studio-algo-traceability-validation-validate-structure:p1:inst-codes-code-traceability

# @cpt-begin:cpt-studio-algo-traceability-validation-validate-structure:p1:inst-codes-scope-and-toc
# ---------------------------------------------------------------------------
# Codebase registration — what was in scope to check
# ---------------------------------------------------------------------------
CODEBASE_ENTRY_EMPTY = "codebase-entry-empty"

# ---------------------------------------------------------------------------
# TOC (Table of Contents) validation
# ---------------------------------------------------------------------------
TOC_MISSING = "toc-missing"
TOC_ANCHOR_BROKEN = "toc-anchor-broken"
TOC_HEADING_NOT_IN_TOC = "toc-heading-not-in-toc"
TOC_STALE = "toc-stale"

# JIT-retrieval readiness signals (warning-only) — see constructorfabric/studio#104
TOC_HEADING_DUPLICATE = "toc-heading-duplicate"
TOC_HEADING_DEPTH_JUMP = "toc-heading-depth-jump"
TOC_SECTION_TOO_LONG = "toc-section-too-long"
TOC_MISSING_DESCRIPTION = "toc-missing-description"

# @cpt-end:cpt-studio-algo-traceability-validation-validate-structure:p1:inst-codes-scope-and-toc

# @cpt-begin:cpt-studio-algo-traceability-validation-validate-structure:p1:inst-codes-files-and-cdsl
# ---------------------------------------------------------------------------
# File errors
# ---------------------------------------------------------------------------
FILE_READ_ERROR = "file-read-error"
FILE_LOAD_ERROR = "file-load-error"
#: A file the reader declined because it exceeds the scan size ceiling. Distinct from
#: FILE_READ_ERROR so a caller can branch on the code rather than re-stat the file or
#: parse the message.
FILE_TOO_LARGE = "file-too-large"

# ---------------------------------------------------------------------------
# Content language validation
# ---------------------------------------------------------------------------
CONTENT_LANGUAGE_VIOLATION = "LANG001"

# ---------------------------------------------------------------------------
# CDSL structure — CDSL.md FAIL rules (S.3-7, CL.1-4, CO.4-6)
# ---------------------------------------------------------------------------
CDSL_MISSING_CHECKBOX = "cdsl-missing-checkbox"
CDSL_MISSING_PHASE_TOKEN = "cdsl-missing-phase-token"  # noqa: S105 -- error code, not a secret
CDSL_MISSING_INST_ID = "cdsl-missing-inst-id"
CDSL_INCOMPLETE_STEP_LINE = "cdsl-incomplete-step-line"
CDSL_CODE_SYNTAX = "cdsl-code-syntax"
CDSL_TYPE_ANNOTATION = "cdsl-type-annotation"
CDSL_LANGUAGE_OPERATOR = "cdsl-language-operator"
CDSL_NOT_PLAIN_ENGLISH = "cdsl-not-plain-english"
CDSL_DUPLICATE_INST_ID = "cdsl-duplicate-inst-id"
CDSL_PLACEHOLDER = "cdsl-placeholder"

# @cpt-end:cpt-studio-algo-traceability-validation-validate-structure:p1:inst-codes-files-and-cdsl

# @cpt-begin:cpt-studio-algo-traceability-validation-validate-structure:p1:inst-codes-kit
# ---------------------------------------------------------------------------
# Kit self-check, kit validation and context resolution
# ---------------------------------------------------------------------------
# These findings were emitted without a code, which put them out of reach of
# every per-rule mechanism: fixing prompts, downstream filtering, and now
# severity. A finding with no code cannot be configured, only deleted.
TEMPLATE_ID_KIND_NO_TEMPLATE = "template-id-kind-no-template"
TEMPLATE_DEF_PLACEHOLDER_WRONG_HEADINGS = "template-def-placeholder-wrong-headings"
TEMPLATE_REF_PLACEHOLDER_WRONG_HEADINGS = "template-ref-placeholder-wrong-headings"
TEMPLATE_READ_ERROR = "template-read-error"
CONSTRAINTS_INVALID = "constraints-invalid"
#: A key under a ``[validation]`` table this engine does not understand. A
#: warning rather than an error: a kit written for a newer engine stays
#: installable on an older one, the same bargain the manifest already makes.
CONSTRAINTS_UNKNOWN_KEY = "constraints-unknown-key"
KIT_TEMPLATE_BINDING_MISSING = "kit-template-binding-missing"
KIT_RESOURCE_PATH_NOT_FOUND = "kit-resource-path-not-found"
KIT_MODEL_INVALID = "kit-model-invalid"
KIT_PATH_NOT_ACCESSIBLE = "kit-path-not-accessible"
KIT_BINDING_ERROR = "kit-binding-error"
REGISTRY_AUTODETECT_INVALID = "registry-autodetect-invalid"
REGISTRY_AUTODETECT_FAILED = "registry-autodetect-failed"
# @cpt-end:cpt-studio-algo-traceability-validation-validate-structure:p1:inst-codes-kit
