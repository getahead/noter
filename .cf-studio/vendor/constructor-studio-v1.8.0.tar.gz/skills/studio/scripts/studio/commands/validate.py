"""Validate Studio traceability artifacts and code references."""

# @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-imports
import argparse
import json
import logging
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from ..utils import decision_log
from ..utils import error_codes as EC
from ..utils.codebase import CodeFile, cross_validate_code, error as code_issue, resolve_entry_code_files
from ..utils.constraints import (
    ArtifactRecord,
    build_severity_policy,
    cross_validate_artifacts,
    error as constraints_error,
    validate_artifact_file,
)
from ..utils.document import scan_cdsl_instructions, scan_cpt_ids
from ..utils.fixing import enrich_issues
from ..utils.severity import (
    SeverityPolicy,
    SeverityTables,
    apply_policy,
    declared_overrides,
    override_row,
    parse_project_validation,
    run_verdict,
)
from ..utils.ui import ui
# @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-imports

logger = logging.getLogger(__name__)


def _warn_validate(message: str) -> None:
    logger.warning("validate: %s", message)


@dataclass
class _ValidateSession:
    """Mutable validation session state shared across helper phases."""

    args: argparse.Namespace
    ctx: object
    ws_ctx: Optional[object]
    meta: object
    project_root: Path
    registered_systems: Set[str]
    known_kinds: Set[str]
    ctx_errors: List[Dict[str, object]]
    policy: SeverityPolicy = field(default_factory=SeverityPolicy)
    #: Warnings the passing validate-kits gate produced. Carried forward so a
    #: kit-level advisory is not lost just because the gate let the run proceed.
    kit_warnings: List[Dict[str, object]] = field(default_factory=list)
    artifacts_to_validate: List[Tuple[Path, Path, str, str, str]] = field(default_factory=list)
    # Reported alongside the scanned count: a file total without the number
    # excluded does not say whether the scope was what the reader assumed.
    code_files_excluded: int = 0


@dataclass
class _ValidateResults:
    """Aggregated validation outputs shared across phases."""

    all_errors: List[Dict[str, object]] = field(default_factory=list)
    all_warnings: List[Dict[str, object]] = field(default_factory=list)
    #: Findings a rule set to `off` removed. Counted so a suppressed rule is
    #: never simply invisible — a silent run and a silenced one look the same.
    suppressed_count: int = 0
    refusals: List[Dict[str, object]] = field(default_factory=list)
    artifact_reports: List[Dict[str, object]] = field(default_factory=list)
    artifact_report_by_path: Dict[str, Dict[str, object]] = field(default_factory=dict)
    artifact_records: List[ArtifactRecord] = field(default_factory=list)
    code_files_scanned: List[Dict[str, object]] = field(default_factory=list)
    parsed_code_files_full: List[CodeFile] = field(default_factory=list)
    code_ids_found: Set[str] = field(default_factory=set)
    to_code_ids: Set[str] = field(default_factory=set)
    empty_full_codebase_entries: List[Dict[str, str]] = field(default_factory=list)

# @cpt-begin:cpt-studio-algo-workspace-determine-target:p1:inst-validate-source-flag
def _resolve_source_context(source_name: str, ws_ctx: Optional["WorkspaceContext"]) -> Optional["StudioContext"]:
    """Resolve a workspace source name to its adapter StudioContext.

    Returns the adapter context on success, or None after emitting an error.
    """
    from ..utils.context import WorkspaceContext, resolve_adapter_context

    if ws_ctx is None:
        ui.result({"status": "ERROR", "message": "--source requires a workspace context. Run 'workspace-init' first."})
        return None
    sc = ws_ctx.sources.get(source_name)
    if sc is None:
        ui.result({"status": "ERROR", "message": f"Source '{source_name}' not found in workspace"})
        return None
    if not sc.reachable:
        ui.result({"status": "ERROR", "message": f"Source '{source_name}' is not reachable"})
        return None
    adapter_ctx = resolve_adapter_context(sc)
    if adapter_ctx is None:
        ui.result({"status": "ERROR", "message": f"Cannot resolve adapter context for source '{source_name}'"})
        return None
    return adapter_ctx
# @cpt-end:cpt-studio-algo-workspace-determine-target:p1:inst-validate-source-flag


# @cpt-dod:cpt-studio-dod-workspace-cross-repo:p1
def _collect_cross_repo_artifacts(
    ws_ctx: "WorkspaceContext",
    already_seen: Set[str],
) -> List[ArtifactRecord]:
    """Collect artifacts from remote workspace sources for cross-reference context.

    Remote artifacts are NOT validated themselves — only used so that
    cross-references FROM validated (local) artifacts can be resolved.
    """
    from ..utils.context import get_expanded_meta as _get_expanded_meta

    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-cross-repo-artifacts
    result: List[ArtifactRecord] = []
    seen = set(already_seen)
    for sc in ws_ctx.sources.values():
        if not sc.reachable or sc.meta is None or sc.path is None or sc.role not in ("artifacts", "full"):
            continue
        expanded = _get_expanded_meta(sc)
        if expanded is None:
            continue
        for art, _sys in expanded.iter_all_artifacts():
            art_path = (sc.path / art.path).resolve()
            if not art_path.exists() or str(art_path) in seen:
                continue
            seen.add(str(art_path))
            result.append(ArtifactRecord(
                path=art_path,
                artifact_kind=str(art.kind),
                constraints=None,
            ))
    return result
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-cross-repo-artifacts


def _collect_artifact_code_expectations(
    artifacts: List[ArtifactRecord],
    traceability_by_path: Dict[str, str],
    registered_systems: Optional[Set[str]] = None,
) -> Tuple[Set[str], Set[str], Set[str]]:
    """Collect artifact IDs and to-code expectations for strict validation."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-traceability-index
    artifact_ids: Set[str] = set()
    to_code_ids: Set[str] = set()
    to_code_ids_task_unchecked: Set[str] = set()
    for art in artifacts:
        art_traceability = traceability_by_path.get(str(art.path), "FULL")
        for hit in scan_cpt_ids(art.path):
            if hit.get("type") != "definition" or not hit.get("id"):
                continue
            did = str(hit["id"])
            artifact_ids.add(did)
            if art_traceability != "FULL":
                continue
            constraints_for_kind = getattr(art, "constraints", None)
            if constraints_for_kind is None:
                continue
            for id_constraint in getattr(constraints_for_kind, "defined_id", []) or []:
                kind = str(getattr(id_constraint, "kind", "") or "").strip().lower()
                if (
                    not kind
                    or not _cpt_definition_matches_kind(did, kind, registered_systems)
                    or not bool(getattr(id_constraint, "to_code", False))
                ):
                    continue
                if bool(hit.get("has_task", False)) and not bool(hit.get("checked", False)):
                    to_code_ids_task_unchecked.add(did)
                else:
                    to_code_ids_task_unchecked.discard(did)
                    to_code_ids.add(did)
                break
    return artifact_ids, to_code_ids, to_code_ids_task_unchecked
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-traceability-index


def _cpt_definition_matches_kind(
    cpt_id: str,
    kind: str,
    registered_systems: Optional[Set[str]] = None,
) -> bool:
    """Return whether a CPT definition ID has *kind* in its structural kind slot."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-traceability-index
    normalized_id = cpt_id.strip().lower()
    normalized_kind = kind.strip().lower()
    if not normalized_id.startswith("cpt-") or not normalized_kind:
        return False

    for system_name in sorted(registered_systems or set(), key=len, reverse=True):
        prefix = f"cpt-{system_name.lower()}-"
        if normalized_id.startswith(prefix):
            remainder = normalized_id[len(prefix):]
            return remainder.split("-", 1)[0] == normalized_kind

    parts = normalized_id.split("-")
    return len(parts) >= 3 and parts[2] == normalized_kind
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-traceability-index


def _collect_full_artifact_instances(
    artifacts: List[ArtifactRecord],
    traceability_by_path: Dict[str, str],
) -> Tuple[Dict[str, Set[str]], Dict[str, Set[str]]]:
    """Collect checked and all CDSL instruction instances from FULL artifacts."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-traceability-index
    artifact_instances: Dict[str, Set[str]] = {}
    artifact_instances_all: Dict[str, Set[str]] = {}
    for art in artifacts:
        art_traceability = traceability_by_path.get(str(art.path), "FULL")
        if art_traceability != "FULL":
            continue
        try:
            steps = scan_cdsl_instructions(art.path)
        except (OSError, ValueError) as exc:
            _warn_validate(f"failed to scan CDSL instructions in {art.path}: {exc}")
            continue
        for step in steps:
            pid = str(step.get("parent_id") or "")
            inst = str(step.get("inst") or "")
            if not pid or not inst:
                continue
            artifact_instances_all.setdefault(pid, set()).add(inst)
            if bool(step.get("checked", False)):
                artifact_instances.setdefault(pid, set()).add(inst)
    return artifact_instances, artifact_instances_all
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-traceability-index


def _parse_validate_args(argv: List[str]) -> argparse.Namespace:
    """Parse CLI args for the validate command."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-cli-setup
    parser = argparse.ArgumentParser(
        prog="validate",
        description=(
            "Validate Constructor Studio artifacts and code traceability "
            "(structure + cross-references + traceability)"
        ),
    )
    parser.add_argument(
        "--artifact",
        default=None,
        help=(
            "Path to specific Constructor Studio artifact "
            "(if omitted, validates all registered artifacts)"
        ),
    )
    parser.add_argument("--skip-code", action="store_true", help="Skip code traceability validation")
    parser.add_argument("--verbose", action="store_true", help="Print full validation report")
    parser.add_argument("--output", default=None, help="Write report to file instead of stdout")
    parser.add_argument(
        "--local-only",
        action="store_true",
        help="Skip cross-repo workspace validation (validate local repo only)",
    )
    parser.add_argument(
        "--source",
        default=None,
        help=(
            "Target a specific workspace source for validation "
            "(uses that source's adapter context)"
        ),
    )
    parser.add_argument(
        "--fail-on-warnings",
        action="store_true",
        help="Fail the run when there are warnings but no errors (exit 2)",
    )
    parser.add_argument(
        "--explain-severity",
        action="store_true",
        help="Report the effective severity of each rule and the layer that set it, then exit",
    )
    parser.add_argument(
        "--kind",
        default=None,
        help="With --explain-severity: restrict the explanation to one artifact kind",
    )
    parser.add_argument(
        "--rule",
        default=None,
        help="With --explain-severity: restrict the explanation to one rule code",
    )
    args = parser.parse_args(argv)
    # `--kind` and `--rule` narrow the explanation, they do not filter what is
    # validated. Accepting them silently on a normal run would look like the
    # artifact-kind filter the CLI spec once described, and quietly validate
    # everything anyway.
    if not args.explain_severity:
        for flag in ("kind", "rule"):
            if getattr(args, flag, None):
                parser.error(f"--{flag} is only meaningful with --explain-severity")
    return args
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-cli-setup


def _extend_known_kinds(ctx: object, known_kinds: Set[str]) -> None:
    """Merge kit-defined ID kinds into the known-kinds set."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-cli-setup
    from ..utils.context import collect_known_id_kinds

    known_kinds.update(collect_known_id_kinds(ctx))
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-cli-setup


def _run_validate_kits_gate(
    project_root: Path,
    ctx: object,
    verbose: bool,
    kit_warnings: Optional[List[Dict[str, object]]] = None,
) -> Optional[int]:
    """Run validate-kits fail-fast gate when kits are present.

    A passing gate still has something to say. A kit with a misspelled
    ``[validation]`` key passes — the finding is a warning — and the report was
    discarded whole, so the one command most likely to be run after editing a
    kit's severity policy was also the one that never mentioned the typo.
    """
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-session
    meta = getattr(ctx, "meta", None)
    if not getattr(meta, "kits", None):
        return None
    try:
        from .validate_kits import run_validate_kits

        rc, report = run_validate_kits(
            project_root=project_root,
            adapter_dir=ctx.adapter_dir,
            kit_filter=None,
            verbose=bool(verbose),
        )
    except (OSError, ValueError, KeyError) as exc:
        logger.exception("validate-kits gate failed")
        ui.result({
            "status": "ERROR",
            "message": "self-check failed to run",
            "error": str(exc),
        })
        return 1
    if not rc and str(report.get("status")) == "PASS":
        if kit_warnings is not None:
            kit_warnings.extend(_collect_kit_gate_warnings(report))
        return None
    ui.result({
        "status": "FAIL" if rc == 2 else "ERROR",
        "message": "validate-kits failed (kit structure or templates are inconsistent)",
        "validate_kits": report,
    })
    return 2 if rc == 2 else 1
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-session


#: Kit-level warnings that change how *this* run behaves, and therefore belong
#: in this run's report. A misspelled `[validation]` key is a severity policy
#: the kit author believes is in force and this command has never seen, so the
#: reader of a validate report needs it. Everything else a kit self-check
#: produces is about the kit's own files, and belongs to `validate-kits` —
#: forwarding it all would answer a question about the project's artifacts with
#: advisories about someone else's examples.
_KIT_WARNINGS_AFFECTING_THIS_RUN = frozenset({EC.CONSTRAINTS_UNKNOWN_KEY})


def _collect_kit_gate_warnings(report: Dict[str, object]) -> List[Dict[str, object]]:
    """Lift the kit warnings that bear on this run out of a passing gate report."""
    warnings: List[Dict[str, object]] = []
    for item in report.get("self_check_results", []) or []:
        if not isinstance(item, dict):
            continue
        warnings.extend(
            warning for warning in (item.get("warnings") or [])
            if str(warning.get("code") or "") in _KIT_WARNINGS_AFFECTING_THIS_RUN
        )
    return warnings


def _build_validate_session(args: argparse.Namespace) -> Tuple[Optional[_ValidateSession], Optional[int]]:
    """Load context, workspace state, and static validation metadata."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-load-context
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-session
    from ..utils.context import WorkspaceContext, get_context

    ctx = get_context()
    if not ctx:
        ui.result({"status": "ERROR", "message": "Constructor Studio not initialized. Run 'cfs init' first."})
        return None, 1

    ws_ctx = ctx if isinstance(ctx, WorkspaceContext) else None
    if args.source:
        ctx = _resolve_source_context(args.source, ws_ctx)
        if ctx is None:
            return None, 1

    ctx_errors = list(getattr(ctx, "_errors", []) or [])
    if ws_ctx is not None:
        from ..utils.workspace import find_workspace_config as _find_ws

        workspace_config, _ = _find_ws(ws_ctx.project_root)
        if workspace_config is not None:
            for ws_err in workspace_config.validate():
                ctx_errors.append(constraints_error("workspace", ws_err, path=str(workspace_config.workspace_file)))

    project_root = ctx.project_root
    # The validate-kits gate does not run here. `--artifact` can move the
    # session to a different workspace source, and a gate run now would
    # validate the kits of the source we are about to leave. It runs from
    # `_resolve_artifacts_to_validate`, once the context is final — which also
    # means `--explain-severity`, which returns before that, never triggers it.
    known_kinds = ctx.get_known_id_kinds()
    _extend_known_kinds(ctx, known_kinds)
    policy, policy_errors = _build_severity_policy(ctx, project_root, args)
    if policy_errors:
        return None, _emit_policy_config_error(policy_errors)
    return _ValidateSession(
        args=args,
        ctx=ctx,
        ws_ctx=ws_ctx,
        meta=ctx.meta,
        project_root=project_root,
        registered_systems=(
            ws_ctx.get_all_registered_systems()
            if ws_ctx is not None and not args.local_only
            else ctx.registered_systems
        ),
        known_kinds=known_kinds,
        ctx_errors=ctx_errors,
        policy=policy,
    ), None
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-session
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-load-context


# @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-build-policy
#: Three helpers below — `_emit_policy_config_error`, `_build_severity_policy`
#: and `_show_severity_overrides` — are also imported by `commands/validate_toc`,
#: which must read one project's severity exactly the way this command does.
#: Treat their signatures as a contract with that module, not as private detail.
#:
#: They stay here rather than moving to `utils/severity.py`: `_build_severity_policy`
#: calls `build_severity_policy`, which lives in `utils/constraints.py`, and
#: `constraints` already imports `severity` — so that direction is a cycle. The
#: other two are presentation, which `utils/` has no business owning.
#: `tests/test_validate_toc_policy.py` exercises all three through the real CLI,
#: so a changed return shape fails loudly rather than silently.


def _emit_policy_config_error(errors: List[str]) -> int:
    """Refuse the run when the severity configuration cannot be read.

    Also used by `validate-toc`; see the note above before changing its shape.
    """
    ui.result({
        "status": "ERROR",
        "message": "validation severity configuration is invalid",
        "errors": errors,
    })
    return 1


def _known_artifact_kinds(ctx: object) -> Set[str]:
    """Every artifact kind this project could validate.

    Both sources, because either alone would produce false alarms: a kit can
    declare constraints for a kind no system registers, and a system can
    register a kind whose constraints live in a kit that is not loaded here.
    """
    kinds: Set[str] = set()
    for kit in (getattr(ctx, "kits", None) or {}).values():
        constraints = getattr(kit, "constraints", None)
        for kind in (getattr(constraints, "by_kind", None) or {}):
            kinds.add(str(kind).strip().upper())
    meta = getattr(ctx, "meta", None)
    iter_artifacts = getattr(meta, "iter_all_artifacts", None)
    if callable(iter_artifacts):
        for artifact_meta, _system_node in iter_artifacts():
            kinds.add(str(getattr(artifact_meta, "kind", "") or "").strip().upper())
    return {kind for kind in kinds if kind}


def _unknown_project_severity_kinds(ctx: object, project: SeverityTables) -> List[str]:
    """Refuse a `[validation.severity.<KIND>]` naming a kind that does not exist.

    A misspelled kind is inert: it is not a rule code, so it resolves to
    nothing and shows up in no override report. The usual direction is a
    *raise*, so the author is left believing a rule now blocks when it does
    not — the failure this whole model exists to prevent, wearing a typo.

    A hard error rather than a warning, matching the rule for everything else
    in `core.toml`: the file is authored by whoever is running the command, on
    the engine they are running it on, so there is no older-engine case to
    protect and a typo is better said out loud.
    """
    known = _known_artifact_kinds(ctx)
    if not known:
        # Nothing registered and no kit loaded: every name would look wrong,
        # and refusing the run over that would be an alarm about our own
        # ignorance rather than about the project's configuration.
        return []
    unknown = sorted(kind for kind in project.by_kind if kind not in known)
    if not unknown:
        return []
    return [
        "[validation.severity] in core.toml names artifact kind(s) this project does not have: "
        f"{', '.join(unknown)} (known: {', '.join(sorted(known))})"
    ]


def _build_severity_policy(
    ctx: object,
    project_root: Path,
    args: argparse.Namespace,
) -> Tuple[SeverityPolicy, List[str]]:
    """Assemble the severity policy from every loaded kit and the project config.

    An invalid setting fails the run rather than being skipped. A severity that
    cannot be parsed is not a value with no opinion — it is a rule whose
    enforcement nobody can predict, and continuing would report a verdict on a
    policy that was never actually in force.
    """
    from ..utils.files import load_project_config

    errors: List[str] = []
    kit_constraints = [
        kit.constraints for kit in (getattr(ctx, "kits", None) or {}).values()
        if getattr(kit, "constraints", None) is not None
    ]
    project_config = load_project_config(project_root) or {}
    project = parse_project_validation(project_config.get("validation"), errors)
    if project.unknown_keys:
        errors.append(
            "[validation] in core.toml has unrecognised keys: "
            f"{', '.join(project.unknown_keys)}"
        )
    errors.extend(_unknown_project_severity_kinds(ctx, project))
    if errors:
        return SeverityPolicy(), errors
    if getattr(args, "fail_on_warnings", False):
        # A flag may only raise. Lowering stays in reviewable configuration,
        # where it is diffed and visible, rather than in whatever a caller
        # happened to type.
        project = replace(project, fail_on_warnings=True)
    return build_severity_policy(kit_constraints, project), []
# @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-build-policy


def _emit_validate_output(data: Dict[str, object], *, output_path: Optional[str], human: bool, pretty: bool) -> None:
    """Emit validate output to stdout or a JSON file."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-output
    if output_path:
        text = json.dumps(data, indent=2 if pretty else None, ensure_ascii=False)
        if pretty:
            text += "\n"
        Path(output_path).write_text(text, encoding="utf-8")
        return
    ui.result(data, human_fn=_human_validate if human else None)
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-output


def _emit_no_artifacts_result(session: _ValidateSession) -> int:
    """Emit the empty-registry result, preserving context load errors."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-output
    results = _ValidateResults()
    results.all_errors = list(session.ctx_errors)
    # Kit warnings belong here too. A project with nothing registered can still
    # have a kit whose `[validation]` table this engine does not understand,
    # and that is precisely the run where nothing else would mention it.
    results.all_warnings = list(session.kit_warnings)
    # Context errors are findings like any other, so the policy settles them
    # here too rather than only on the path that has artifacts to validate.
    _apply_run_policy(session, results)
    if results.all_errors or results.all_warnings:
        enrich_issues(results.all_errors, project_root=session.project_root)
        enrich_issues(results.all_warnings, project_root=session.project_root)
        verdict = run_verdict(
            len(results.all_errors),
            len(results.all_warnings),
            fail_on_warnings=session.policy.fail_on_warnings,
        )
        report: Dict[str, object] = {
            "status": verdict.status,
            "project_root": session.project_root.as_posix(),
            "artifacts_validated": 0,
            "error_count": len(results.all_errors),
            "warning_count": len(results.all_warnings),
            "errors": results.all_errors,
            "warnings": results.all_warnings,
        }
        if verdict.failed_on:
            report["failed_on"] = verdict.failed_on
        _attach_policy_report(report, session, results)
        ui.result(report, human_fn=_human_validate)
        return verdict.exit_code
    empty_report: Dict[str, object] = {
        "status": "PASS",
        "artifacts_validated": 0,
        "error_count": 0,
        "warning_count": 0,
        "message": "No artifacts found in registry",
    }
    # A project lowering is a property of the configuration, not of what a run
    # happened to find, so an empty registry reports it like any other run.
    _attach_policy_report(empty_report, session, results)
    ui.result(empty_report)
    return 0
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-output


def _append_registered_artifact(
    session: _ValidateSession,
    artifact_path: Path,
    artifact_meta: object,
    system_node: object,
) -> None:
    """Append one resolved registry artifact to the validation target list."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-artifact-resolution
    pkg = session.meta.get_kit(system_node.kit)
    if not pkg or not pkg.is_cfs_format():
        return
    template_path = (session.project_root / pkg.get_template_path(artifact_meta.kind)).resolve()
    session.artifacts_to_validate.append((
        artifact_path,
        template_path,
        artifact_meta.kind,
        artifact_meta.traceability,
        system_node.kit,
    ))
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-artifact-resolution


def _resolve_explicit_artifact(session: _ValidateSession, artifact_path: Path) -> Optional[int]:
    """Resolve one explicit artifact path against the registry and active context."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-artifact-resolution
    from ..utils.context import StudioContext, determine_target_source

    if not artifact_path.exists():
        ui.result({"status": "ERROR", "message": f"Artifact not found: {artifact_path}"})
        return 1

    if session.ws_ctx is not None:
        matched_sc, matched_ctx = determine_target_source(artifact_path, session.ws_ctx)
        if matched_ctx is None:
            ui.result({"status": "ERROR", "message": f"Cannot resolve context for artifact: {artifact_path}"})
            return 1
        if session.args.source and matched_sc is not None and matched_sc.name != session.args.source:
            ui.result({"status": "ERROR", "message": (
                f"Artifact '{session.args.artifact}' belongs to source '{matched_sc.name}', "
                f"not '{session.args.source}'."
            )})
            return 1
        session.ctx = matched_ctx
    else:
        session.ctx = StudioContext.load(artifact_path.parent)
        if not session.ctx:
            ui.result({"status": "ERROR", "message": "Constructor Studio not initialized"})
            return 1

    session.ctx_errors.extend(getattr(session.ctx, "_errors", []) or [])
    session.meta = session.ctx.meta
    session.project_root = session.ctx.project_root
    session.registered_systems.update(getattr(session.ctx, "registered_systems", set()) or set())
    session.known_kinds = session.ctx.get_known_id_kinds()
    _extend_known_kinds(session.ctx, session.known_kinds)
    try:
        rel_path = artifact_path.relative_to(session.project_root).as_posix()
    except ValueError as exc:
        logger.info(
            "Artifact path %s is not under project root %s",
            artifact_path,
            session.project_root,
            exc_info=exc,
        )
        rel_path = None
    result = session.meta.get_artifact_by_path(rel_path) if rel_path else None
    if result is None:
        ui.result({"status": "ERROR", "message": f"Artifact not in registry: {session.args.artifact}"})
        return 1
    artifact_meta, system_node = result
    _append_registered_artifact(session, artifact_path, artifact_meta, system_node)
    return None
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-artifact-resolution


def _collect_all_registered_artifacts(session: _ValidateSession) -> None:
    """Resolve all registered artifacts for the active context."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-artifact-resolution
    for artifact_meta, system_node in session.meta.iter_all_artifacts():
        if session.ws_ctx is not None:
            artifact_path = session.ws_ctx.resolve_artifact_path(artifact_meta, session.project_root)
        else:
            artifact_path = (session.project_root / artifact_meta.path).resolve()
        if artifact_path is None or not artifact_path.exists():
            continue
        _append_registered_artifact(session, artifact_path, artifact_meta, system_node)
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-artifact-resolution


def _resolve_artifacts_to_validate(session: _ValidateSession) -> Optional[int]:
    """Populate the validation target list from args or registry state."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-resolve-artifacts
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-artifact-resolution
    if session.args.artifact:
        exit_code = _resolve_explicit_artifact(session, Path(session.args.artifact).resolve())
        if exit_code is not None:
            return exit_code
        # `--artifact` can point into a different workspace source, which
        # replaces the session's context and project root. The policy assembled
        # from the original context would then apply another source's kit
        # severities and another project's `core.toml`, so it is rebuilt here
        # against the context actually in force.
        policy, policy_errors = _build_severity_policy(
            session.ctx, session.project_root, session.args)
        if policy_errors:
            return _emit_policy_config_error(policy_errors)
        session.policy = policy
    else:
        _collect_all_registered_artifacts(session)
    # The gate runs here rather than during session build, because the context
    # it should judge is the one `--artifact` may just have switched to. Run
    # earlier, it validated the kits of the source being left behind.
    gate_code = _run_validate_kits_gate(
        session.project_root,
        session.ctx,
        bool(session.args.verbose),
        session.kit_warnings,
    )
    if gate_code is not None:
        return gate_code
    if session.artifacts_to_validate:
        return None
    return _emit_no_artifacts_result(session)
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-artifact-resolution
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-resolve-artifacts


def _maybe_emit_registry_failure(session: _ValidateSession, results: _ValidateResults) -> Optional[int]:
    """Stop early when registry-level errors make later checks unreliable."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-constraint-resolution
    if session.ctx_errors:
        results.all_errors.extend(session.ctx_errors)
    if not any(str(issue.get("type", "")) == "registry" for issue in results.all_errors):
        return None
    enrich_issues(results.all_errors, project_root=session.project_root)
    _emit_validate_output({
        "status": "FAIL",
        "project_root": session.project_root.as_posix(),
        "artifact_count": len(session.artifacts_to_validate),
        "error_count": len(results.all_errors),
        "warning_count": 0,
        "errors": results.all_errors,
    }, output_path=session.args.output, human=True, pretty=True)
    return 2
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-constraint-resolution


def _resolve_constraints_for_artifact(
    session: _ValidateSession,
    artifact_type: str,
    kit_id: str,
) -> Tuple[object, Optional[Path]]:
    """Resolve artifact-kind constraints and the originating constraints path."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-constraint-resolution
    from ..utils.context import _resolve_loaded_kit_constraints_path

    constraints_for_kind = None
    loaded_kit = (session.ctx.kits or {}).get(str(kit_id))
    if loaded_kit and loaded_kit.constraints and str(artifact_type) in loaded_kit.constraints.by_kind:
        constraints_for_kind = loaded_kit.constraints.by_kind[str(artifact_type)]
    if not loaded_kit:
        return constraints_for_kind, None
    try:
        adapter_dir = getattr(session.ctx, "adapter_dir", None)
        if not isinstance(adapter_dir, Path):
            adapter_dir = session.project_root
        constraints_path = _resolve_loaded_kit_constraints_path(adapter_dir, session.project_root, loaded_kit)
    except (OSError, ValueError, KeyError) as exc:
        logger.warning("Failed to resolve loaded kit constraints path for %s", loaded_kit, exc_info=exc)
        constraints_path = None
    return constraints_for_kind, constraints_path
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-constraint-resolution


def _validate_one_artifact(
    session: _ValidateSession,
    results: _ValidateResults,
    artifact_entry: Tuple[Path, Path, str, str, str],
) -> None:
    """Run structure validation for one artifact and record its report."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-artifact-report
    artifact_path, _template_path, artifact_type, traceability, kit_id = artifact_entry
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-load-constraints
    constraints_for_kind, constraints_path = _resolve_constraints_for_artifact(session, artifact_type, kit_id)
    results.artifact_records.append(ArtifactRecord(
        path=artifact_path,
        artifact_kind=str(artifact_type),
        constraints=constraints_for_kind,
    ))
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-load-constraints
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-structure
    report = validate_artifact_file(
        artifact_path=artifact_path,
        artifact_kind=str(artifact_type),
        constraints=constraints_for_kind,
        registered_systems=session.registered_systems,
        constraints_path=constraints_path,
        kit_id=str(kit_id),
        policy=session.policy,
    )
    results.suppressed_count += int(report.get("suppressed") or 0)
    _record_refusals(results, report.get("refusals") or [])
    artifact_report = _build_artifact_report(
        artifact_path=artifact_path,
        artifact_type=artifact_type,
        traceability=traceability,
        report=report,
        verbose=bool(session.args.verbose),
    )
    results.artifact_reports.append(artifact_report)
    results.artifact_report_by_path[str(artifact_path)] = artifact_report
    results.all_errors.extend(report.get("errors", []))
    results.all_warnings.extend(report.get("warnings", []))
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-structure
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-artifact-report


def _build_artifact_report(
    *,
    artifact_path: Path,
    artifact_type: str,
    traceability: str,
    report: Dict[str, object],
    verbose: bool,
) -> Dict[str, object]:
    """Build one per-artifact validate report, including optional ID stats."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-artifact-report
    errors = report.get("errors", [])
    warnings = report.get("warnings", [])
    artifact_report: Dict[str, object] = {
        "artifact": str(artifact_path),
        "artifact_type": artifact_type,
        "traceability": traceability,
        "status": "PASS" if not errors else "FAIL",
        "error_count": len(errors),
        "warning_count": len(warnings),
    }
    if verbose or errors:
        artifact_report["errors"] = errors
    if verbose or warnings:
        artifact_report["warnings"] = warnings
        artifact_report.update(_artifact_traceability_counts(artifact_path))
    return artifact_report
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-artifact-report


def _artifact_traceability_counts(artifact_path: Path) -> Dict[str, int]:
    """Count traceability definitions and references for one artifact."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-artifact-report
    try:
        hits = scan_cpt_ids(artifact_path)
    except (OSError, ValueError) as exc:
        _warn_validate(f"failed to scan traceability ids in {artifact_path}: {exc}")
        return {"id_definitions": 0, "id_references": 0}
    return {
        "id_definitions": len([hit for hit in hits if hit.get("type") == "definition"]),
        "id_references": len([hit for hit in hits if hit.get("type") == "reference"]),
    }
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-artifact-report


def _attach_issue_to_artifact_report(
    issue: Dict[str, object],
    *,
    results: _ValidateResults,
    verbose: bool,
    is_error: bool,
) -> None:
    """Increment per-artifact counters for a later validation issue."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-artifact-report
    report = results.artifact_report_by_path.get(str(issue.get("path", "") or ""))
    if report is None:
        return
    if is_error:
        report["status"] = "FAIL"
        report["error_count"] = int(report.get("error_count", 0) or 0) + 1
        if verbose and isinstance(report.get("errors"), list):
            report["errors"].append(issue)
        return
    report["warning_count"] = int(report.get("warning_count", 0) or 0) + 1
    if verbose and isinstance(report.get("warnings"), list):
        report["warnings"].append(issue)
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-artifact-report


def _run_initial_artifact_validation(session: _ValidateSession) -> Tuple[_ValidateResults, Optional[int]]:
    """Run per-artifact structure checks and stop on early failures."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-artifact-report
    results = _ValidateResults()
    results.all_warnings.extend(session.kit_warnings)
    exit_code = _maybe_emit_registry_failure(session, results)
    if exit_code is not None:
        return results, exit_code
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-foreach-artifact
    for artifact_entry in session.artifacts_to_validate:
        _validate_one_artifact(session, results, artifact_entry)
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-foreach-artifact
    for language_error in _run_content_language_check(session.artifacts_to_validate, session.project_root):
        results.all_errors.append(language_error)
        _attach_issue_to_artifact_report(
            language_error,
            results=results,
            verbose=bool(session.args.verbose),
            is_error=True,
        )
    # Settle policy before deciding whether to stop. Context and language
    # findings arrive after the per-artifact pass has already run, so testing
    # the raw list here would take the early exit on a finding the project had
    # configured as `warning` or `off` — a relaxation that made the run fail
    # sooner rather than later.
    _apply_run_policy(session, results)
    if not results.all_errors:
        return results, None
    enrich_issues(results.all_errors, project_root=session.project_root)
    enrich_issues(results.all_warnings, project_root=session.project_root)
    out: Dict[str, object] = {
        "status": "FAIL",
        "project_root": session.project_root.as_posix(),
        "artifact_count": len(session.artifacts_to_validate),
        "error_count": len(results.all_errors),
        "warning_count": len(results.all_warnings),
        "errors": results.all_errors,
        "warnings": results.all_warnings,
    }
    _attach_policy_report(out, session, results)
    _emit_validate_output(out, output_path=session.args.output, human=True, pretty=True)
    return results, 2
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-artifact-report


def _build_cross_validation_context(session: _ValidateSession, results: _ValidateResults) -> List[ArtifactRecord]:
    """Load all artifacts needed for cross-reference and code validation context."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-cross-context
    all_artifacts = list(results.artifact_records)
    validated_paths = {str(path) for path, _, _, _, _ in session.artifacts_to_validate}
    for artifact_meta, system_node in session.meta.iter_all_artifacts():
        if session.ws_ctx is not None:
            artifact_path = session.ws_ctx.resolve_artifact_path(artifact_meta, session.project_root)
        else:
            artifact_path = (session.project_root / artifact_meta.path).resolve()
        if artifact_path is None or not artifact_path.exists() or str(artifact_path) in validated_paths:
            continue
        constraints_for_kind, _ = _resolve_constraints_for_artifact(
            session,
            str(artifact_meta.kind),
            str(system_node.kit),
        )
        all_artifacts.append(ArtifactRecord(
            path=artifact_path,
            artifact_kind=str(artifact_meta.kind),
            constraints=constraints_for_kind,
        ))
    if (
        not session.args.local_only
        and session.ws_ctx is not None
        and session.ws_ctx.cross_repo
        and session.ws_ctx.resolve_remote_ids
    ):
        seen_paths = {str(record.path) for record in all_artifacts}
        all_artifacts.extend(_collect_cross_repo_artifacts(session.ws_ctx, seen_paths))
    return all_artifacts
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-cross-context


def _run_cross_validation(
    session: _ValidateSession,
    results: _ValidateResults,
    all_artifacts_for_cross: List[ArtifactRecord],
) -> None:
    """Apply cross-artifact reference validation to the selected artifacts."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-cross-validate
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-cross-run
    if not all_artifacts_for_cross:
        return
    validated_paths = {str(path) for path, _, _, _, _ in session.artifacts_to_validate}
    cross_result = cross_validate_artifacts(
        all_artifacts_for_cross,
        registered_systems=session.registered_systems,
        known_kinds=session.known_kinds,
    )
    for issue in cross_result.get("errors", []):
        if issue.get("path", "") not in validated_paths:
            continue
        results.all_errors.append(issue)
        _attach_issue_to_artifact_report(issue, results=results, verbose=bool(session.args.verbose), is_error=True)
    for issue in cross_result.get("warnings", []):
        if issue.get("path", "") not in validated_paths:
            continue
        results.all_warnings.append(issue)
        _attach_issue_to_artifact_report(issue, results=results, verbose=bool(session.args.verbose), is_error=False)
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-cross-run
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-cross-validate


def _scan_codebase_entry(
    *,
    entry: object,
    traceability: str,
    session: _ValidateSession,
    results: _ValidateResults,
    strict_code_validation: bool,
) -> None:
    """Scan one configured codebase entry and collect code traceability state."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-code-scan
    # Normalise before resolving. A raw mapping would otherwise lose its
    # `source`: both this function and `resolve_artifact_path` read it by
    # attribute, so a dict naming a workspace source would silently resolve
    # against the local path instead — and the warning below would then name a
    # source that was never consulted.
    if isinstance(entry, dict):
        from ..utils.artifacts_meta import CodebaseEntry

        entry = CodebaseEntry.from_dict(entry)

    scan_targets = list(_resolve_code_scan_targets(session, entry))
    if traceability == "FULL" and not scan_targets:
        results.empty_full_codebase_entries.append({
            "path": _codebase_entry_path(entry),
            "source": str(getattr(entry, "source", "") or ""),
        })
    for file_path in scan_targets:
        try:
            rel_path = file_path.resolve().relative_to(session.project_root).as_posix()
        except ValueError as exc:
            logger.info(
                "Code file path %s is not under project root %s",
                file_path,
                session.project_root,
                exc_info=exc,
            )
            rel_path = None
        if rel_path and session.meta.is_ignored(rel_path):
            continue
        code_file, errors = CodeFile.from_path(file_path)
        if errors or code_file is None:
            if strict_code_validation and errors:
                results.all_errors.extend(errors)
            continue
        if traceability == "FULL":
            results.parsed_code_files_full.append(code_file)
        if strict_code_validation:
            code_report = code_file.validate()
            results.all_errors.extend(code_report.get("errors", []))
            results.all_warnings.extend(code_report.get("warnings", []))
        file_ids = code_file.list_ids()
        results.code_ids_found.update(file_ids)
        if file_ids or code_file.scope_markers or code_file.block_markers:
            results.code_files_scanned.append({
                "path": str(file_path),
                "scope_markers": len(code_file.scope_markers),
                "block_markers": len(code_file.block_markers),
                "ids_referenced": len(file_ids),
            })
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-code-scan


def _codebase_entry_path(entry: object) -> str:
    """Configured path of a codebase entry, which may be a record or a raw dict."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-code-scan
    if isinstance(entry, dict):
        return str(entry.get("path", ""))
    return str(getattr(entry, "path", ""))
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-code-scan


def _resolve_code_scan_targets(session: _ValidateSession, entry: object) -> List[Path]:
    """Resolve concrete files for one codebase entry."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-code-scan
    src_name = getattr(entry, "source", None)
    if src_name and session.ws_ctx is not None:
        code_path = session.ws_ctx.resolve_artifact_path(entry, session.project_root)
    else:
        code_path = (session.project_root / _codebase_entry_path(entry)).resolve()
    if code_path is None or not code_path.exists():
        return []
    # No early return for a single file: that bypassed the shared resolver
    # entirely, so a file entry was judged by this command and by the policy
    # differently -- which is the disagreement this resolver exists to end.
    extensions = (
        getattr(entry, "extensions", None)
        if not isinstance(entry, dict)
        else entry.get("extensions", None)
    ) or [".py"]
    # Resolved through the shared policy rather than a bare rglob: a registered
    # parent root otherwise re-admits the vendored and generated trees that
    # registration itself refuses, and this command's file count then disagrees
    # with every other consumer of the same entry.
    files, excluded = resolve_entry_code_files(code_path, extensions, project_root=session.project_root)
    session.code_files_excluded += excluded
    return files
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-code-scan


def _scan_system_codebase(
    system_node: object,
    *,
    session: _ValidateSession,
    results: _ValidateResults,
    strict_code_validation: bool,
    inherited_traceability: str = "DOCS-ONLY",
) -> None:
    """Recursively scan a system node's configured codebase entries.

    FULL traceability is inherited by descendants. A parent that owns the FULL
    artifact makes the claim; the code backing it often lives in a child system
    that has no artifact of its own. Deriving traceability from each node in
    isolation left such code out of the FULL set, so its markers were never
    cross-validated and a correctly marked implementation looked unmarked.
    """
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-code-scan
    traceability = (
        "FULL"
        if inherited_traceability == "FULL"
        or any(art.traceability == "FULL" for art in system_node.artifacts)
        else "DOCS-ONLY"
    )
    for codebase_entry in system_node.codebase:
        _scan_codebase_entry(
            entry=codebase_entry,
            traceability=traceability,
            session=session,
            results=results,
            strict_code_validation=strict_code_validation,
        )
    for child in system_node.children:
        _scan_system_codebase(
            child,
            session=session,
            results=results,
            strict_code_validation=strict_code_validation,
            inherited_traceability=traceability,
        )
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-code-scan


def _build_empty_codebase_entry_warnings(entries: List[Dict[str, str]]) -> List[Dict[str, object]]:
    """Warn for each FULL codebase entry that is registered but resolves to no files.

    A registered entry matching nothing is a configuration mistake -- usually a
    stale or misspelled path, or a workspace source that is not reachable -- and
    it silently shrinks what the run was able to check. It is reported separately
    from any unmet ID, because the subject is the registration rather than the
    claim. The workspace source is named when there is one, so two entries that
    share a path stay distinguishable and the reader knows whether to fix the
    source or the path.
    """
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-warn-empty-codebase-entry
    warnings: List[Dict[str, object]] = []
    for entry in entries:
        path = entry.get("path") or "<unset>"
        source = entry.get("source") or ""
        subject = f"`{source}:{path}`" if source else f"`{path}`"
        cause = (
            f"workspace source `{source}` did not resolve, or it resolved to an empty tree"
            if source
            else "the path does not exist, or it contains no files with the configured extensions"
        )
        warnings.append(
            code_issue(
                "structure",
                f"codebase entry {subject} is registered with FULL traceability but "
                f"resolved to 0 files — nothing from it was checked ({cause})",
                code=EC.CODEBASE_ENTRY_EMPTY,
                path=Path(path if path != "<unset>" else "."),
                source=source or None,
            )
        )
    return warnings
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-warn-empty-codebase-entry


def _run_code_validation(
    session: _ValidateSession,
    results: _ValidateResults,
    all_artifacts_for_cross: List[ArtifactRecord],
) -> None:
    """Run code traceability validation unless disabled by CLI flags."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-if-code
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-code-run
    traceability_by_path = _build_traceability_by_path(session.artifacts_to_validate)
    full_ids_to_check = _collect_full_traceability_ids(session.artifacts_to_validate)
    strict_code_validation = not session.args.artifact
    should_scan_code = (not session.args.skip_code) and (strict_code_validation or bool(full_ids_to_check))
    to_code_ids_task_unchecked: Set[str] = set()
    artifact_ids: Set[str] = set()
    if strict_code_validation and all_artifacts_for_cross:
        artifact_ids, results.to_code_ids, to_code_ids_task_unchecked = _collect_artifact_code_expectations(
            all_artifacts_for_cross,
            traceability_by_path,
            session.registered_systems,
        )
    if not session.args.local_only and session.ws_ctx is not None:
        artifact_ids.update(session.ws_ctx.get_all_artifact_ids())
    if not should_scan_code:
        return
    for system_node in session.meta.systems:
        _scan_system_codebase(
            system_node,
            session=session,
            results=results,
            strict_code_validation=strict_code_validation,
        )
    if not strict_code_validation:
        return
    results.all_warnings.extend(
        _build_empty_codebase_entry_warnings(results.empty_full_codebase_entries)
    )
    if not results.parsed_code_files_full and not results.to_code_ids:
        return
    artifact_instances, artifact_instances_all = _collect_full_artifact_instances(
        all_artifacts_for_cross,
        traceability_by_path,
    )
    code_validation = cross_validate_code(
        results.parsed_code_files_full,
        artifact_ids,
        results.to_code_ids,
        forbidden_code_ids=to_code_ids_task_unchecked,
        traceability="FULL",
        artifact_instances=artifact_instances,
        artifact_instances_all=artifact_instances_all,
    )
    results.all_errors.extend(code_validation.get("errors", []))
    results.all_warnings.extend(code_validation.get("warnings", []))
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-code-run
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-if-code


def _build_traceability_by_path(
    artifacts_to_validate: List[Tuple[Path, Path, str, str, str]],
) -> Dict[str, str]:
    """Build a quick artifact-path to traceability lookup."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-traceability-index
    return {
        str(artifact_path): traceability
        for artifact_path, _template_path, _artifact_type, traceability, _kit_id in artifacts_to_validate
    }
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-traceability-index


def _collect_full_traceability_ids(
    artifacts_to_validate: List[Tuple[Path, Path, str, str, str]],
) -> Set[str]:
    """Collect definition IDs from FULL-traceability artifacts."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-traceability-index
    full_ids_to_check: Set[str] = set()
    for artifact_path, _template_path, _artifact_kind, traceability, _kit_id in artifacts_to_validate:
        if traceability != "FULL":
            continue
        try:
            for hit in scan_cpt_ids(artifact_path):
                if hit.get("type") == "definition" and hit.get("id"):
                    full_ids_to_check.add(str(hit["id"]))
        except (OSError, ValueError) as exc:
            _warn_validate(f"failed to collect definition ids from {artifact_path}: {exc}")
            continue
    return full_ids_to_check
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-traceability-index


def _run_reference_coverage(
    session: _ValidateSession,
    results: _ValidateResults,
    all_artifacts_for_cross: List[ArtifactRecord],
) -> None:
    """Enforce fallback cross-reference coverage for unconstrained artifact kinds."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-reference-coverage
    if not all_artifacts_for_cross:
        return
    code_references_available = not session.args.skip_code
    present_kinds, refs_by_id = _build_reference_index(all_artifacts_for_cross)
    validated_paths = {str(path) for path, _, _, _, _ in session.artifacts_to_validate}
    traceability_by_path = _build_traceability_by_path(session.artifacts_to_validate)
    for artifact in all_artifacts_for_cross:
        _apply_reference_coverage_for_artifact(
            artifact,
            present_kinds=present_kinds,
            refs_by_id=refs_by_id,
            validated_paths=validated_paths,
            traceability_by_path=traceability_by_path,
            code_ids_found=results.code_ids_found,
            code_references_available=code_references_available,
            results=results,
            verbose=bool(session.args.verbose),
        )
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-reference-coverage


def _build_reference_index(
    all_artifacts_for_cross: List[ArtifactRecord],
) -> Tuple[Set[str], Dict[str, Set[str]]]:
    """Build present-kind and reference indices across all artifacts."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-traceability-index
    present_kinds: Set[str] = set()
    refs_by_id: Dict[str, Set[str]] = {}
    for artifact in all_artifacts_for_cross:
        kind = str(getattr(artifact, "artifact_kind", "") or "")
        present_kinds.add(kind)
        try:
            for hit in scan_cpt_ids(artifact.path):
                if hit.get("type") != "reference":
                    continue
                ref_id = str(hit.get("id") or "").strip()
                if ref_id:
                    refs_by_id.setdefault(ref_id, set()).add(kind)
        except (OSError, ValueError) as exc:
            _warn_validate(f"failed to index references in {artifact.path}: {exc}")
            continue
    return present_kinds, refs_by_id
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-traceability-index


# pylint: disable-next=too-many-arguments,too-many-locals
def _apply_reference_coverage_for_artifact(
    artifact: ArtifactRecord,
    *,
    present_kinds: Set[str],
    refs_by_id: Dict[str, Set[str]],
    validated_paths: Set[str],
    traceability_by_path: Dict[str, str],
    code_ids_found: Set[str],
    code_references_available: bool,
    results: _ValidateResults,
    verbose: bool,
) -> None:
    """Apply fallback coverage rules to one artifact without explicit constraints."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-reference-coverage
    artifact_path_str = str(artifact.path)
    if artifact_path_str not in validated_paths or getattr(artifact, "constraints", None) is not None:
        return
    kind = str(getattr(artifact, "artifact_kind", "") or "")
    other_kinds = sorted(candidate for candidate in present_kinds if candidate != kind)
    art_traceability = traceability_by_path.get(artifact_path_str, "FULL")
    try:
        definitions = [hit for hit in scan_cpt_ids(artifact.path) if hit.get("type") == "definition" and hit.get("id")]
    except (OSError, ValueError) as exc:
        _warn_validate(f"failed to read definition ids from {artifact.path}: {exc}")
        definitions = []
    for definition in definitions:
        _apply_reference_coverage_for_definition(
            artifact=artifact,
            definition=definition,
            other_kinds=other_kinds,
            refs_by_id=refs_by_id,
            art_traceability=art_traceability,
            code_ids_found=code_ids_found,
            code_references_available=code_references_available,
            results=results,
            verbose=verbose,
        )
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-reference-coverage


# pylint: disable-next=too-many-arguments
def _apply_reference_coverage_for_definition(
    *,
    artifact: ArtifactRecord,
    definition: Dict[str, object],
    other_kinds: List[str],
    refs_by_id: Dict[str, Set[str]],
    art_traceability: str,
    code_ids_found: Set[str],
    code_references_available: bool,
    results: _ValidateResults,
    verbose: bool,
) -> None:
    """Apply fallback coverage rules to one definition hit."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-reference-coverage
    defined_id = str(definition.get("id") or "").strip()
    if not defined_id:
        return
    line = int(definition.get("line", 1) or 1)
    if not other_kinds:
        warning = constraints_error(
            "structure",
            f"`{defined_id}` is not referenced — no other artifact kinds exist in scope for cross-referencing",
            code=EC.ID_NOT_REFERENCED_NO_SCOPE,
            path=artifact.path,
            line=line,
            id=defined_id,
        )
        results.all_warnings.append(warning)
        _attach_issue_to_artifact_report(warning, results=results, verbose=verbose, is_error=False)
        return
    kind = str(getattr(artifact, "artifact_kind", "") or "")
    referenced_kinds = sorted(candidate for candidate in refs_by_id.get(defined_id, set()) if candidate != kind)
    if referenced_kinds or (
        art_traceability == "FULL"
        and code_references_available
        and defined_id in code_ids_found
    ):
        return
    error = constraints_error(
        "structure",
        f"`{defined_id}` (defined in {kind}) is not referenced from any of {other_kinds}",
        code=EC.ID_NOT_REFERENCED,
        path=artifact.path,
        line=line,
        id=defined_id,
        other_kinds=other_kinds,
    )
    results.all_errors.append(error)
    _attach_issue_to_artifact_report(error, results=results, verbose=verbose, is_error=True)
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-reference-coverage


# @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-explain-severity
def _explained_kinds(session: _ValidateSession) -> List[Optional[str]]:
    """List the artifact kinds to explain, or ``[None]`` for the unscoped view."""
    if session.args.kind:
        return [str(session.args.kind).strip().upper()]
    kinds = {
        str(kind).strip().upper()
        for kit in (getattr(session.ctx, "kits", None) or {}).values()
        for kind in ((getattr(kit, "constraints", None).by_kind or {})
                     if getattr(kit, "constraints", None) is not None else {})
    }
    # A project can scope a rule to a kind no installed kit declares
    # constraints for, and the resolver honours that. Leaving those kinds out
    # of the inventory would hide the very settings the reader came to check.
    kinds.update(session.policy.project.by_kind)
    kinds.update(session.policy.kit.by_kind)
    kinds.update(session.policy.entries)
    return sorted(kinds) or [None]


def _explained_rule_row(
    session: _ValidateSession,
    code: str,
    kind: Optional[str],
    key: Optional[Tuple[str, str]],
) -> Dict[str, object]:
    """One `--explain-severity` row: the effective value and where it came from."""
    decision = session.policy.resolve(code, kind, key)
    row: Dict[str, object] = {
        "code": code,
        "kind": kind,
        "severity": decision.severity,
        "source": decision.source,
    }
    if key is not None:
        row["entry"] = f"{key[0]}:{key[1]}"
    if decision.refused_from:
        row["refused"] = override_row(code, kind, key, decision)
    return row


def _emit_severity_explanation(session: _ValidateSession) -> int:
    """Report the effective severity of every rule, and the layer that set it."""
    rule_filter = str(session.args.rule).strip() if session.args.rule else None
    codes = sorted({
        value for name, value in vars(EC).items()
        if name.isupper() and isinstance(value, str)
    })
    if rule_filter:
        codes = [code for code in codes if code == rule_filter]
        if not codes:
            ui.result({
                "status": "ERROR",
                "message": f"no such rule code: {session.args.rule}",
            })
            return 1
    rows: List[Dict[str, object]] = []
    for kind in _explained_kinds(session):
        for code in codes:
            # Unscoped first, then once per entry that declares anything for
            # this kind. Explaining only the unscoped value would report the
            # per-kind or default severity for a rule a heading or ID-kind
            # entry has actually overridden — the one case a reader is most
            # likely to be asking about.
            for key in [None] + list(session.policy.entry_keys_for(kind)):
                rows.append(_explained_rule_row(session, code, kind, key))
    # Sorted by (kind, code, entry) so two runs over one configuration read the
    # same way, and a diff of the output means what it appears to mean.
    rows.sort(key=lambda row: (
        str(row["kind"] or ""), str(row["code"]), str(row.get("entry") or "")))
    ui.result({
        "status": "PASS",
        "configured": session.policy.is_configured(),
        "fail_on_warnings": session.policy.fail_on_warnings,
        "rules": rows,
        "severity_overrides": declared_overrides(session.policy),
    }, human_fn=_human_explain_severity)
    return 0


#: Rows the severity explanation prints before truncating, matching the
#: 30-row cap `_human_validate` uses for errors.
_EXPLAIN_ROW_CAP = 30


def _human_explain_severity(data: dict) -> None:
    """Render the severity explanation for a terminal.

    Without this the command falls to the generic result renderer, which reads
    only `status` and prints `Done (PASS)` — the whole answer discarded for
    every caller who did not think to add `--json`, which is most of them.
    """
    ui.header("Effective severity")
    ui.detail("Configured", "yes" if data.get("configured") else "no (built-in defaults only)")
    ui.detail("Fail on warnings", "yes" if data.get("fail_on_warnings") else "no")

    ui.blank()
    # One exit, one call to each renderer. An early return for the empty case
    # would need its own copy of the overrides call, and a copy is a thing a
    # later edit can drop from one branch while the other keeps passing.
    _show_explained_rules(data.get("rules") or [])
    _show_severity_overrides(data.get("severity_overrides") or [])
    ui.blank()


def _show_explained_rules(rules: List[Dict[str, object]]) -> None:
    """Print the resolved-severity table, capped like every other listing here."""
    if not rules:
        ui.info("No rules matched.")
        return
    # 85 rule codes times the kinds times their entries is an unreadable dump,
    # and the reader who wants all of it wants `--json` — while the reader who
    # wants one rule has `--rule`, which the remainder line points at.
    shown = rules[:_EXPLAIN_ROW_CAP]
    ui.table(
        ["Rule", "Kind", "Entry", "Severity", "Set by"],
        [[
            str(row.get("code") or ""),
            str(row.get("kind") or "(any)"),
            str(row.get("entry") or ""),
            str(row.get("severity") or ""),
            str(row.get("source") or ""),
        ] for row in shown],
    )
    if len(rules) > len(shown):
        ui.substep(
            f"  ... and {len(rules) - len(shown)} more rule(s) "
            "— narrow with --kind/--rule, or use --json for all of them"
        )
# @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-explain-severity


# @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-apply-policy
def _record_refusals(results: _ValidateResults, rows: List[Dict[str, object]]) -> None:
    """Collect refusals across passes, once per refused rule.

    The per-artifact pass and the command-level pass both meet the same
    surviving finding, and each records the refusal its own resolution
    produced. Deduplicating on the rule rather than the finding keeps one
    refused rule reading as one line however many findings it covered, and
    however many passes saw them.
    """
    seen = {(row.get("code"), row.get("kind"), row.get("entry")) for row in results.refusals}
    for row in rows:
        identity = (row.get("code"), row.get("kind"), row.get("entry"))
        if identity in seen:
            continue
        seen.add(identity)
        results.refusals.append(row)


def _apply_run_policy(session: _ValidateSession, results: _ValidateResults) -> None:
    """Settle severity for every finding the per-artifact pass did not."""
    outcome = apply_policy(session.policy, list(results.all_errors) + list(results.all_warnings))
    results.all_errors = outcome.errors
    results.all_warnings = outcome.warnings
    results.suppressed_count += outcome.suppressed
    _record_refusals(results, outcome.refusals)
    _reconcile_artifact_reports(results)


def _reconcile_artifact_reports(results: _ValidateResults) -> None:
    """Recount every per-artifact report from the settled aggregate lists.

    Cross-artifact, code and reference findings are attached to their artifact
    before policy runs, so a rule the project lowered or switched off would
    otherwise leave the artifact's own status and counts describing the
    pre-policy world — a top-level PASS containing an artifact marked FAIL.
    """
    settled: Dict[str, Dict[str, int]] = {}
    for bucket, findings in (("error_count", results.all_errors), ("warning_count", results.all_warnings)):
        for finding in findings:
            counts = settled.setdefault(str(finding.get("path", "") or ""), {})
            counts[bucket] = counts.get(bucket, 0) + 1
    for path, report in results.artifact_report_by_path.items():
        counts = settled.get(path, {})
        errors = counts.get("error_count", 0)
        report["error_count"] = errors
        report["warning_count"] = counts.get("warning_count", 0)
        report["status"] = "PASS" if not errors else "FAIL"
        for key, bucket in (("errors", results.all_errors), ("warnings", results.all_warnings)):
            if isinstance(report.get(key), list):
                report[key] = [f for f in bucket if str(f.get("path", "") or "") == path]


def _attach_policy_report(
    report: Dict[str, object],
    session: _ValidateSession,
    results: _ValidateResults,
) -> None:
    """Name what the policy changed, whenever it changed anything.

    Emitted without waiting to be asked. `--explain-severity` answers a
    question, and the reader who most needs to know a rule was switched off is
    the one who does not know to ask.
    """
    if results.suppressed_count:
        report["suppressed_count"] = results.suppressed_count
    overrides = _merge_overrides(declared_overrides(session.policy), results.refusals)
    if overrides:
        report["severity_overrides"] = overrides


def _merge_overrides(
    declared: List[Dict[str, object]],
    refusals: List[Dict[str, object]],
) -> List[Dict[str, object]]:
    """Combine configuration-derived and encountered overrides, each once.

    Both sources are needed and they overlap. The declared list covers rules
    that never fired — including a lowering to `off`, which by definition emits
    nothing. The encountered list covers refusals on entries the tables cannot
    be asked about ahead of time. A refusal that both find is one decision, and
    belongs in the report once.
    """
    merged = list(declared)
    seen = {(row.get("code"), row.get("kind"), row.get("entry")) for row in merged}
    for row in refusals:
        identity = (row.get("code"), row.get("kind"), row.get("entry"))
        if identity in seen:
            continue
        seen.add(identity)
        merged.append(row)
    return sorted(
        merged,
        key=lambda row: (
            str(row.get("kind") or ""), str(row.get("code") or ""), str(row.get("entry") or "")),
    )
# @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-apply-policy


def _emit_final_validate_report(session: _ValidateSession, results: _ValidateResults) -> int:
    """Enrich issues and emit the final validate report."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-return-report
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-output
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-enrich-errors
    # Everything the per-artifact pass did not already settle: cross-artifact
    # findings, code traceability, reference coverage, context errors. Findings
    # that carry their own `artifact_kind` resolve against it; the rest resolve
    # unscoped. Re-running this over the already-settled ones changes nothing.
    _apply_run_policy(session, results)
    # Both lists. Policy has just repartitioned them, so a reference rule a
    # project lowered to `warning` now sits in `all_warnings` — and enriching
    # only the errors would strip the target path from exactly the findings a
    # team is migrating gradually, which is when they most need the hint.
    for settled in (results.all_errors, results.all_warnings):
        _enrich_target_artifact_paths(settled, meta=session.meta, project_root=session.project_root)
    enrich_issues(results.all_errors, project_root=session.project_root)
    enrich_issues(results.all_warnings, project_root=session.project_root)
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-enrich-errors
    verdict = run_verdict(
        len(results.all_errors),
        len(results.all_warnings),
        fail_on_warnings=session.policy.fail_on_warnings,
    )
    overall_status = verdict.status
    report: Dict[str, object] = {
        "status": overall_status,
        "artifacts_validated": len(results.artifact_reports),
        "error_count": len(results.all_errors),
        "warning_count": len(results.all_warnings),
    }
    if verdict.failed_on:
        report["failed_on"] = verdict.failed_on
    _attach_policy_report(report, session, results)
    if not session.args.skip_code and not session.args.artifact:
        report["code_files_scanned"] = len(results.code_files_scanned)
        # A scanned total without the number excluded does not say whether
        # the scope was the one the reader assumed.
        report["code_files_excluded"] = session.code_files_excluded
        report["to_code_ids_total"] = len(results.to_code_ids)
        report["code_ids_found"] = len(results.code_ids_found)
        if results.to_code_ids:
            report["coverage"] = f"{len(results.code_ids_found & results.to_code_ids)}/{len(results.to_code_ids)}"
        # Named unconditionally: a passing run has to be able to say what it did
        # not check, and warning bodies are omitted from a non-verbose report.
        if results.empty_full_codebase_entries:
            report["unscanned_codebase_entries"] = [
                f"{entry['source']}:{entry['path']}" if entry.get("source") else entry["path"]
                for entry in results.empty_full_codebase_entries
            ]
    if overall_status == "PASS":
        report["next_step"] = (
            "Deterministic validation passed. Now perform semantic validation: "
            "review content quality against checklist.md criteria."
        )
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-emit-warnings
    # Both lists, always. A passing non-verbose run used to withhold `warnings`
    # entirely, so the only consumer that could see a warning was one that had
    # already been told to expect a failure.
    report["errors"] = results.all_errors
    report["warnings"] = results.all_warnings
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-emit-warnings
    if overall_status == "PASS" and not session.args.verbose:
        failed_artifacts = [item for item in results.artifact_reports if item.get("status") == "FAIL"]
        if failed_artifacts:
            report["failed_artifacts"] = [
                {"artifact": item.get("artifact"), "error_count": item.get("error_count")}
                for item in failed_artifacts
            ]
    # Telemetry: record the authoritative final validation verdict. It inherits the
    # run's decision id from the dispatcher, correlating to the invocation. record()
    # is fail-safe (never raises into the caller), so no guard is needed here.
    # `findings` is what decided the verdict. Before `fail_on_warnings`, FAIL
    # always implied errors, so the error count was the whole story; a
    # warning-only failure recorded as `findings: 0` would read as a failure
    # with nothing behind it.
    decision_log.record_validation(
        "validate",
        overall_status,
        findings=(len(results.all_warnings) if verdict.failed_on == "warnings"
                  else len(results.all_errors)),
        rules={
            "errors": len(results.all_errors),
            "warnings": len(results.all_warnings),
            "suppressed": results.suppressed_count,
        },
    )
    _emit_validate_output(
        report,
        output_path=session.args.output,
        human=True,
        pretty=bool(session.args.verbose) or (overall_status != "PASS"),
    )
    return verdict.exit_code
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-output
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-return-report


# @cpt-flow:cpt-studio-flow-traceability-validation-validate:p1
# @cpt-dod:cpt-studio-dod-traceability-validation-cross-refs:p1
# @cpt-dod:cpt-studio-dod-traceability-validation-cdsl:p1
def cmd_validate(argv: List[str]) -> int:
    """Validate Constructor Studio artifacts and code traceability.

    Performs deterministic validation checks (structure, cross-references,
    task statuses, traceability markers) and produces a machine-readable report.
    """
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-user-validate
    session, exit_code = _build_validate_session(_parse_validate_args(argv))
    if exit_code is not None or session is None:
        return 1 if exit_code is None else exit_code
    if session.args.explain_severity:
        return _emit_severity_explanation(session)
    exit_code = _resolve_artifacts_to_validate(session)
    if exit_code is not None:
        return exit_code
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-self-check
    # validate-kits gate runs during session construction and has already passed here
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-self-check
    results, exit_code = _run_initial_artifact_validation(session)
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-if-structure-fail
    if exit_code is not None:
        return exit_code
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-if-structure-fail
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-if-registry-fail
    # registry-level failures are handled inside _run_initial_artifact_validation()
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-if-registry-fail
    all_artifacts_for_cross = _build_cross_validation_context(session, results)
    _run_cross_validation(session, results, all_artifacts_for_cross)
    _run_code_validation(session, results, all_artifacts_for_cross)
    _run_reference_coverage(session, results, all_artifacts_for_cross)
    return _emit_final_validate_report(session, results)
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-user-validate

# @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-helpers
def _enrich_target_artifact_paths(
    issues: List[Dict[str, object]],
    *,
    meta: object,
    project_root: Path,
) -> None:
    """Add ``target_artifact_path`` to 'ID not referenced from required artifact kind' findings.

    Called for both settled buckets. The rule defaults to ``error``, but a
    project may lower it to ``warning`` as a migration step, and the hint is
    what makes that step actionable — so enrichment follows the finding rather
    than the severity it happens to have ended up with.

    Three outcomes per finding:
    - ``target_artifact_path`` set  → artifact exists, prompt says "in `path`"
    - ``target_artifact_suggested_path`` set → artifact missing, autodetect knows where → "create `path`"
    - neither set → no autodetect rule → prompt asks LLM to request path from user
    """
    from ..utils.artifacts_meta import ArtifactsMeta

    if not isinstance(meta, ArtifactsMeta):
        return

    for issue in issues:
        if str(issue.get("code") or "") != EC.REF_MISSING_FROM_KIND:
            continue

        target_kind = str(issue.get("target_kind") or "").upper()
        if not target_kind:
            continue

        # Find the system node that owns the source artifact
        src_path = str(issue.get("path") or "")
        try:
            rel_src = Path(src_path).relative_to(project_root).as_posix()
        except (ValueError, TypeError) as exc:
            _warn_validate(f"skipping issue with non-project path {src_path!r}: {exc}")
            continue

        result = meta.get_artifact_by_path(rel_src)
        if not result:
            continue
        _, system_node = result

        # Search system's artifacts for an existing artifact of target_kind
        target_path = _find_artifact_in_system(system_node, target_kind, project_root)
        if target_path:
            issue["target_artifact_path"] = target_path
            continue

        # No existing artifact — check autodetect rules for suggested path
        suggested = _suggest_path_from_autodetect(system_node, target_kind)
        if suggested:
            issue["target_artifact_suggested_path"] = suggested
        # else: neither set → fixing.py will ask user

def _find_artifact_in_system(node: object, target_kind: str, project_root: Path) -> Optional[str]:
    """Search system node and its children for an existing artifact of target_kind.

    Returns relative path string if found, else None.
    """
    from ..utils.artifacts_meta import SystemNode

    if not isinstance(node, SystemNode):
        return None
    for art in (node.artifacts or []):
        if str(art.kind).upper() == target_kind:
            full = (project_root / art.path).resolve()
            if full.exists():
                return str(full)
    for child in (node.children or []):
        found = _find_artifact_in_system(child, target_kind, project_root)
        if found:
            return found
    return None

def _suggest_path_from_autodetect(node: object, target_kind: str) -> Optional[str]:
    """Derive a suggested file path from autodetect rules for a missing artifact.

    Returns a project-root-relative path like ``architecture/DESIGN.md``, or None.
    """
    from ..utils.artifacts_meta import SystemNode

    if not isinstance(node, SystemNode):
        return None

    for rule in (node.autodetect or []):
        arts = rule.artifacts or {}
        kind_upper = {str(k).upper(): k for k in arts}
        orig_key = kind_upper.get(target_kind)
        if not orig_key:
            continue
        ap = arts[orig_key]
        pattern = str(ap.pattern or "")
        if not pattern:
            continue

        # Compute artifacts_root with simple substitution
        system_root = str(rule.system_root or "{project_root}")
        system_root = system_root.replace("{project_root}", ".")
        system_root = system_root.replace("{system}", node.slug or "")

        arts_root = str(rule.artifacts_root or "{system_root}")
        arts_root = arts_root.replace("{system_root}", system_root)
        arts_root = arts_root.replace("{project_root}", ".")
        arts_root = arts_root.replace("{system}", node.slug or "")

        # If pattern is a simple filename (no glob chars), use it directly
        if "*" not in pattern and "?" not in pattern:
            suggested = f"{arts_root}/{pattern}"
        else:
            # Glob pattern — suggest conventional {KIND}.md
            suggested = f"{arts_root}/{target_kind}.md"

        # Normalize: strip leading "./"
        suggested = suggested.lstrip("./")
        if suggested.startswith("/"):
            suggested = suggested.lstrip("/")
        return suggested

    return None
# @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-helpers

# ---------------------------------------------------------------------------
# Content language check helper
# ---------------------------------------------------------------------------

def _load_language_validation_settings(project_root: "Path") -> Tuple[Optional[List[str]], list]:
    """Load configured allowed content languages and any config-load errors."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-language-config
    from ..utils.constraints import error as _error
    from ..utils import error_codes as _EC

    try:
        from ..utils.workspace import find_workspace_config as _find_ws
        ws_cfg, ws_err = _find_ws(project_root)
    except (ImportError, OSError, AttributeError) as exc:
        return None, [_error(
            "language",
            f"Cannot load workspace config for language check: {exc}",
            path=project_root,
            line=1,
            code=_EC.FILE_LOAD_ERROR,
        )]

    if ws_err:
        return None, [_error(
            "language",
            f"Workspace config error, language validation skipped: {ws_err}",
            path=project_root,
            line=1,
            code=_EC.FILE_LOAD_ERROR,
        )]

    validation = getattr(ws_cfg, "validation", None) if ws_cfg is not None else None
    return getattr(validation, "allowed_content_languages", None), []
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-language-config


def _scan_artifact_language_violations(
    artifact_path: Path,
    allowed_langs: List[str],
    allowed_ranges: object,
    *,
    artifact_kind: Optional[str] = None,
) -> list:
    """Scan one artifact for language violations.

    The kind is stamped like every other per-file finding: without it a
    per-kind severity could never reach a language violation, and the caller
    already knows which artifact it is scanning.
    """
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-language-scan
    from ..utils.constraints import error as _error
    from ..utils import error_codes as _EC
    from ..utils.content_language import LangScanError as _LangScanError, scan_file as _scan_file

    results = []
    try:
        for violation in _scan_file(artifact_path, allowed_ranges):
            results.append(_error(
                "language",
                f"Non-allowed characters [{violation.bad_chars_preview()}] -- {violation.line_preview()}",
                path=artifact_path,
                line=violation.lineno,
                code=_EC.CONTENT_LANGUAGE_VIOLATION,
                allowed_languages=allowed_langs,
                artifact_kind=artifact_kind,
            ))
    except _LangScanError as exc:
        results.append(_error(
            "language",
            f"Cannot read file for language check: {exc.cause}",
            path=artifact_path,
            line=1,
            code=_EC.FILE_READ_ERROR,
            artifact_kind=artifact_kind,
        ))
    return results
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-language-scan

def _run_content_language_check(
    artifacts_to_validate: list,
    project_root: "Path",
) -> list:
    """Return language-violation error dicts for all validated .md artifacts.

    Uses project_root to discover the workspace config so the check works in
    both workspace mode and single-repo mode.  Returns an empty list when
    allowed_content_languages is not configured.

    Config failures (malformed .cf-workspace.toml) are surfaced as
    FILE_LOAD_ERROR entries rather than silently disabling validation.
    """
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-language-run
    try:
        from ..utils.content_language import build_allowed_ranges
    except ImportError as exc:
        _warn_validate(f"content-language validation is unavailable: {exc}")
        return []

    allowed_langs, config_errors = _load_language_validation_settings(project_root)
    if config_errors:
        return config_errors
    if not allowed_langs:
        return []

    allowed_ranges = build_allowed_ranges(allowed_langs)
    results = []
    for artifact_path, _template_path, artifact_type, _traceability, _kit_id in artifacts_to_validate:
        if artifact_path.suffix.lower() != ".md":
            continue
        results.extend(_scan_artifact_language_violations(
            artifact_path, allowed_langs, allowed_ranges, artifact_kind=str(artifact_type)))
    return results
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-language-run


# ---------------------------------------------------------------------------
# Human-friendly formatter
# ---------------------------------------------------------------------------

# @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-format
def _show_unscanned_codebase_entries(unscanned: List[str]) -> None:
    """Name the registered entries that resolved to no files, if any."""
    if not unscanned:
        return
    ui.blank()
    ui.warn(
        f"{len(unscanned)} registered codebase "
        f"{'entry' if len(unscanned) == 1 else 'entries'} resolved to 0 files "
        "— nothing from them was checked"
    )
    for entry in unscanned[:10]:
        ui.substep(f"  {entry}")
    if len(unscanned) > 10:
        ui.substep(f"  ... and {len(unscanned) - 10} more")


def _human_validate(data: dict) -> None:
    status = data.get("status", "")
    n_art = data.get("artifacts_validated", data.get("artifact_count", 0))
    n_err = data.get("error_count", 0)
    n_warn = data.get("warning_count", 0)

    ui.header("Validate")
    ui.detail("Artifacts", str(n_art))
    ui.detail("Errors", str(n_err))
    ui.detail("Warnings", str(n_warn))
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-human-suppressed
    # Named at the terminal, not only in JSON. `--explain-severity` answers a
    # question; a run with fourteen rules switched off otherwise looks exactly
    # like a run with none to the reader who never thought to ask.
    if data.get("suppressed_count"):
        # "off" covers both a rule this project switched off and one that ships
        # off until a kit asks for it, so the wording names the state rather
        # than an action nobody here necessarily took.
        ui.detail("Suppressed", f"{data['suppressed_count']} (rules that are off)")
    _show_severity_overrides(data.get("severity_overrides") or [])
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-human-suppressed

    if data.get("code_files_scanned") is not None:
        excluded = data.get("code_files_excluded") or 0
        scanned = str(data["code_files_scanned"])
        ui.detail("Code files", f"{scanned} ({excluded} excluded)" if excluded else scanned)
    if data.get("coverage"):
        ui.detail("Code coverage", str(data["coverage"]))

    _show_unscanned_codebase_entries(data.get("unscanned_codebase_entries", []))

    errors = data.get("errors", [])
    if errors:
        ui.blank()
        for e in errors[:30]:
            _format_issue(e, is_error=True)
        if len(errors) > 30:
            ui.substep(f"  ... and {len(errors) - 30} more error(s)")

    warnings = data.get("warnings", [])
    if warnings:
        ui.blank()
        for w in warnings[:15]:
            _format_issue(w, is_error=False)
        if len(warnings) > 15:
            ui.substep(f"  ... and {len(warnings) - 15} more warning(s)")

    ui.blank()
    _show_validate_verdict(data, status=status, n_err=n_err, n_warn=n_warn)
    ui.blank()


def _show_validate_verdict(data: dict, *, status: str, n_err: int, n_warn: int) -> None:
    """Print the one-line verdict, naming warnings when warnings decided it."""
    if status == "PASS":
        ui.success("All checks passed.")
        if data.get("next_step"):
            ui.hint(str(data["next_step"]))
        return
    if status != "FAIL":
        ui.info(f"Status: {status}")
        return
    if data.get("failed_on") == "warnings":
        ui.error(f"Validation failed on warnings — {n_warn} warning(s), 0 errors.")
    else:
        ui.error(f"Validation failed — {n_err} error(s).")


# @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-human-suppressed
def _show_severity_overrides(overrides: List[Dict[str, object]]) -> None:
    """List rules the project lowered, and any the kit refused to let it lower."""
    if not overrides:
        return
    for row in overrides[:10]:
        scope = str(row.get("kind") or "all kinds")
        entry = f" entry {row['entry']}" if row.get("entry") else ""
        change = f"{row.get('from')} -> {row.get('to')}"
        verb = "lowered" if row.get("applied") else "REFUSED (locked)"
        ui.detail(f"  {row.get('code')} [{scope}]{entry}", f"{change} {verb}")
    if len(overrides) > 10:
        ui.substep(f"  ... and {len(overrides) - 10} more severity override(s)")
# @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-human-suppressed

def _issue_location(issue: dict) -> str:
    """Extract display location from an issue dict, relative to cwd."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-issue-format
    loc = str(issue.get("location") or "")
    if not loc:
        path = str(issue.get("path") or "")
        line = issue.get("line", "")
        if path:
            loc = f"{path}:{line}" if line else path
    if not loc:
        return ""
    if ":" in loc:
        parts = loc.rsplit(":", 1)
        if parts[1].isdigit():
            return f"{ui.relpath(parts[0])}:{parts[1]}"
    return ui.relpath(loc)
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-issue-format


def _emit_issue_header(loc: str, code: str, msg: str, *, is_error: bool) -> None:
    """Emit the main issue heading and message."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-issue-format
    header_parts = []
    if loc:
        header_parts.append(loc)
    if code:
        header_parts.append(f"[{code}]")

    if header_parts:
        header_text = " ".join(header_parts)
        if is_error:
            ui.warn(header_text)
        else:
            ui.substep(f"  > {header_text}")
        if msg:
            ui.substep(f"    {msg}")
        return

    if is_error:
        ui.warn(msg)
    else:
        ui.substep(f"  > {msg}")
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-issue-format


def _emit_issue_extras(issue: dict) -> bool:
    """Emit structured extra fields for an issue."""
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-issue-format
    has_extra = False
    reasons = issue.get("reasons")
    if isinstance(reasons, list) and reasons:
        for reason in reasons:
            ui.substep(f"    -> {reason}")
        has_extra = True

    fixing = issue.get("fixing_prompt")
    if fixing:
        ui.substep(f"    Fix: {fixing}")
        has_extra = True

    handled_keys = {
        "type", "message", "code", "line", "path", "location",
        "reasons", "fixing_prompt",
    }
    for key, value in issue.items():
        if key in handled_keys or value is None or not value or value == []:
            continue
        if isinstance(value, list):
            ui.substep(f"    {key}: {', '.join(str(item) for item in value)}")
        else:
            ui.substep(f"    {key}: {value}")
        has_extra = True
    return has_extra
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-issue-format


def _format_issue(issue: object, *, is_error: bool) -> None:
    """Format a single error/warning with all available fields.

    Generic: iterates ALL keys in the dict so no information is ever lost.
    Special formatting for known structural keys (location, message, code,
    reasons, fixing_prompt); everything else auto-formatted as key: value.
    """
    # @cpt-begin:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-issue-format
    if not isinstance(issue, dict):
        if is_error:
            ui.warn(str(issue))
        else:
            ui.substep(f"  \u25b8 {issue}")
        return

    msg = issue.get("message", "")
    code = issue.get("code", "")
    loc = _issue_location(issue)
    _emit_issue_header(loc, str(code), str(msg), is_error=is_error)
    has_extra = _emit_issue_extras(issue)

    if has_extra:
        ui.blank()
    # @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-issue-format
# @cpt-end:cpt-studio-flow-traceability-validation-validate:p1:inst-validate-format
