# Plan Assess

```pdsl
UNIT PlanPhase1Assess
PURPOSE: Identify task type, extract target-workflow rules, estimate size, and scan every interaction point (Phase 1).
STATE:
  SET task_type: generate | analyze | implement (default unset, scope workflow_run)
DO:
  RUN map the request to a task_type and its target workflow (generate -> generate.md, analyze -> analyze.md, implement -> generate.md code mode)
  RUN extract the target workflow's navigation rules, estimate compiled size, and scan for every user interaction point (questions, confirmations, decisions, reviews, required inputs) so phases assign them
  RUN resolve the target artifact, {task-slug}, target_key, and input_signature; SET plan_dir = {cf-studio-path}/.plans/{task-slug}/
  LOAD {cf-studio-path}/.core/requirements/raw-input-overflow.md and chunk raw input under {cf-studio-path}/.plans/{task-slug}/input/ WHEN the raw task input exceeds 500 lines
  CONTINUE PlanPhase2Decompose
RULES:
  ALWAYS treat kit rules as law, and ALWAYS capture every interaction point so phases assign them
```

```pdsl
UNIT PlanPhase2Decompose
PURPOSE: Choose a lifecycle, decompose into phases, predict per-phase budget, and present the decomposition for the production choice that authorises the write (Phase 2).
STATE:
  SET lifecycle: gitignore | cleanup | archive | manual (default unset, scope workflow_run)
DO:
  LOAD {cf-studio-path}/.core/requirements/plan-decomposition.md
  RUN follow the plan-decomposition.md methodology rules
  LOAD {cf-studio-path}/.core/skills/studio/modules/planning-runtime.md
  RUN select a lifecycle from the STATE lifecycle options (gitignore | cleanup | archive | manual)
  RUN decompose by task-type strategy into phases (sections/categories/CDSL blocks), map intermediate results to out/ artifacts, insert review gates where the target workflow requires approval, and predict per-phase context budget — split any phase over 2000 lines
  RUN PlanningPhaseContract
  RUN PlanningChecklistContract
  LOAD {cf-studio-path}/.core/skills/studio/modules/plan-compile.md
  EMIT the decomposition summary — phases, est. lines, budget
  CONTINUE PlanPhase3Compile
RULES:
  NEVER write any file during decomposition — the brief package is written only after PlanProduceChoice resolves, and NEVER hide raw-input chunk estimates in vague totals
  ALWAYS normalize decomposed phases against the shared PlanningPhaseContract and PlanningChecklistContract before standalone packaging begins
  ALWAYS emit the decomposition summary before PlanProduceChoice, so the choice that authorises the write is made against the phases it will write
```
