---
description: Invoke when parsing a template into per-section questions and proposing defaults to produce an Inputs block for the user — parses H2 sections, loads the example, and returns the rendered Inputs proposal block for the orchestrator to show. When pre_resolved_inputs is supplied (from brainstorm), pre-fills those sections marked [from brainstorm] and proposes only the remaining ones.
---

<!-- toc -->

- [Frozen Input Payload](#frozen-input-payload)
- [Methodology](#methodology)
- [Output Contract](#output-contract)
- [Response Completion Gate](#response-completion-gate)

<!-- /toc -->

## Dispatch Generator Contract

This file is a controller-side prompt generator source, not a runtime prompt for the dispatched sub-agent.

The controller MUST use this file to synthesize the final dispatch prompt for
the agent. The final prompt MUST include the task statement, frozen input
payload, task-relevant instruction assets resolved from `SHARED_CONTEXT_PACK`,
allowed resource context, output contract, completion gate, and the explicit
rule that the dispatched sub-agent executes only that final prompt.

The dispatched sub-agent MUST NOT open prompt assets from disk and MUST NOT
rediscover workflows, requirements, specs, AGENTS, SKILL, or kit prompt files.


## Frozen Input Payload

```json
{
  "kind": "<KIND>",
  "name": "<artifact name>",
  "rules_mode": "STRICT|RELAXED",
  "template_path": "<path>",
  "example_path": "<path or null>",
  "kit_rules_path": "<path or null>",
  "system": "<system name>",
  "pre_resolved_inputs": { "<section>": "<value-from-brainstorm>" },
  "open_questions": ["<carryover from brainstorm>"]
}
```

## Methodology

```pdsl
UNIT GenerateCollectorMethodology

PURPOSE:
  Execute ordered steps to build the Inputs block.

DO:
  - RUN Parse the template's H2 sections into an ordered list
  - RUN For each section, decide its source:
       WHEN section name (or normalized form) appears in pre_resolved_inputs:
         - SET source = "brainstorm"
         Use that value
       ELSE:
         Propose a concrete default grounded in example_path and project context
         - SET source = "proposal"
  - RUN Build the Inputs markdown block per the workflow spec (Phase 1 format):
       Add [from brainstorm] tags on pre-filled sections
       Add Carryover Questions mini-section listing open_questions
```

## Output Contract

```pdsl
UNIT GenerateCollectorOutput

PURPOSE:
  Emit three artifacts in fixed order: markdown block, marker line, JSON block.

DO:
  - RUN Emit user-facing markdown Inputs block (shown to user verbatim)
     End the markdown block with the line:
       Reply: `approve all` or provide edits per item
  - RUN Emit raw HTML-comment marker line at column 0:
       <!-- proposed_inputs -->
     RULES:
       - ALWAYS emit at column 0 (NOT inside any code fence)
       - ALWAYS WHEN marker would fall inside a fenced block:
           Close the fence before emitting the marker line
           Resume a new fence after
       - ALWAYS The orchestrator regex matches ^<!-- proposed_inputs --> only outside
         fences; placing the marker inside a fence makes it undetectable
  - EMIT Immediately after the marker line, emit a standard json-fenced code block:
       Keys: template H2 section names (normalized — lowercased, spaces → _,
             punctuation stripped)
       Values: proposed defaults exactly as they appear verbatim in the
               markdown block above

- NEVER: preamble or trailing remarks after the JSON block

NOTES:
  Orchestrator locates this block by matching the regex:
    ^<!-- proposed_inputs -->\n```json
  and parses the next json-fenced block.
  Orchestrator (workflows/generate.md Phase 1 / Phase 4 author dispatch)
  consumes the parsed JSON when constructing the inputs field for the
  Phase 4 author selection payload.
```

Concretely, the agent's final two output lines plus the JSON block look exactly
like this (no `text` fence around the marker, no surrounding prose):

<!-- proposed_inputs -->
```json
{
  "<normalized_section_name>": "<proposed default verbatim>",
  ...
}
```

## Response Completion Gate

```pdsl
UNIT GenerateCollectorCompletionGate

PURPOSE:
  Enforce that every required output element is present before the response
  is complete.

RULES:
  - ALWAYS have exactly one Inputs block entry for every H2 section of the template
  - ALWAYS tag every brainstorm-filled section with [from brainstorm]
  - ALWAYS include carryover questions list (empty when no open questions)
  - ALWAYS have proposed_inputs JSON block after the markdown block with one
    key per H2 section (normalized) and the corresponding default value
  - ALWAYS satisfy the SKILL.md invariant
```
