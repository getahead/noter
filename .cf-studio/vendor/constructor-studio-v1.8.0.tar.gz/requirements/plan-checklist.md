---
cf: true
type: requirement
name: Plan Checklist
version: 1.0
purpose: Checklist for validating execution plans — used by analyze workflow and plan self-validation
---

# Plan Checklist


<!-- toc -->

- [Procedure](#procedure)
- [1. Structural Validation](#1-structural-validation)
- [1b. Brief-Phase Integrity](#1b-brief-phase-integrity)
- [2. Interactive Questions Completeness](#2-interactive-questions-completeness)
- [3. Rules Coverage](#3-rules-coverage)
- [4. Context Completeness](#4-context-completeness)
- [5. Phase Independence](#5-phase-independence)
- [6. Budget Compliance](#6-budget-compliance)
- [7. Lifecycle & Handoff](#7-lifecycle--handoff)
- [Validation Procedure](#validation-procedure)
- [Output Format](#output-format)

<!-- /toc -->

## Procedure

```pdsl
UNIT PlanChecklistProcedure

PURPOSE:
  Apply the plan checklist to validate plans after generation, during analysis, or when debugging failing phases.

WHEN:
  - REQUIRE plan generation is complete
  - OR cf-analyze is invoked on a plan
  - OR a failing phase is being debugged

DO:
  - RUN all checklist categories (Structural, Interactive Questions, Rules Coverage, Context Completeness, Phase Independence, Budget Compliance, Lifecycle & Handoff)
  - REQUIRE interactive questions verified explicitly
  - REQUIRE rules coverage verified explicitly
  - REQUIRE lifecycle handoff verified explicitly
  - REQUIRE validation next-step behavior verified explicitly
```

## 1. Structural Validation
- [ ] `plan.toml` exists at `.plans/{task-slug}/`.
- [ ] `[plan]` contains `task`, `type`, `target`, `created`, `total_phases`, and `lifecycle`.
- [ ] `[plan].approval_status` is `approved` once the decomposition gate has authorised the
      package, or `revised` once a change has superseded that approval. It is the record a
      later session reads, since run-scoped state does not survive a handoff into a new chat,
      and no phase is dispatched without it. **A plan written before approvals were recorded
      carries no such field**; that is not a malformed plan, and re-running the decomposition
      gate is what supplies one.
- [ ] `[[phases]]` blocks match actual phase files.
- [ ] Phase numbers are sequential.
- [ ] `depends_on` forms a valid DAG.
- [ ] `needs`, where a phase declares one, lists the decision keys that phase requires — a
      list of strings, each naming a key a gate in that phase will ask for. It is optional:
      a phase declaring none behaves exactly as it would without it, stopping when it
      reaches an unanswered question rather than being warned about beforehand. It is
      **phase-to-decision** and is kept apart from `depends_on`, which is phase-to-phase:
      waiting on another phase's output and waiting on a human answer fail differently and
      are cleared differently.
- [ ] `awaiting_decision`, where present, is a list of strings naming every decision key
      that phase was waiting on when the register last wrote it. Written at runtime by a
      gate that could not resolve, never by the plan's author. It is a **record, not a
      gate**: nothing clears it, and nothing needs to, because dispatch decides whether a
      phase may run by re-resolving that phase's `needs` against the plan rather than by
      reading this field. A key answered since simply stops holding anything.
- [ ] `status`, where present, is one of exactly five values — `pending`, `in_progress`,
      `blocked`, `done`, `failed`. The set is closed, and anything else is an invalid state
      rather than a sixth meaning: a hand-edited `Block` matches neither the runnable set
      nor the held one, so without this it is dropped from both and reads as finished work.
- [ ] `status = "blocked"`, where present, holds a phase regardless of its decisions. It is
      the one hold a person or an external tool sets by hand, so it carries no key and the
      notice says so rather than naming one it does not have.
- [ ] `outputs` and `inputs` are consistent across dependent phases.
- [ ] Every `[[phases]]` entry has `brief_file`.
- [ ] Every `brief-{NN}-{slug}.md` exists.
- [ ] Each phase has exactly one corresponding brief.
- [ ] Every `phase-{NN}-{slug}.md` exists.
- [ ] Every phase has valid TOML frontmatter.
- [ ] `number` matches filename.
- [ ] `total` matches `total_phases`.
- [ ] Required sections appear in order: `Preamble`, `What`, `Prior Context`, `Rules`, `Input`, `Task`, `Acceptance Criteria`, `Output Format`.
- [ ] `User Decisions` appears in the documented position when the phase has interaction points or carried decisions; it is omitted only when `plan-template.md` permits omission for phases with no decisions.

## 1b. Brief-Phase Integrity
- [ ] Every brief file is written before phase compilation starts.
- [ ] Each brief Load Instructions block references specific kit file line ranges.
- [ ] Each phase Rules section covers the ranges referenced by its brief.
- [ ] No phase contains extra inlined kit content outside its brief references.

## 2. Interactive Questions Completeness
- [ ] Source scanning includes the target workflow plus target `rules.md`, `checklist.md`, and `template.md`.
- [ ] Source scanning includes every file referenced by `ALWAYS open` and `OPEN and follow` directives.
- [ ] Question and input-request patterns are detected (`ask the user`, `ask user`, `what is`, `which`, trailing `?`, `user provides`, `user specifies`, `user enters`, `input from user`).
- [ ] Confirmation, review, and decision patterns are detected (`wait for`, `confirm`, `approval`, `before proceeding`, `review`, `present for`, `show to user`, `user inspects`, `choose`, `select`, `option A or B`, `decide`).
- [ ] All detected interaction points are listed in plan-generation output.
- [ ] Each interaction point is classified as `pre-resolvable`, `phase-bound`, or `cross-phase`.
- [ ] Pre-resolvable questions are asked before plan generation.
- [ ] Cross-phase questions are asked before plan generation.
- [ ] Phase-bound questions are embedded in the correct phase files.
- [ ] Each phase with interactions has `## User Decisions`.
- [ ] `## User Decisions` includes `### Already Decided` and `### Decisions Needed During This Phase` when applicable.
- [ ] Review gates appear as explicit Task steps.
- [ ] No source interaction point is omitted.
- [ ] `interaction_points_in_plan >= interaction_points_in_sources`.
- [ ] Rules do not reference `rules.md` by path instead of inlining.
- [ ] Rules do not contain `Prerequisites`, `Load Dependencies`, or `Tasks`, and they contain all required MUST and MUST NOT statements.
- [ ] Input does not reference `checklist.md` or `template.md` by path instead of inlining.
- [ ] Input does not inline full project artifacts or source code except small examples.
- [ ] Every `input_files` and `inputs` entry has a matching `Read {file}` task step.
- [ ] Per-phase context estimate uses `phase_file_lines + sum(input_files) + sum(inputs) + output_lines`.
- [ ] Estimated context does not exceed `2000` lines; `1501-2000` is warned.

## 3. Rules Coverage
- [ ] Target `rules.md` is read and filtered.
- [ ] Every MUST rule appears verbatim in at least one phase Rules section.
- [ ] Every MUST NOT rule appears verbatim in at least one phase Rules section.
- [ ] Rules are not summarized or paraphrased.
- [ ] `Prerequisites`, `Load Dependencies`, `Tasks`, `Next Steps`, and TOC are stripped from Rules.
- [ ] Phase Rules sections cover 100% of applicable MUST and MUST NOT rules in union.
- [ ] For analyze plans, target `checklist.md` is fully loaded.
- [ ] Every checklist item appears in at least one phase.
- [ ] Checklist items are inlined verbatim.
- [ ] Coverage reporting marks each rule `COVERED` or `MISSING`, then reports coverage percentage and missing rules.

## 4. Context Completeness
- [ ] The target workflow is opened and scanned for navigation directives.
- [ ] All `ALWAYS open`, `OPEN and follow`, and `ALWAYS open and follow` directives are processed.
- [ ] The loaded-file manifest is recorded and reported.
- [ ] `{cfs_cmd} info` or `{cfs_cmd} resolve-vars` is executed.
- [ ] All `{variable}` references resolve to absolute paths.
- [ ] No unresolved `{...}` patterns remain outside code fences.
- [ ] Rules inline MUST and MUST NOT content from `rules.md`.
- [ ] `Prerequisites`, `Tasks`, and `Next Steps` are stripped from Rules.
- [ ] Assigned `checklist.md` criteria and `template.md` sections are inlined in Input.
- [ ] Examples are excerpted where helpful.
- [ ] No "see rules.md" or "load checklist" path references remain.
- [ ] Project artifacts and source files stay in `input_files`, and intermediate results stay in `inputs`, not inline.
- [ ] Task includes explicit read instructions for every `input_files` and `inputs` entry.

## 5. Phase Independence
- [ ] Each phase is executable without prior Studio knowledge.
- [ ] Each phase is executable without reading other phase files.
- [ ] Prior Context summarizes earlier outputs instead of referencing them.
- [ ] Tool commands include full arguments.
- [ ] Producer phases declare `outputs`.
- [ ] Consumer phases declare `inputs`.
- [ ] `outputs` use `out/`.
- [ ] The final phase lists every required prior output.

## 6. Budget Compliance
- [ ] Each phase file is `<=1000` lines.
- [ ] Each phase file targets `<=500` lines.
- [ ] Each Rules section is `<=300` lines.
- [ ] Each Input section is `<=500` lines.
- [ ] Each Task section has `3-10` steps.
- [ ] Execution context is estimated per phase.
- [ ] No phase exceeds `5000` predicted lines.
- [ ] Warning phases (`3001-5000`) are noted.
- [ ] Overflow phases are auto-split before compilation.

## 7. Lifecycle & Handoff
- [ ] User is asked about lifecycle strategy after plan generation.
- [ ] `plan.toml` sets `lifecycle` to `gitignore`, `cleanup`, `archive`, or `manual`.
- [ ] The lifecycle action is implemented.
- [ ] The last phase Output Format includes `ALL PHASES COMPLETE`, the lifecycle strategy reference, and the canonical 3-option `Continue in this chat?` menu that surfaces validation first, then next-task selection, then end.
- [ ] Every non-final phase includes a single fenced, copy-pasteable next-phase prompt with both the `plan.toml` path and the next phase file path.
- [ ] The user is told to validate before execution, given Invoke skill `cf-analyze` on the plan directory, and offered validation as the first explicit final-menu step.

## Validation Procedure

```pdsl
UNIT PlanValidationProcedure

PURPOSE:
  Execute plan self-validation or plan analysis and produce a pass/fail result with issue reporting.

WHEN:
  - REQUIRE plan validation is invoked

DO:
  - RUN all checklist categories
  - EMIT every FAIL item with issue description and source location
  - SET pass_rate: passed_items / total_items
  - REQUIRE pass_rate equals 100% before execution proceeds; require correction otherwise
  - LOAD plan.toml, all phase files, and source rules/checklist/template for the target artifact kind
  - RUN automated checks: structure, variable resolution, budget compliance
  - RUN manual checks: interaction completeness, verbatim rules coverage, navigation/context completeness
```

## Output Format
```text
Plan Validation: {task-slug}
Plan: {cf-studio-path}/.plans/{task-slug}/plan.toml
Phases: {N}
Target: {artifact kind}
Status: PASS | FAIL
### Category Results
| Category | Status | Issues |
|----------|--------|--------|
| 1. Structural | PASS/FAIL | {count} |
| 2. Interactive Questions | PASS/FAIL | {count} |
| 3. Rules Coverage | PASS/FAIL | {count} |
| 4. Context Completeness | PASS/FAIL | {count} |
| 5. Phase Independence | PASS/FAIL | {count} |
| 6. Budget Compliance | PASS/FAIL | {count} |
| 7. Lifecycle & Handoff | PASS/FAIL | {count} |
### Issues Found
**Category {number}: {name}**
- MISSING: {missing item} ({source path}:{line})
### Recommendations
1. {fix missing interaction points}
2. {fix missing rules coverage}
3. {re-compile affected phases}
Pass rate: {passed}/{total} ({percentage}%)
```
