---
cf: true
type: requirement
name: Auto-Configuration Methodology
version: 1.0
purpose: Systematic methodology for scanning brownfield projects and generating project-specific agent rules
---

# Auto-Configuration Methodology
 

<!-- toc -->

- [Phase 1.5: Documentation Discovery](#phase-15-documentation-discovery)
- [Runtime Contract](#runtime-contract)
- [Phase 2: System Detection](#phase-2-system-detection)
- [Phase 3: Rule Generation](#phase-3-rule-generation)
- [Phase 4: AGENTS.md Integration](#phase-4-agentsmd-integration)
- [Phase 5: Registry Update](#phase-5-registry-update)
- [Phase 6: Validation](#phase-6-validation)
- [Output Specification](#output-specification)
- [Rule File Format](#rule-file-format)
- [WHEN Rule Patterns](#when-rule-patterns)
- [Error Handling](#error-handling)
- [References](#references)

<!-- /toc -->

 **Scope**: Brownfield projects where Studio is installed and the user wants
 to generate, refresh, or rescan project-specific rules/spec navigation.
 
 **Out of scope**: Greenfield projects with no code to scan. Existing
 configured specs/rules are not out of scope; they activate refresh/rescan
 mode and require an explicit update strategy before overwriting generated
 sections.
 
## Runtime Contract

```pdsl
UNIT AutoConfigActivation

PURPOSE:
  Route brownfield setup and rescan requests into the auto-config methodology.

WHEN:
  - REQUIRE auto-config intent or brownfield setup intent is detected

DO:
  - SET ACTIVATION_INTENT = auto_config_or_brownfield_setup
  - SET ACTIVATION_REQUIRED_PROMPT_ASSETS = auto_config_runtime_assets
  - SET ACTIVATION_MODE_FLAG = AUTO_CONFIG_MODE
  - LOAD {cf-studio-path}/.core/requirements/shared/runtime-activation-contract.md
  - CONTINUE SharedRuntimeActivationContract

RULES:
  - ALWAYS auto-config runtime assets include
    `{cf-studio-path}/.core/requirements/reverse-engineering.md` and
    `{cf-studio-path}/.core/requirements/prompt-engineering.md`
```

```pdsl
UNIT AutoConfigPhaseSequence

PURPOSE:
  Define the required phase order for an auto-config run.

STATE:
  - SET AUTO_CONFIG_PHASE: phase_1_scan | phase_1_5_docs | phase_2_systems | phase_3_rules | phase_4_agents | phase_5_registry | phase_6_validation | done
    default: phase_1_scan
  - SET AUTO_CONFIG_RULE_MODE: create | refresh | selective | report_only | cancel
    default: create

DO:
  - REQUIRE brownfield prerequisites pass before Phase 1
  - SET AUTO_CONFIG_PHASE = phase_1_scan
  - CONTINUE project scan
  - SET AUTO_CONFIG_PHASE = phase_1_5_docs
  - CONTINUE documentation discovery
  - SET AUTO_CONFIG_PHASE = phase_2_systems
  - CONTINUE system and topic detection
  - SET AUTO_CONFIG_PHASE = phase_3_rules
  - CONTINUE rule generation
  - SET AUTO_CONFIG_PHASE = phase_4_agents
  - CONTINUE AGENTS integration
  - SET AUTO_CONFIG_PHASE = phase_5_registry
  - CONTINUE registry update
  - SET AUTO_CONFIG_PHASE = phase_6_validation
  - CONTINUE validation
  - SET AUTO_CONFIG_PHASE = done

RULES:
  - ALWAYS execute phases in order
  - ALWAYS checkpoint after each phase
  - ALWAYS obtain user confirmation at every defined checkpoint before writing
  - NEVER replace this methodology with `cfs update`, `make update`,
    bootstrap refresh, kit refresh, cache refresh, or generated-agent refresh
    unless the user explicitly asks to leave auto-config and run those commands
```

```pdsl
UNIT AutoConfigWriteBoundaries

PURPOSE:
  Make the phase-specific write surfaces explicit.

RULES:
  - ALWAYS restrict generated rule files to `{cf-studio-path}/config/rules/`
  - ALWAYS restrict generated navigation rules to `{cf-studio-path}/config/AGENTS.md`
  - ALWAYS restrict detected-system registration to `{cf-studio-path}/config/artifacts.toml`
  - ALWAYS preserve existing project docs except for approved TOC additions
  - ALWAYS preserve user-authored content outside auto-config managed blocks
  - ALWAYS WHEN existing generated rule files or auto-config blocks are present:
      ALWAYS present ExistingRulesRefreshMenu before Phase 3 writes
      NEVER fail closed merely because rules already exist
      NEVER overwrite user-authored rules unless the selected mode explicitly
        includes that file and the Phase 3 write preview identifies the change

MENU ExistingRulesRefreshMenu:
  TITLE: |
    Existing auto-config rules or navigation blocks were found.

    Choose how to refresh them:
    1. Refresh generated rules and auto-config AGENTS blocks from a new scan
    2. Select files/sections to refresh after the scan summary
    3. Keep existing rules and only report scan findings
    4. Cancel auto-config
  OPTIONS:
    1 ->
      SET AUTO_CONFIG_RULE_MODE = refresh
      CONTINUE phase_1_scan
    2 ->
      SET AUTO_CONFIG_RULE_MODE = selective
      CONTINUE phase_1_scan
    3 ->
      SET AUTO_CONFIG_RULE_MODE = report_only
      CONTINUE phase_1_scan with writes disabled for existing rule files
    4 ->
      SET AUTO_CONFIG_RULE_MODE = cancel
      STOP_TURN
  INVALID:
    EMIT "Reply with 1, 2, 3, or 4."
    WAIT user.reply
    STOP_TURN
```

```pdsl
UNIT AutoConfigErrorHandling

PURPOSE:
  Define deterministic recovery and stop conditions for auto-config.

ON_ERROR:
  no_source_code_found ->
    EMIT "No source code detected in project"
    RETURN blocker

  existing_rules_found ->
    EMIT "Existing rules found in {cf-studio-path}/config/rules/ — choose refresh, selective refresh, report-only, or cancel."
    EMIT_MENU ExistingRulesRefreshMenu
    WAIT user.reply
    STOP_TURN

  scan_incomplete ->
    EMIT "Project scan incomplete: {reason}"
    CONTINUE with partial-scan warning

  large_codebase ->
    EMIT "Large codebase detected ({file_count} files)"
    CONTINUE with limited scan depth
```

```pdsl
UNIT AutoConfigPreconditions

PURPOSE:
  Verify the project is set up for auto-config before Phase 1 begins.

WHEN:
  - REQUIRE AUTO_CONFIG_PHASE == phase_1_scan

DO:
  - REQUIRE Studio is initialized (studio.py info returns FOUND)
  - REQUIRE source-code repository is accessible
  - REQUIRE {cf-studio-path}/config/ exists and is writable
  - REQUIRE {cf-studio-path}/config/rules/ is empty OR ExistingRulesRefreshMenu
    has resolved to refresh, selective, or report-only mode

RULES:
  - NEVER begin Phase 1 until all pre-checks pass
```

```pdsl
UNIT AutoConfigQualityRules

PURPOSE:
  Define quality and validation obligations applied across all auto-config phases.

RULES:
  - ALWAYS apply prompt-engineering.md Layer 2 and Layer 5 quality gates to
    every generated rule
  - ALWAYS include a Critical Files table in exactly one generated topic file
  - ALWAYS run {cfs_cmd} --json toc <file> on each generated rule file after writing it
  - ALWAYS generate only topic files that have at least 3 project-specific rules
  - NEVER generate topic files exceeding 120 lines
  - ALWAYS present generated rule files to the user before writing any file
  - ALWAYS validate that every generated WHEN rule resolves to an accessible
    file or heading
  - ALWAYS verify registry entries point to existing directories
  - ALWAYS validate generated TOML for syntax correctness
  - ALWAYS use activity-based WHEN conditions, not location-based
  - NEVER produce rules that overlap across topic files
  - NEVER include generic boilerplate or language-default rules
```
 
 ## Overview
 
 Auto-config scans a brownfield project and generates **per-topic** rule files in `{cf-studio-path}/config/rules/` plus contextual `WHEN` rules in `{cf-studio-path}/config/AGENTS.md`. Files are split by **topic** (`conventions`, `architecture`, `patterns`, etc.), not by system path, so the agent loads only the guidance relevant to the current activity.
 
 **Core principle**: extract conventions from code, do not impose them.
 
 | Output | Location | Purpose |
 |---|---|---|
 | Per-topic rule files | `{cf-studio-path}/config/rules/{topic}.md` | Focused rules per semantic topic |
 | Doc navigation rules | `{cf-studio-path}/config/AGENTS.md` | `WHEN` rules for existing project docs with heading anchors |
 | Rule-file navigation rules | `{cf-studio-path}/config/AGENTS.md` | `WHEN` rules that load generated topic files contextually |
 | Registry entries | `{cf-studio-path}/config/artifacts.toml` | Detected systems with source paths |
 | TOC updates | Existing docs + generated rule files | Navigability for docs and rules |
 
 **Upstream methodologies used**:
 - **Reverse Engineering** (`L1-L3`, `L8`): surface scan, entry points, structure, pattern recognition
 - **Prompt Engineering** (`L2`, `L5`, `L6`): clarity, anti-pattern prevention, context efficiency
 
 ## Preconditions
 
 **Trigger conditions** (`ANY`):
 - Automatic brownfield detection with no project specs in config (`studio.py info` reports `specs: []` or no specs dir, and source-code directories exist)
 - Manual invocation via `cf auto-config` or equivalent user request
 - Rescan via `{cfs_cmd} init --rescan` or equivalent reconfigure request
 
 **Pre-checks**:
 - [ ] Studio is initialized (`studio.py info` returns `FOUND`)
 - [ ] Source-code repository is accessible
 - [ ] `{cf-studio-path}/config/` exists and is writable
 - [ ] `{cf-studio-path}/config/rules/` is empty, or ExistingRulesRefreshMenu has
   resolved to refresh, selective refresh, or report-only mode

 ## Phase 1: Project Scan
 
 **Goal**: extract raw project data using reverse-engineering methodology.
 
 **Use**: `{cf-studio-path}/.core/requirements/reverse-engineering.md` Layers `1`, `2`, `3`, and `8`.
 
 | Subphase | Focus | Capture |
 |---|---|---|
 | `1.1` Surface Reconnaissance | Repository structure scan (`1.1.1-1.1.3`), language detection (`1.2.1-1.2.2`), documentation inventory (`1.3.1-1.3.2`) | `project_surface` — structure, languages, docs, git patterns |
 | `1.2` Entry Point Analysis | Application entry points (`2.1.1-2.1.2`), request entry points (`2.2.1-2.2.3`), bootstrap sequence (`2.3.1`) | `entry_points` — main files, HTTP routes, CLI commands, workers |
 | `1.3` Structural Decomposition | Architecture pattern (`3.1.1`), module/package boundaries (`3.1.2`), organization patterns (`3.2.1-3.2.2`), component inventory (`3.3.1-3.3.2`) | `structure` — architecture style, modules, boundaries, components |
 | `1.4` Pattern Recognition | Code patterns (`8.1.1-8.1.3`), project conventions (`8.2.1-8.2.3`), testing conventions (`8.3.1-8.3.2`) | `conventions` — naming, style, error handling, testing patterns |
 
 **Scan checkpoint**: after `1.1-1.4`, present and confirm:
 
 ```markdown
 ### Auto-Config Scan Summary
 
 **Project**: {name}
 **Languages**: {primary}, {secondary}
 **Architecture**: {pattern}
 **Entry points**: {count} ({types})
 **Modules**: {count} ({list})
 **Key conventions**:
 - Naming: {convention}
 - Error handling: {pattern}
 - Testing: {pattern}
 - File organization: {pattern}
 
 **Systems detected**: {count}
 ```

## Phase 1.5: Documentation Discovery

**Goal**: find project docs/specs, add TOCs where missing, and create heading-level navigation rules.

**Scan + capture**:
- [ ] Search `docs/`, `documentation/`, `guides/`, `wiki/`, `.github/`, standalone guides, ADR dirs, API docs, `README.md` links, `architecture/`, and `{cf-studio-path}/config/`
- [ ] Build `docs_inventory` with `path`, title from first `H1`, TOC present, heading count, estimated topic/scope
- [ ] For each doc, parse `H1-H4`, identify scope/topic, classify as `Guide` / `Reference` / `Standard` / `Decision`, define `WHEN`, and identify the most useful headings

**TOC flow**: offer `{cfs_cmd} toc {doc_path}`; show missing-TOC docs as `# | File | Headings | Topic`; on approval, run `{cfs_cmd} toc` per selected doc and verify success.

**Documentation map output**:

```markdown
### Project Documentation Found
| # | File | Type | Has TOC | Key Sections | WHEN Condition |
|---|---|---|---|---|---|
| 1 | `docs/architecture.md` | Reference | ✓ | System Overview, Components, Data Flow | writing architecture code |
| 2 | `CONTRIBUTING.md` | Guide | ✓ (generated) | Setup, Code Style, PR Process | contributing or submitting PRs |
| 3 | `docs/api/endpoints.md` | Reference | ✓ | Auth, Users, Billing | writing API endpoints |

### Proposed Navigation Rules
ALWAYS open and follow `docs/architecture.md#system-overview` WHEN modifying system architecture or adding new components
ALWAYS open and follow `CONTRIBUTING.md#code-style` WHEN writing any code
ALWAYS open and follow `docs/api/endpoints.md#authentication` WHEN writing authentication code
```

Present this to the user for confirmation.

## Phase 2: System Detection

**Goal**: identify logical systems, subsystems, and semantic rule topics.

**System detection**: classify as `Monolith`, `Monorepo`, `Microservices`, or `Library`; record `Name`, `Slug`, `Root path`, `Language`, `Type`, inter-system `Dependencies`; identify domain, infrastructure, and shared modules.

**System map checkpoint**:

```markdown
### Detected Systems
| # | Name | Slug | Root | Language | Type |
|---|---|---|---|---|---|
| 1 | {name} | {slug} | {path} | {lang} | {type} |

### Subsystems
**{system-name}**:
- {subsystem}: {path} — {description}
```

Present for confirmation and naming adjustments.

**Topic detection**: topics are semantic, not structural.

| Topic | Typical `WHEN` | Focus |
|---|---|---|
| `conventions` | writing or reviewing code | Naming, code style, imports, file organization |
| `architecture` | modifying architecture, adding components, or refactoring module boundaries | System design, boundaries, data flow, abstractions |
| `patterns` | implementing features or writing business logic | Error handling, data access, state management, DI, idioms |
| `testing` | writing or running tests | Structure, naming, bootstrap helpers, fixtures, coverage |
| `api-contracts` | writing API endpoints or CLI commands | Request/response shape, error codes, output contracts, versioning |
| `infrastructure` | building, deploying, or configuring CI/CD | Build, dependencies, environment, release process |
| `security` | writing security-sensitive code or handling user input | Auth, secrets, sanitization, permission checks |
| `anti-patterns` | reviewing code or refactoring | Project-specific prohibitions with rationale |

**Topic selection rules**: [ ] only if `>= 3` project-specific rules [ ] complement existing `config/specs/` rather than duplicate [ ] merge topics with `<3` rules [ ] split topics `>120` lines [ ] custom topics allowed.

**Topic map checkpoint**:

```markdown
### Proposed Rule Files
| # | Topic | File | Rules | WHEN condition |
|---|---|---|---|---|
| 1 | Conventions | `rules/conventions.md` | ~{n} rules | writing or reviewing code |
| 2 | Architecture | `rules/architecture.md` | ~{n} rules | modifying architecture or module boundaries |
| 3 | Patterns | `rules/patterns.md` | ~{n} rules | implementing features |
→ Confirm topic split before generating? [yes / adjust]
```

Present this to the user before Phase `3`.

## Phase 3: Rule Generation

**Goal**: generate project-specific rule files from scan data.

**Quality gate**: apply `{cf-studio-path}/.core/requirements/prompt-engineering.md` Layer `2` and Layer `5` to every generated rule.

**Base rule-file template**:

```markdown
---
cf: true
type: project-rule
topic: {topic-slug}
generated-by: auto-config
version: 1.0
---
# {Topic Title}
{One-paragraph scope statement}
## {Rule Group}
### {Rule Name}
{Imperative rule statement}
Evidence: `{file}:{line}` — {what was observed}
```

**Topic structure guidance**: `conventions.md` → Naming / Imports / File Organization / Code Style; `architecture.md` → Package Design / Module Boundaries / Communication Patterns / Key Abstractions + `Source Layout`; `patterns.md` → Error Handling / Data Access / State Management; `testing.md` → Structure / Naming / Fixtures / Coverage + bootstrap helpers; `api-contracts.md` → Output Format / Error Codes / Exit Codes / Versioning; `anti-patterns.md` → flat list of anti-pattern / why / safer alternative.

**Required checks**: [ ] focused [ ] has TOC [ ] specific [ ] observable [ ] grounded [ ] actionable [ ] `<120` lines [ ] no hallucination [ ] no overlap. One topic file, usually `architecture.md`, **MUST** include a `Critical Files` table.

**Generation protocol**: 1) filter by topic 2) merge/skip if `<3` rules 3) synthesize 4) validate against `AP-VAGUE`, `AP-CONTEXT-BLOAT`, `AP-HALLUCINATION-PRONE` 5) present batch to user 6) write after confirmation 7) run `python3 {cf-studio-path}/.core/skills/studio/scripts/studio.py toc {rule_file_path}`.

## Phase 4: AGENTS.md Integration

**Goal**: generate `WHEN` rules for topic files and existing project docs.

**Principle**: one topic file normally gets one whole-file `WHEN` rule; split by heading only if the file exceeds about `120` lines.

**Generated topic rules**:

```markdown
ALWAYS open and follow `{cf-studio-path}/config/rules/conventions.md` WHEN writing or reviewing code
ALWAYS open and follow `{cf-studio-path}/config/rules/architecture.md` WHEN modifying architecture, adding components, or refactoring module boundaries
ALWAYS open and follow `{cf-studio-path}/config/rules/patterns.md` WHEN implementing features or writing business logic
ALWAYS open and follow `{cf-studio-path}/config/rules/testing.md` WHEN writing or running tests
ALWAYS open and follow `{cf-studio-path}/config/rules/api-contracts.md` WHEN writing API endpoints or CLI commands
ALWAYS open and follow `{cf-studio-path}/config/rules/anti-patterns.md` WHEN reviewing code or refactoring
```

**Project-doc rules**: point to actionable headings such as `#code-style`, `#pr-process`, `#deployment`, and `#authentication`.

**Checks**: [ ] most specific actionable heading [ ] skip purely informational headings [ ] group related rules [ ] activity-based conditions, not location-based; multi-system example `WHEN implementing features in the auth service`; single-system example `WHEN implementing features or writing business logic`.

**AGENTS.md update** (preserve all existing user-written content):

```markdown
## Project Documentation (auto-configured)
<!-- auto-config:docs:start -->
{WHEN rules for existing project docs, with heading anchors}
<!-- auto-config:docs:end -->
## Project Rules (auto-configured)
<!-- auto-config:rules:start -->
{WHEN rules for generated rule files, with heading anchors if needed}
<!-- auto-config:rules:end -->
```

## Phase 5: Registry Update

**Goal**: register detected systems in `{cf-studio-path}/config/artifacts.toml`.

```toml
[[systems]]
name = "{System Name}"
slug = "{slug}"
kits = "studio-sdlc"
source_paths = ["{path1}", "{path2}"]
[[systems.artifacts]]
path = "{source-root}"
kind = "CODEBASE"
```

**Registry validation**: [ ] unique slugs [ ] existing/readable source paths [ ] no duplicates [ ] valid TOML.

## Phase 6: Validation

**Goal**: verify auto-config output is correct and useful.

**Validation**:
- Structural: [ ] all rule files exist [ ] all `WHEN` rules resolve [ ] registry entries point to existing directories [ ] TOML valid
- Quality + functional: [ ] Layer `2` → no ambiguity [ ] Layer `5` → no `AP-VAGUE`, `AP-CONTEXT-BLOAT`, `AP-HALLUCINATION-PRONE` [ ] Layer `6` → under `200` lines, efficient token use [ ] rules actionable and project-specific [ ] no generic boilerplate

**Validation report**:

```markdown
## Auto-Config Validation
**Systems detected**: {count}
**Topic files generated**: {count} ({list of topic slugs})
**WHEN rules added**: {count} (topic rules + doc rules)
**Registry entries added**: {count}
- Topic file quality: {PASS|WARN} (focused, <120 lines, no overlap)
- WHEN rule validity: {PASS|FAIL}
- Registry validity: {PASS|FAIL}
- {path}: {status}
```

## Output Specification

**Directory structure**:

```text
{cf-studio-path}/config/
├── AGENTS.md
├── artifacts.toml
└── rules/ (`conventions.md`, `architecture.md`, `patterns.md`, `testing.md`, `api-contracts.md`, `anti-patterns.md`)
```

Generate only topic files with at least `3` project-specific rules. Existing project docs stay preserved; only TOCs may be added where missing.

**Scripted JSON output**:

```json
{"status":"PASS","systems_detected":2,"topics_generated":["conventions","architecture","patterns","testing"],"agents_rules_added":4,"registry_entries_added":2,"files_written":["{cf-studio-path}/config/rules/conventions.md","{cf-studio-path}/config/rules/architecture.md","{cf-studio-path}/config/rules/patterns.md","{cf-studio-path}/config/rules/testing.md"],"docs_found":3,"docs_toc_generated":2,"doc_navigation_rules_added":5}
```

## Rule File Format

**Frontmatter**:

```yaml
---
cf: true
type: project-rule
topic: {topic-slug}
generated-by: auto-config
version: 1.0
---
```

**TOC requirements**:
- [ ] Immediately after frontmatter and `H1`
- [ ] Covers `H2`/`H3` with GitHub-style anchors
- [ ] Validate with `python3 {cf-studio-path}/.core/skills/studio/scripts/studio.py toc {rule_file_path}`

**Content guidelines**:
- [ ] Max `120` lines; imperative mood; specific file refs
- [ ] Evidence-based; no language-default boilerplate; no cross-topic content

## WHEN Rule Patterns

**Valid activity-based conditions**:

```text
WHEN writing or reviewing code
WHEN modifying architecture, adding components, or refactoring module boundaries
WHEN implementing features or writing business logic
WHEN writing or running tests
WHEN writing API endpoints or CLI commands
WHEN reviewing code or refactoring
WHEN building, deploying, or configuring CI/CD
WHEN writing security-sensitive code or handling user input
WHEN writing or reviewing code in the {system-name}
WHEN implementing features for {system-name}
WHEN {doc-specific-activity}
```

**WHEN-rule quality**: [ ] activity not location [ ] specific enough [ ] broad enough [ ] no overlap [ ] one rule per topic file unless `>120` lines [ ] heading anchors for project docs.

## Error Handling

Recovery paths for all error conditions are specified in `AutoConfigErrorHandling` above.

## References

- Reverse Engineering: `{cf-studio-path}/.core/requirements/reverse-engineering.md`
- Prompt Engineering: `{cf-studio-path}/.core/requirements/prompt-engineering.md`
- Generate Workflow: `{cf-studio-path}/.core/workflows/generate.md` (triggers auto-config in Brownfield prerequisite)
